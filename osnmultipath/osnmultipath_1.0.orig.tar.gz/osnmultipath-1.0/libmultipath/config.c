/*
 * Copyright (c) 2004, 2005 Christophe Varoqui
 * Copyright (c) 2005 Benjamin Marzinski, Redhat
 * Copyright (c) 2005 Edward Goggin, EMC
 */
#include <stdio.h>
#include <string.h>

#include "checkers.h"
#include "memory.h"
#include "util.h"
#include "debug.h"
#include "parser.h"
#include "dict.h"
#include "hwtable.h"
#include "vector.h"
#include "structs.h"
#include "config.h"
#include "blacklist.h"
#include "defaults.h"
#include "prio.h"
#include "version.h"
#include "devmapper.h"
#include "dmparser.h"

static int
hwe_strmatch (struct hwentry *hwe1, struct hwentry *hwe2)
{
	if (hwe1->vendor) {
		if (!hwe2->vendor || strcmp(hwe1->vendor, hwe2->vendor))
			return 1;
	}
	else if (hwe2->vendor)
		return 1;

	if (hwe1->product) {
		if (!hwe2->product || strcmp(hwe1->product, hwe2->product))
			return 1;
	}
	else if (hwe2->product)
		return 1;

	if (hwe1->revision) {
 		if (!hwe2->revision || strcmp(hwe1->revision, hwe2->revision))
			return 1;
	}
	else if (hwe2->revision)
		return 1;

	return 0;
}

static int
hwe_regmatch(struct hwentry *hwe, struct hwentry *hw)
{
	regex_t vre, pre, rre;
	int ret = 1;

	if (hwe->vendor &&
	    regcomp(&vre, hwe->vendor, REG_EXTENDED|REG_NOSUB))
		goto out;
	if (hwe->product &&
	    regcomp(&pre, hwe->product, REG_EXTENDED|REG_NOSUB))
		goto out_vre;
	if (hwe->revision &&
	    regcomp(&rre, hwe->revision, REG_EXTENDED|REG_NOSUB))
		goto out_pre;

	if ((!hwe->vendor || !hw->vendor ||
	     !regexec(&vre, hw->vendor, 0, NULL, 0)) &&
	    (!hwe->product || !hw->product ||
	     !regexec(&pre, hw->product, 0, NULL, 0)) &&
	    (!hwe->revision || !hw->revision ||
	     !regexec(&rre, hw->revision, 0, NULL, 0)))
		ret = 0;

	if (hwe->revision)
		regfree(&rre);
out_pre:
	if (hwe->product)
		regfree(&pre);
out_vre:
	if (hwe->vendor)
		regfree(&vre);
out:
	return ret;
}

struct hwentry *
find_hwe (vector hwtable, char * vendor, char * product, char * revision)
{
	int i;
	struct hwentry hw, *hwe, *ret = NULL;

	hw.vendor = vendor;
	hw.product = product;
	hw.revision = revision;

	vector_foreach_slot (hwtable, hwe, i) {
		if (hwe->all_devs == 1)
			continue;
		if (hwe_regmatch(hwe, &hw))
			continue;
		ret = hwe;
		break;
	}
	return ret;
}

extern struct mpentry *
find_mpe (char * wwid)
{
	int i;
	struct mpentry * mpe;

	if (!wwid)
		return NULL;

	vector_foreach_slot (conf->mptable, mpe, i)
		if (mpe->wwid && !strcmp(mpe->wwid, wwid))
			return mpe;

	return NULL;
}

extern char *
get_mpe_wwid (char * alias)
{
	int i;
	struct mpentry * mpe;

	if (!alias)
		return NULL;

	vector_foreach_slot (conf->mptable, mpe, i)
		if (mpe->alias && strcmp(mpe->alias, alias) == 0)
			return mpe->wwid;

	return NULL;
}

void
free_hwe (struct hwentry * hwe)
{
	if (!hwe)
		return;

	if (hwe->vendor)
		FREE(hwe->vendor);

	if (hwe->product)
		FREE(hwe->product);

	if (hwe->revision)
		FREE(hwe->revision);

	if (hwe->getuid)
		FREE(hwe->getuid);

	if (hwe->features)
		FREE(hwe->features);

	if (hwe->hwhandler)
		FREE(hwe->hwhandler);

	if (hwe->selector)
		FREE(hwe->selector);

	if (hwe->checker_name)
		FREE(hwe->checker_name);

	if (hwe->prio_name)
		FREE(hwe->prio_name);

	if (hwe->prio_args)
		FREE(hwe->prio_args);

	if (hwe->bl_product)
		FREE(hwe->bl_product);

	FREE(hwe);
}

void
free_hwtable (vector hwtable)
{
	int i;
	struct hwentry * hwe;

	if (!hwtable)
		return;

	vector_foreach_slot (hwtable, hwe, i)
		free_hwe(hwe);

	vector_free(hwtable);
}

void
free_mpe (struct mpentry * mpe)
{
	if (!mpe)
		return;

	if (mpe->wwid)
		FREE(mpe->wwid);

	if (mpe->selector)
		FREE(mpe->selector);

	if (mpe->getuid)
		FREE(mpe->getuid);

	if (mpe->alias)
		FREE(mpe->alias);

	if (mpe->prio_name)
		FREE(mpe->prio_name);

	if (mpe->prio_args)
		FREE(mpe->prio_args);

	FREE(mpe);
}

void
free_mptable (vector mptable)
{
	int i;
	struct mpentry * mpe;

	if (!mptable)
		return;

	vector_foreach_slot (mptable, mpe, i)
		free_mpe(mpe);

	vector_free(mptable);
}

struct mpentry *
alloc_mpe (void)
{
	struct mpentry * mpe = (struct mpentry *)
				MALLOC(sizeof(struct mpentry));

	return mpe;
}

struct hwentry *
alloc_hwe (void)
{
	struct hwentry * hwe = (struct hwentry *)
				MALLOC(sizeof(struct hwentry));

	return hwe;
}

static char *
set_param_str(char * str)
{
	char * dst;
	int len;

	if (!str)
		return NULL;

	len = strlen(str);

	if (!len)
		return NULL;

	dst = (char *)MALLOC(len + 1);

	if (!dst)
		return NULL;

	strcpy(dst, str);
	return dst;
}

#define merge_str(s) \
	if (!hwe1->s && hwe2->s) { \
		if (!(hwe1->s = set_param_str(hwe2->s))) \
			return 1; \
	}

#define merge_num(s) \
	if (!hwe1->s && hwe2->s) \
		hwe1->s = hwe2->s


static int
merge_hwe (struct hwentry * hwe1, struct hwentry * hwe2)
{
	merge_str(vendor);
	merge_str(product);
	merge_str(revision);
	merge_str(getuid);
	merge_str(features);
	merge_str(hwhandler);
	merge_str(selector);
	merge_str(checker_name);
	merge_str(prio_name);
	merge_str(prio_args);
	merge_str(bl_product);
	merge_num(pgpolicy);
	merge_num(pgfailback);
	merge_num(rr_weight);
	merge_num(no_path_retry);
	merge_num(minio);
	merge_num(minio_rq);
	merge_num(pg_timeout);
	merge_num(flush_on_last_del);
	merge_num(fast_io_fail);
	merge_num(dev_loss);
	merge_num(user_friendly_names);
	merge_num(retain_hwhandler);
	merge_num(detect_prio);

	return 0;
}

#define overwrite_str(s) \
do { \
        if (src->s) { \
		if (dst->s) \
			FREE(dst->s); \
                if (!(dst->s = set_param_str(src->s))) \
                        return 1; \
        } \
} while(0)

#define overwrite_num(s) \
do { \
	if (src->s) \
		dst->s = src->s; \
} while(0)

static int
overwrite_hwe (struct hwentry * dst, struct hwentry * src)
{
	overwrite_str(getuid);
	overwrite_str(features);
	overwrite_str(hwhandler);
	overwrite_str(selector);
	overwrite_str(checker_name);
	overwrite_str(prio_name);
	overwrite_str(prio_args);
	overwrite_str(bl_product);
	overwrite_num(pgpolicy);
	overwrite_num(pgfailback);
	overwrite_num(rr_weight);
	overwrite_num(no_path_retry);
	overwrite_num(minio);
	overwrite_num(minio_rq);
	overwrite_num(pg_timeout);
	overwrite_num(flush_on_last_del);
	overwrite_num(fast_io_fail);
	overwrite_num(dev_loss);
	overwrite_num(user_friendly_names);
	overwrite_num(retain_hwhandler);
	overwrite_num(detect_prio);

	if (dst->no_path_retry == NO_PATH_RETRY_FAIL && dst->features) {
		char *tmp;
		remove_feature(dst->features, "queue_if_no_path");
		tmp = realloc(dst->features, strlen(dst->features) + 1);
		if (tmp)
			dst->features = tmp;
	}
	return 0;
}

int
store_hwe (vector hwtable, struct hwentry * dhwe)
{
	struct hwentry * hwe;

	if (!(hwe = alloc_hwe()))
		return 1;

	if (!dhwe->vendor || !(hwe->vendor = set_param_str(dhwe->vendor)))
		goto out;

	if (!dhwe->product || !(hwe->product = set_param_str(dhwe->product)))
		goto out;

	if (dhwe->revision && !(hwe->revision = set_param_str(dhwe->revision)))
		goto out;

	if (dhwe->getuid) {
		if (strcmp(dhwe->getuid, DEFAULT_GETUID) == 0 &&
		    conf->replace_wwid_whitespace)
			hwe->getuid = set_param_str(DEFAULT_NOSPACE_GETUID);
		else
			hwe->getuid = set_param_str(dhwe->getuid);
		if (hwe->getuid == NULL)
			goto out;
	}

	if (dhwe->features && !(hwe->features = set_param_str(dhwe->features)))
		goto out;

	if (dhwe->hwhandler && !(hwe->hwhandler = set_param_str(dhwe->hwhandler)))
		goto out;

	if (dhwe->selector && !(hwe->selector = set_param_str(dhwe->selector)))
		goto out;

	if (dhwe->checker_name && !(hwe->checker_name = set_param_str(dhwe->checker_name)))
		goto out;
				
	if (dhwe->prio_name && !(hwe->prio_name = set_param_str(dhwe->prio_name)))
		goto out;

	if (dhwe->prio_args && !(hwe->prio_args = set_param_str(dhwe->prio_args)))
		goto out;
				
	hwe->pgpolicy = dhwe->pgpolicy;
	hwe->pgfailback = dhwe->pgfailback;
	hwe->rr_weight = dhwe->rr_weight;
	hwe->no_path_retry = dhwe->no_path_retry;
	hwe->minio = dhwe->minio;
	hwe->minio_rq = dhwe->minio_rq;
	hwe->pg_timeout = dhwe->pg_timeout;
	hwe->flush_on_last_del = dhwe->flush_on_last_del;
	hwe->fast_io_fail = dhwe->fast_io_fail;
	hwe->dev_loss = dhwe->dev_loss;
	hwe->user_friendly_names = dhwe->user_friendly_names;
	hwe->retain_hwhandler = dhwe->retain_hwhandler;
	hwe->detect_prio = dhwe->detect_prio;

	if (dhwe->bl_product && !(hwe->bl_product = set_param_str(dhwe->bl_product)))
		goto out;

	if (!vector_alloc_slot(hwtable))
		goto out;

	vector_set_slot(hwtable, hwe);
	return 0;
out:
	free_hwe(hwe);
	return 1;
}

static int
factorize_hwtable (vector hw, int n)
{
	struct hwentry *hwe1, *hwe2;
	int i, j;

	vector_foreach_slot(hw, hwe1, i) {
		if (i == n)
			break;

		j = n;
		vector_foreach_slot_after(hw, hwe2, j) {
			if (hwe1->all_devs == 1) {
				overwrite_hwe(hwe2, hwe1);
				continue;
			}
			else if (conf->regex_match){
				if (hwe_regmatch(hwe2, hwe1))
					continue;
			}
			else if (hwe_strmatch(hwe1, hwe2))
				continue;
			/* dup */
			merge_hwe(hwe1, hwe2);
			free_hwe(hwe2);
			vector_del_slot(hw, j);
			j--;
		}
	}
	return 0;
}

struct config *
alloc_config (void)
{
	return (struct config *)MALLOC(sizeof(struct config));
}

void
free_config (struct config * conf)
{
	if (!conf)
		return;

	if (conf->dev)
		FREE(conf->dev);

	if (conf->udev_dir)
		FREE(conf->udev_dir);

	if (conf->multipath_dir)
		FREE(conf->multipath_dir);

	if (conf->selector)
		FREE(conf->selector);

	if (conf->getuid)
		FREE(conf->getuid);

	if (conf->features)
		FREE(conf->features);

	if (conf->hwhandler)
		FREE(conf->hwhandler);

	if (conf->prio_name)
		FREE(conf->prio_name);

	if (conf->checker_name)
		FREE(conf->checker_name);
	if (conf->reservation_key)
		FREE(conf->reservation_key);

	free_blacklist(conf->blist_devnode);
	free_blacklist(conf->blist_wwid);
	free_blacklist_device(conf->blist_device);

	free_blacklist(conf->elist_devnode);
	free_blacklist(conf->elist_wwid);
	free_blacklist_device(conf->elist_device);

	free_mptable(conf->mptable);
	free_hwtable(conf->hwtable);
	free_keywords(conf->keywords);
	FREE(conf);
}

int
load_config (char * file)
{
	int hwtable_size;
	//if (!conf)
		conf = alloc_config();

	if (!conf)
		return 1;

	/*
	 * internal defaults
	 */
	if (!conf->verbosity)
		conf->verbosity = DEFAULT_VERBOSITY;

	conf->dmrq = dm_drv_get_rq();
	conf->dev_type = DEV_NONE;
	conf->minio = DEFAULT_MINIO;
	conf->minio_rq = DEFAULT_MINIO_RQ;
	get_sys_max_fds(&conf->max_fds);
	conf->bindings_file = DEFAULT_BINDINGS_FILE;
	conf->multipath_dir = set_default(DEFAULT_MULTIPATHDIR);
	conf->flush_on_last_del = 0;
	conf->attribute_flags = 0;
	conf->find_multipaths = DEFAULT_FIND_MULTIPATHS;
	conf->retain_hwhandler = DEFAULT_RETAIN_HWHANDLER;
	conf->detect_prio = DEFAULT_DETECT_PRIO;
	conf->reload_readwrite = 0;
	conf->replace_wwid_whitespace = 0;

	/*
	 * preload default hwtable
	 */
	if (conf->hwtable == NULL) {
		conf->hwtable = vector_alloc();

		if (!conf->hwtable)
			goto out;
	}

	/*
	 * read the config file
	 */
	if (filepresent(file)) {
		set_current_keywords(&conf->keywords);
		init_data(file, init_keywords);
		
		//if (init_data(file, init_keywords)) {
		//	condlog(0, "error parsing config file");
			//goto out;
		//}
	} else {
		condlog(0, "/etc/multipath.conf does not exist, blacklisting all devices.");
		condlog(0, "A sample multipath.conf file is located at");
		condlog(0,
"/usr/share/doc/device-mapper-multipath-%d.%d.%d/multipath.conf",
			MULTIPATH_VERSION(VERSION_CODE));
		condlog(0,
"You can run /sbin/mpathconf to create or modify /etc/multipath.conf");
		conf->blist_devnode = vector_alloc();
		if (!conf->blist_devnode) {
			condlog(0, "cannot allocate blacklist\n");
			goto out;
		}
		if (store_ble(conf->blist_devnode, strdup(".*"),
			      ORIGIN_NO_CONFIG)) {
			condlog(0, "cannot store default no-config blacklist\n");
			goto out;
		}
	}
	hwtable_size = VECTOR_SIZE(conf->hwtable);
	if (setup_default_hwtable(conf->hwtable))
		goto out;
	/*
	 * remove duplica in hwtable. config file takes precedence
	 * over build-in hwtable
	 */
	if (hwtable_size)
		factorize_hwtable(conf->hwtable, hwtable_size);

	/*
	 * fill the voids left in the config file
	 */
	if (conf->blist_devnode == NULL) {
		conf->blist_devnode = vector_alloc();

		if (!conf->blist_devnode)
			goto out;
	}
	if (conf->blist_wwid == NULL) {
		conf->blist_wwid = vector_alloc();

		if (!conf->blist_wwid)
			goto out;
	}
	if (conf->blist_device == NULL) {
		conf->blist_device = vector_alloc();

		if (!conf->blist_device)
			goto out;
	}
	if (setup_default_blist(conf))
		goto out;

	if (conf->elist_devnode == NULL) {
		conf->elist_devnode = vector_alloc();

		if (!conf->elist_devnode)
			goto out;
	}
	if (conf->elist_wwid == NULL) {
		conf->elist_wwid = vector_alloc();

		if (!conf->elist_wwid)
			goto out;
	}

	if (conf->elist_device == NULL) {
		conf->elist_device = vector_alloc();

		if (!conf->elist_device)
			goto out;
	}

	if (conf->mptable == NULL) {
		conf->mptable = vector_alloc();
		if (!conf->mptable)
			goto out;
	}
	if (conf->selector == NULL)
		conf->selector = set_default(DEFAULT_SELECTOR);

	if (conf->udev_dir == NULL)
		conf->udev_dir = set_default(DEFAULT_UDEVDIR);

	if (conf->getuid == NULL) {
		if (conf->replace_wwid_whitespace)
			conf->getuid = set_default(DEFAULT_NOSPACE_GETUID);
		else
			conf->getuid = set_default(DEFAULT_GETUID);
	}

	if (conf->features == NULL)
		conf->features = set_default(DEFAULT_FEATURES);

	if (conf->hwhandler == NULL)
		conf->hwhandler = set_default(DEFAULT_HWHANDLER);

	if (!conf->selector  || !conf->udev_dir || !conf->multipath_dir ||
	    !conf->getuid    || !conf->features ||
	    !conf->hwhandler)
		goto out;

	if (!conf->prio_name)
		conf->prio_name = set_default(DEFAULT_PRIO);

	if (!conf->checker_name)
		conf->checker_name = set_default(DEFAULT_CHECKER);

	return 0;
out:
	free_config(conf);
	return 1;
}

