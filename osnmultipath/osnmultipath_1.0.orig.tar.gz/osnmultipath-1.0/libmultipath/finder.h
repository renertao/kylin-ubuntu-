/*
 * Copyright (c) 2010 Benjamin Marzinski, Redhat
 */

#ifndef _FINDER_H
#define _FINDER_H

#define WWIDS_FILE_HEADER \
"# Multipath wwids, Version : 1.0\n" \
"# NOTE: This file is automatically maintained by multipath and multipathd.\n" \
"# You should not need to edit this file in normal circumstances.\n" \
"#\n" \
"# Valid WWIDs:\n"

int should_multipath(struct path *pp, vector pathvec);
int remember_wwid(char *wwid);
int check_wwids_file(char *wwid, int write_wwid);

#endif /* _FINDER_H */
