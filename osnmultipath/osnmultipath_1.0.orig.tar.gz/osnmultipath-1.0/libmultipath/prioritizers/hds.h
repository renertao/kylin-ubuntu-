#ifndef _HDS_H
#define _HDS_H

#define PRIO_HDS "hds"
int prio_hds(struct path * pp);

#endif
