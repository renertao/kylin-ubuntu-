#ifndef _ONTAP_H
#define _ONTAP_H

#define PRIO_ONTAP "ontap"
int prio_ontap(struct path * pp);

#endif
