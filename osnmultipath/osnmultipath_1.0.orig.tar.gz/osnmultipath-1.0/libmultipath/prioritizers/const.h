#ifndef _CONST_H
#define _CONST_H

#define PRIO_CONST "const"
int prio_const(struct path * pp);

#endif
