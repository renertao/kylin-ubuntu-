#ifndef _WEIGHTED_H
#define _WEIGHTED_H

#define PRIO_WEIGHTED  "weighted"

int prio_weighted(struct path *pp);

#endif
