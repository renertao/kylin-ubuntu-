/******************************************************************************
*******************************************************************************
**
**  Copyright (C) 2009 Red Hat, Inc.  All rights reserved.
**
**  This copyrighted material is made available to anyone wishing to use,
**  modify, copy, or redistribute it subject to the terms and conditions
**  of the GNU General Public License v.2.
**
*******************************************************************************
******************************************************************************/

/* This prioritizer is based on a path's device name or its H:T:B:L. Both of
 * these can change when the node is rebooted, and can differ from node to
 * node. (i.e. there is no guarantee that sda will point to the same device
 * after a reboot) If you use this prioritizer, it may be necessary to
 * manually edit /etc/multipath.conf after any reboot
 *
 * Format:
 * prio		"weighted hbtl <regex> <prio> [<regex> <prio>]
 * prio		"weighted devname <regex> <prio> [<regex> <prio>]
 *
 * Examples:
 * prio		"weighted hbtl 4:* 2 3:.:.:. 1"
 * prio		"weighted devname sda 2 sde 1"
 *
 */

#include <string.h>
#include <prio.h>
#include <debug.h>
#include <regex.h>

#include "weighted.h"

#define DEFAULT_WEIGHTED_PRIO 0

#define pp_weighted_log(prio, fmt, args...) \
	condlog(prio, "%s: weighted prio: " fmt, dev, ##args)

static char *
next_str(char **str)
{
	char *next;

	do {
		next = strsep(str, " \t");
	} while (next && strcmp(next, "") == 0);
	return next;
}


static int
match (char *dev, char *target, char *regex_str, char *prio_str,
       unsigned int *prio)
{

	regex_t regex;
	int err, ret = 0;
	char *errbuf;
	size_t errbuf_size;
	unsigned int prio_match;

	if (sscanf(prio_str, "%u", &prio_match) != 1) {
		condlog(0, "%s: weighted prio: invalid prio '%s'", dev,
			prio_str);
		return 0;
	}
	err = regcomp(&regex, regex_str, REG_EXTENDED|REG_NOSUB);
	if (err) {
		errbuf_size = regerror(err, &regex, NULL, 0);
		errbuf = malloc(errbuf_size);
		regerror(err, &regex, errbuf, errbuf_size);
		condlog(0, "%s: weighted prio: cannot compile regex '%s' : %s",
			dev, regex_str, errbuf);
		free(errbuf);
		return 0;
	}
	if (regexec(&regex, target, 0, NULL, 0) == 0) {
		*prio = prio_match;
		ret = 1;
	}

	regfree(&regex);
	return ret;
}

int
prio_weighted(struct path * pp)
{
	char target[FILE_NAME_SIZE];
	char *buff, *args, *ptr, *prio_str;
	unsigned int prio = DEFAULT_WEIGHTED_PRIO;
	char *regex_str = NULL;
	int regex_size = 0;

	if (!pp->prio_args)
		return DEFAULT_WEIGHTED_PRIO;
	buff = args = strdup(pp->prio_args);
	ptr = next_str(&args);

	if (strcasecmp(ptr, "hbtl") == 0)
		sprintf(target, "%d:%d:%d:%d", pp->sg_id.host_no,
			pp->sg_id.channel, pp->sg_id.scsi_id, pp->sg_id.lun);
	else if (strcasecmp(ptr, "devname") == 0)
		strcpy(target, pp->dev);
	else {
		condlog(0, "%s: weighted prio: invalid argument. Want 'hbtl' or 'devname'. Got '%s'", pp->dev, ptr);
		goto out;
	}

	while ((ptr = next_str(&args)) != NULL) {

		prio_str = next_str(&args);
		if (!prio_str) {
			condlog(0, "%s weighted prio: missing prio for regex '%s'", pp->dev, ptr);
			goto out;
		}
		if (!regex_str || regex_size < strlen(ptr) + 3){
			regex_size = strlen(ptr) + 3;
			regex_str = realloc(regex_str, regex_size);
		}
		sprintf(regex_str, "%s%s%s", (ptr[0] == '^')? "" : "^",
			ptr, (ptr[strlen(ptr)-1] == '$')? "" : "$");
		if (match(pp->dev, target, regex_str, prio_str, &prio))
			break;
	}
out:
	free(buff);
	if (regex_str)
		free(regex_str);
	return prio;
}

int
getprio(struct path * pp)
{
	return prio_weighted(pp);
}
