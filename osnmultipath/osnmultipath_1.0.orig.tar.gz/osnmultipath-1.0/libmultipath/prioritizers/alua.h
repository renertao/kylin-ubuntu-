#ifndef _ALUA_H
#define _ALUA_H

#include "alua_rtpg.h"

#define PRIO_ALUA "alua"
int prio_alua(struct path * pp);

#endif
