int assemble_map (struct multipath *);
int disassemble_map (vector, char *, struct multipath *);
int disassemble_status (char *, struct multipath *);
int remove_feature (char *features, char *old);
