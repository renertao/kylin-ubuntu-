#ifndef _DIRECTIO_H
#define _DIRECTIO_H

int directio (struct checker *);
int directio_init (struct checker *);
void directio_free (struct checker *);

#endif /* _DIRECTIO_H */
