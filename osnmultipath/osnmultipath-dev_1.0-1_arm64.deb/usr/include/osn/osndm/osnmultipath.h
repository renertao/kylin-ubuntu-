#ifndef _OSNMULTIPATH_H
#define _OSNMULTIPATH_H
#include "list.h"
#define MAX_DM_PATH 10  //dm-2
#define MAX_DEV_PATH 100  // /dev/mapper/mpatha
struct osn_dmdisk { 
	char *dev_name; /* such as 'mpatha' */
   char *dev_path;  /* such as '/dev/mapper/mpatha' */
   char *dm_wwid;
	char *dm_name;  /*such as dm-2*/
	//char *vendor;
	//char *model;
   //uint64_t size;   /* number of sectors */
   
   struct list_head src_disk;
   struct list_head list; 
 };

struct dm_src_disk {
   char *name;
   struct list_head list;
};

int osnmultipath_get_devs(struct list_head *dev_head);

void osn_free_dmdisk(struct osn_dmdisk *odmdisk);
void osn_free_dmdisklist(struct list_head *dev_head);
#endif
