#include <stdio.h>
#include <unistd.h>
#include "osndisk.h"
#include "list.h"

/**
 * debugging for memory leaks 
 */
int main(int argc, char **argv)
{
	struct list_head devs;

	INIT_LIST_HEAD(&devs);
	while (1) {
		osndisk_get_devs(&devs, 0);
		osndisk_free_devs(&devs);
		sleep(1);
	}
}
