?package(osndisk):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="osndisk" command="/usr/bin/osndisk"
