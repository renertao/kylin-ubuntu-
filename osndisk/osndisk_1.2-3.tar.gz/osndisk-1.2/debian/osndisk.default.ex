# Defaults for osndisk initscript
# sourced by /etc/init.d/osndisk
# installed at /etc/default/osndisk by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
