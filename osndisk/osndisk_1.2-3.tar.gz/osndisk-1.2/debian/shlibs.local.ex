libosndisk 1.2 osndisk (>> 1.2-0), osndisk (<< 1.2-99)
