#
# Regular cron jobs for the osndisk package
#
0 4	* * *	root	[ -x /usr/bin/osndisk_maintenance ] && /usr/bin/osndisk_maintenance
