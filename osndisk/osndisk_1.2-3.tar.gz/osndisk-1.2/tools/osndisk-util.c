#include <stdio.h>
#include "osndisk.h"

int main(int argc, char **argv)
{
	return osndisk(argc, argv);
}
