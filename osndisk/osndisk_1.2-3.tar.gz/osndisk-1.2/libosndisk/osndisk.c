#define _GNU_SOURCE

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <regex.h>
#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <blkid/blkid.h>
#include <dirent.h>
#include <libgen.h>
#include <linux/major.h>
#include <fcntl.h>
#include <inttypes.h>
//#include <osn/osndm/osnmultipath.h>
#include <pthread.h>
#include "osndisk.h"
#include "osnlog.h"
#include "scsi_inquiry.h"

#define E_POINTER_NONE 101
#define E_FILE_NOT_EXIST 102
#define E_SDEV_FORMAT 103

#define MAX_NAME_LEN 256
#define MAX_ATTR_LEN 50

#define SYS_CLASS_SCSI_DEV "/sys/class/scsi_device"
#define SYS_CLASS_SCSI_HOST "/sys/class/scsi_host"
#define SYS_CLASS_ISCSI_HOST "/sys/class/iscsi_host"
#define SYS_CLASS_FC_HOST "/sys/class/fc_host"
#define SYS_CLASS_FC_TRANSPORT "/sys/class/fc_transport"
#define SYS_CLASS_FC_REMOTE_PORTS "/sys/class/fc_remote_ports"
#define SYS_BLOCK_CCISS "/sys/block"
#define ATA_DEVICE_HOST "ata"

#define LIST_SDEV_NAME "Name"
#define LIST_SIZE "Size"
#define LIST_HCTL "H:C:T:L"
#define LIST_VENDOR "Vendor"
#define LIST_MODEL "Model"
#define LIST_REVISION "Rev"
#define LIST_DMNAME "BlockName"
#define LIST_STATUS "Status"
#define LIST_TARGET "Transport"
#define LIST_PATH "DevicePath"
#define LIST_TYPE "Type"
#define LIST_SCSI_LEVEL "Scsi level"
#define LIST_DEVICE_BLOCKED "Blocked"
#define LIST_TIMEOUT "Timeout"
#define LIST_IOCOUNTERBITS "IOcounterBits"
#define LIST_IODONE_CNT "IOdone"
#define LIST_IOERR_CNT "IOerr"
#define LIST_IOREQUEST_CNT "IOrequest"
#define LIST_PARTITION "Part"
#define LIST_GUID "GUID"
#define LIST_TOTAL_SIZE "Total"
#define LIST_USED_SIZE "Used"
#define LIST_FS "Filesystem"
#define LIST_MOUNTPOINT "Mountpoint"

#define PROC_PARTITIONS "/proc/partitions"
#define PROC_MOUNTS "/proc/mounts"

#define MAX(a, b) (a) > (b) ? (a) : (b)

static pthread_mutex_t g_osndisk_mutex = PTHREAD_MUTEX_INITIALIZER;

struct osn_target {
	hctl_t hctl;
	char *name;

	struct list_head target_list;
};

struct osndisk_param {
	int list;
	int list_all;
	int transport;
	int info;
	int rescan;
	int force_rescan;
   int target_list;
	char *dev_path;
   struct list_head chns;
};

static struct option long_options[] = {
	{"list", 0, 0, 'l'},
	{"all", 0, 0, 'a'},
	{"info", 1, 0, 'i'},
	{"rescan", 0, 0, 'r'},
	{"force", 0, 0, 'f'},
	{"help", 0, 0, 'h'},
	{0, 0, 0, 0}
};

static const char *scsi_types[] = {
	"Direct-Access",
	"Sequential-Access",
	"Printer",
	"Processor",
	"Write-once",
	"CD-ROM",
	"Scanner",
	"Optical memory",
	"Medium Changer",
	"Communications",
	"Unknown (0xa)",
	"Unknown (0xb)",
	"Storage array",
	"Enclosure",
	"Simplified direct-access",
	"Optical card read/writer",
	"Bridge controller",
	"Object based storage",
	"Automation Drive interface",
	"Reserved (0x13)", "Reserved (0x14)",
	"Reserved (0x15)", "Reserved (0x16)", "Reserved (0x17)",
	"Reserved (0x18)", "Reserved (0x19)", "Reserved (0x1a)",
	"Reserved (0x1b)", "Reserved (0x1c)", "Reserved (0x1e)",
	"Well known LU",
	"No device",
};

static void usage(void)
{
	const char *usage_message =
		"  -l|--list                       list online disks\n"
		"  -a|--all                        list all disks include offline ones\n"
		"  -t|--transport                  list disks' transport\n"
		"  -i|--info <diskPath>            show disk information verbosely\n"
		"  -r|--rescan                     rescan disks that maybe changed or offline\n"
		"  -f|--force                      rescan all disks even one is exist, specified with '-r'\n"
      "  -T|--target <ChannelTarget>     rescan disks that channel appointed, specified with '-r'\n"
		"  -h|--help\n";
	fprintf(stdout, "%s", usage_message);
}

/**
 * path: such as /dev/sda,
 * return 1 if online, 0 if offline
 */
/*
static int _is_online(const char *path)
{
	int fd, online = 0;
	char mbr_buf[512] = {0};

	fd = open(path, O_RDONLY);
	if (fd == -1)
		return 0;

	if (512 == read(fd, mbr_buf, 512))
		online = 1;
	close(fd);

	return online;
}
*/
static char *byte_to_str(uint64_t size)
{
	char *size_str;
	const uint64_t k = 1024;
	const uint64_t m = k * k;
	const uint64_t g = m * k;
	const uint64_t t = g * k;

	if ((size_str = (char*)malloc(128)) == NULL) {
		log_error("Failed to allocate memory");
		return NULL;
	}
	memset(size_str, 0, 128);

	if ((int64_t)size == -1) {
		strcpy(size_str, "unknown");
		goto out;
	}

	if (size >= t)
		sprintf(size_str, "%0.2lfTB", (float)size/t);
	else if (size >= g)
		sprintf(size_str, "%0.2lfGB", (float)size/g);
	else if (size >= m)
		sprintf(size_str, "%0.2lfMB", (float)size/m);
	else if (size >= k)
		sprintf(size_str, "%0.2lfKB", (float)size/k);
	else
		sprintf(size_str, "%0.2lfByte", (float)size);

out:
	return size_str;
}

static int filter(const struct dirent *s)
{
	if (s == NULL || s->d_name[0] == '.')
		return 0;
	return 1;
}

/**
 * @ brief Filter the block device of HP Smart Array. soft link name like cciss!cXdY. X-Controller num,
 *         Y-Disk num
 */
static int filter_cciss_block(const struct dirent *s)
{
	if (s == NULL || s->d_name[0] == '.') {
		return 0;
	}
	else {
		if (strstr(s->d_name, "cciss!")) {
			return 1;
		}
		else { 
			return 0;
		}
	}
}

static int filter_citrix_xen_disk(const struct dirent *s) {
    int ret;
    regex_t pattern;

    if (s == NULL || s->d_name[0] == '.') {
        return 0;
    }
    
    ret = regcomp(&pattern, "xvd[a-z]", 0);
    if (ret) {
        return 0;
    }

    ret = regexec(&pattern, s->d_name, 0, NULL, 0);
    if (! ret) {
        regfree(&pattern);
        return 1;
    }
    regfree(&pattern);
    return 0;
}

static void sanitize_string(char *str)
{
	int i, len;

	if (!str)
		return;
	if (!(len = strlen(str)))
		return;

	for (i = len-1; i >= 0; i--) {
		if (str[i] == ' ')
			str[i] = 0;
		else
			break;
	}
}
/*
static uint64_t atoi_large(const char *src)
{
	uint64_t res = 0;
	const char *p = src;

	if (!src)
		return 0;
	while (p) {
		if (*p <= '9' && *p >= '0')
			res = res*10 + *p - '0';
		else
			break;
		p++;
	}
	return res;
}
*/
/*
static int invalid_hctl(hctl_t *hctl)
{
	hctl->h = -1;
	hctl->c = -1;
	hctl->t = -1;
	hctl->l = -1;

	return 1;
}
*/
int osndisk_free_one_part(struct osn_part *part_node)
{
	if (!part_node)
		return 0;

	free(part_node->name);
	free(part_node->uuid);
	free(part_node->fstype);
   if (part_node->block_name)
      free(part_node->block_name);
	free(part_node->mountpoint);
	free(part_node);

	return 1;
}

int osndisk_free_parts(struct list_head *part_head)
{
	struct osn_part *op, *op_tmp;

	if (!part_head)
		return 0;
	list_for_each_entry_safe(op, op_tmp, part_head, list) {
		list_del(&op->list);
		osndisk_free_one_part(op);
	}

	return 1;
}

int osndisk_free_chns(struct list_head *chns)
{
   if (list_empty(chns)) {
      return 0;
   }
   struct osn_chn *chn = NULL, *chn_tmp = NULL;
   list_for_each_entry_safe (chn, chn_tmp, chns, list) {
      list_del(&chn->list);
      if (chn->target) {
         free(chn->target);
         chn->target = NULL;
      }
      if (chn->initiator) {
         free(chn->initiator);
         chn->initiator = NULL;
      }
   }
   return 0;
}

int osndisk_free_one_dev(struct osn_disk *dev_node)
{
	if (!dev_node)
		return 0;
    if (dev_node->dev_name)
	    free(dev_node->dev_name);
    if (dev_node->vendor)
	    free(dev_node->vendor);
    if (dev_node->model)
	    free(dev_node->model);
    if (dev_node->revision)
	    free(dev_node->revision);
    if (dev_node->dev_path)
	    free(dev_node->dev_path);
    if (dev_node->queue_type)
	    free(dev_node->queue_type);
    if (dev_node->target)
	    free(dev_node->target);
    if (dev_node->block_name)
        free(dev_node->block_name);
    if (dev_node->block_path)
        free(dev_node->block_path);
    if (!list_empty(&dev_node->parts))
		osndisk_free_parts(&dev_node->parts);
	free(dev_node);
	dev_node = NULL;
	return 1;
}

int osndisk_free_devs(struct list_head *dev_head)
{
	struct osn_disk *od_node, *od_tmp;

	if (!dev_head)
		return 0;

	list_for_each_entry_safe(od_node, od_tmp, dev_head, disk_list) {
		list_del(&od_node->disk_list);
		osndisk_free_one_dev(od_node);
	}

	return 1;
}

/*
 * Memory for the value is obtained with malloc,
 * don't forget free it
 */

static char *get_value(const char *file, int max_len)
{
	FILE *fp;
	int len;
	char *value;

	if (!file)
		return NULL;

	if (-1 == access(file, 0))
		return NULL;

	value = (char*)malloc(max_len);
	memset(value, 0, max_len);

	if (NULL == (fp = fopen(file, "r"))) {
		log_error("Failed to open %s", file);
		free(value);
		return NULL;
	}

	if (NULL == fgets(value, max_len, fp)) {
		log_error("Failed to get value from %s", file);
		free(value);
		fclose(fp);
		return NULL;
	}
	value[max_len-1] = 0; /* make sure line is end up with '\0' */
	len = strlen(value);
	if ((len > 0) && (*(value + len - 1) == '\n'))
		*(value + len - 1) = '\0';
	fclose(fp);
	sanitize_string(value);
	return value;
}

static int set_value(const char *file, const char *value)
{
	FILE *f;
	
	if (!file || !value)
		return 0;

	if (NULL == (f = fopen(file, "w")))
		return 0;
	if (-1 == fputs(value, f)) {
		fclose(f);
		return 0;
	}
	fclose(f);
	return 1;
}

/*
 * check if the device is direct-access
 */
static int dev_is_direct_access(const char *device)
{
	char dev_type[MAX_NAME_LEN];
	char *type_value;

	if (!device)
		return E_POINTER_NONE;

	snprintf(dev_type, MAX_NAME_LEN, "%s/type", device);
	type_value = get_value(dev_type, MAX_ATTR_LEN);
	if (type_value && !strcmp(type_value, "0")) {
		free(type_value);
		return 1;
	}

	free(type_value);
	return 0;
}

/*
 * Memory for the string of target is obtained with malloc,
 * don't forget to free it
 */
static char *get_target(hctl_t *hctl)
{
	int iscsi_ssn_idx, num, i;
	struct dirent **filelist;
	char tgt_dir[MAX_NAME_LEN]; /* /sys/class/fc_transprt or /sys/class/iscsi_host */
	char attr_file[MAX_NAME_LEN];
	char *attr_buf; /* iqn.* or wwn */

	if (!hctl)
		return NULL;

	/* step 1. try to get fc target */
	snprintf(attr_file, MAX_NAME_LEN, "%s/target%d:%d:%d/port_name",
		SYS_CLASS_FC_TRANSPORT, hctl->h, hctl->c, hctl->t);
	if ((attr_buf = get_value(attr_file, MAX_NAME_LEN)))
		return attr_buf;

	/* step 2. try to get iscsi target */
	snprintf(tgt_dir, MAX_NAME_LEN, "%s/host%d/device",
		SYS_CLASS_ISCSI_HOST, hctl->h);
	if (-1 == (num = scandir(tgt_dir, &filelist, filter, alphasort)))
		return NULL;
	iscsi_ssn_idx = -1;
	for (i = 0; i < num; i++) {
		if (!strncmp(filelist[i]->d_name, "session", strlen("session")))
			iscsi_ssn_idx = atoi(filelist[i]->d_name+strlen("session"));
		free(filelist[i]);
	}
	free(filelist);
	if (iscsi_ssn_idx == -1)
		return NULL;

	/* rhel 6.x */
	snprintf(attr_file, MAX_NAME_LEN,
		"%s/session%d/iscsi_session/session%d/targetname",
		tgt_dir, iscsi_ssn_idx, iscsi_ssn_idx);
	if (access(attr_file, 0) != -1) {
		if ((attr_buf = get_value(attr_file, MAX_NAME_LEN)))
			return attr_buf;
	}
	/* rhel 5.x */
	snprintf(attr_file, MAX_NAME_LEN,
		"%s/session%d/iscsi_session:session%d/targetname",
		tgt_dir, iscsi_ssn_idx, iscsi_ssn_idx);
	if (access(attr_file, 0) != -1) {
		if ((attr_buf = get_value(attr_file, MAX_NAME_LEN)))
			return attr_buf;
	}

	return NULL;
}

/**
 * dir such as '/dev/sda1'
 */
struct osn_part *osndisk_get_one_part(const char *dir)
{/*{{{*/
	FILE *fp;
	struct statvfs vfsd;
	struct osn_part *osnp = NULL;
	char buf[MAX_NAME_LEN];
	char name[MAX_NAME_LEN];
	char part_name[MAX_NAME_LEN];
	char mountpoint[MAX_NAME_LEN]; /* save mountpoint in /proc/mounts */
	int is_mounted = 0;
	uint64_t part_size;
	blkid_cache cache = NULL;
	blkid_dev dev;
	blkid_tag_iterate iter;
	const char *type, *value;

	if (!dir)
		return NULL;

	/* step 1. get uuid & fs type from libblkid api*/
	osnp = (struct osn_part*)malloc(sizeof (*osnp));
	if (!osnp) {
		log_error("Failed to allocate memory");
		return NULL;
	}
	memset(osnp, 0, sizeof (*osnp));

	osnp->name = strdup(dir);
   osnp->block_name = strdup(osnp->name); // Streamer 6.3 multipath device.
	if (blkid_get_cache(&cache, NULL) < 0) {
		log_error("Failed to open %s", dir);
		goto err;
	}
	dev = blkid_get_dev(cache, dir, BLKID_DEV_NORMAL);
	if (dev) {
		iter = blkid_tag_iterate_begin(dev);
		while (blkid_tag_next(iter, &type, &value) == 0) {
			if (!strcmp(type, "UUID"))
				osnp->uuid = strdup(value);
			else if (!strcmp(type, "TYPE"))
				osnp->fstype = strdup(value);
		}
		blkid_tag_iterate_end(iter);
	}
	blkid_put_cache(cache);

	/* step 2. get partition size */

	/* step 2.1 check if partition be mounted */
	if ((fp = fopen(PROC_MOUNTS, "r")) == NULL) {
		log_error("Failed to open %s", PROC_MOUNTS);
		goto out;
	}
	while (!feof(fp)) {
		fgets(buf, MAX_NAME_LEN, fp);
		if (sscanf(buf, "%s %s %*s", name, mountpoint) != 2)
			continue;
		if (!strcmp(name, dir)) {
			is_mounted = 1;
			break;
		}
	}
	fclose(fp);

	/* step 2.2 get partition attr */
	if (is_mounted) {
		if (statvfs(mountpoint, &vfsd) < 0) {
			log_error("statvfs(): %m");
			goto out;
		}
		osnp->mountpoint = strdup(mountpoint);
		/* total size, unit: Byte */
		osnp->size = vfsd.f_bsize * vfsd.f_blocks;
		/* used size, unit:Byte */
		osnp->used = vfsd.f_bsize * (vfsd.f_blocks - vfsd.f_bavail);
	} else {
		sscanf(dir, "/dev/%s", part_name);
		if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
			log_error("Failed to open %s", PROC_PARTITIONS);
			goto out;
		}
		while (!feof(fp)) {
			fgets(buf, MAX_NAME_LEN, fp);
			if (!strstr(buf, part_name))
				continue;
			if ((sscanf(buf, "%*s %*s %"PRIu64" %*s", &part_size)) != 1) {
				log_error("Failed to get size of %s", dir);
				break;
			}
			/* part_size's unit is KB */
			osnp->size = part_size * 1024;
			break;
		}
		fclose(fp);
	}

out:
	return osnp;
err:
	if (osnp)
		osndisk_free_one_part(osnp);
	return NULL;
}/*}}}*/

struct osn_part *osndisk_get_one_cciss_part(const char *dir)
{/*{{{*/
	FILE *fp;
	struct statvfs vfsd;
	struct osn_part *osnp = NULL;
	char buf[MAX_NAME_LEN];
	char name[MAX_NAME_LEN];
	char part_name[MAX_NAME_LEN];
	char mountpoint[MAX_NAME_LEN]; /* save mountpoint in /proc/mounts */
	int is_mounted = 0;
	uint64_t part_size;
	blkid_cache cache = NULL;
	blkid_dev dev;
	blkid_tag_iterate iter;
	const char *type, *value;

	if (!dir)
		return NULL;

	/* step 1. get uuid & fs type from libblkid api*/
	osnp = (struct osn_part*)malloc(sizeof (*osnp));
	if (!osnp) {
		log_error("Failed to allocate memory");
		return NULL;
	}
	memset(osnp, 0, sizeof (*osnp));

	osnp->name = strdup(dir);

	if (blkid_get_cache(&cache, NULL) < 0) {
		log_error("Failed to open %s", dir);
		goto err;
	}
	dev = blkid_get_dev(cache, dir, BLKID_DEV_NORMAL);
	if (dev) {
		iter = blkid_tag_iterate_begin(dev);
		while (blkid_tag_next(iter, &type, &value) == 0) {
			if (!strcmp(type, "UUID"))
				osnp->uuid = strdup(value);
			else if (!strcmp(type, "TYPE"))
				osnp->fstype = strdup(value);
		}
		blkid_tag_iterate_end(iter);
	}
	blkid_put_cache(cache);

	/* step 2. get partition size */

	/* step 2.1 check if partition be mounted */
	if ((fp = fopen(PROC_MOUNTS, "r")) == NULL) {
		log_error("Failed to open %s", PROC_MOUNTS);
		goto out;
	}
	while (!feof(fp)) {
		fgets(buf, MAX_NAME_LEN, fp);
		if (sscanf(buf, "%s %s %*s", name, mountpoint) != 2)
			continue;
		if (!strcmp(name, dir)) {
			is_mounted = 1;
			break;
		}
	}
	fclose(fp);

	/* step 2.2 get partition attr */
	if (is_mounted) {
		if (statvfs(mountpoint, &vfsd) < 0) {
			log_error("statvfs(): %m");
			goto out;
		}
		osnp->mountpoint = strdup(mountpoint);
		/* total size, unit: Byte */
		osnp->size = vfsd.f_bsize * vfsd.f_blocks;
		/* used size, unit:Byte */
		osnp->used = vfsd.f_bsize * (vfsd.f_blocks - vfsd.f_bavail);
	} else {
		sscanf(dir, "/dev/cciss/%s", part_name);
		if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
			log_error("Failed to open %s", PROC_PARTITIONS);
			goto out;
		}
		while (!feof(fp)) {
			fgets(buf, MAX_NAME_LEN, fp);
			if (!strstr(buf, part_name))
				continue;
			if ((sscanf(buf, "%*s %*s %"PRIu64" %*s", &part_size)) != 1) {
				log_error("Failed to get size of %s", dir);
				break;
			}
			/* part_size's unit is KB */
			osnp->size = part_size * 1024;
			break;
		}
		fclose(fp);
	}

out:
	return osnp;
err:
	if (osnp)
		osndisk_free_one_part(osnp);
	return NULL;
}/*}}}*/

static struct osn_part *osndisk_get_one_citrix_part(const char *dir) {
    FILE *fp;
    struct statvfs vfsd;
    struct osn_part *osnp = NULL;
    blkid_dev dev;
    blkid_cache cache;
    blkid_tag_iterate iter;
    char buff[MAX_NAME_LEN];
    char name[MAX_NAME_LEN];
    char part_name[MAX_NAME_LEN];
    char mountpoint[MAX_NAME_LEN];
    const char *type, *value;
    int is_mounted;
    uint64_t part_size;

    if (! dir) {
        return NULL;
    }

    osnp = calloc(1, sizeof(struct osn_part));
    if (!osnp) {
        return NULL;
    }

    osnp->name = strdup(dir);

    if (blkid_get_cache(&cache, NULL) < 0) {
        goto err;
    }
    dev = blkid_get_dev(cache, dir, BLKID_DEV_NORMAL);
    if (dev) {
        iter = blkid_tag_iterate_begin(dev);
        while(blkid_tag_next(iter, &type, &value) == 0) {
            if (!strcmp(type, "UUID")) {
                osnp->uuid = strdup(value);
            }
            else if (!strcmp(type, "TYPE")) {
                osnp->fstype = strdup(value);
            }
        }
        blkid_tag_iterate_end(iter);
    }
    blkid_put_cache(cache);

    if ((fp = fopen(PROC_MOUNTS, "r")) == NULL) {
        log_error("Failed to open %s", PROC_MOUNTS);
        goto err;
    }
    while (!feof(fp)) {
        fgets(buff, MAX_NAME_LEN, fp);
        if (sscanf(buff, "%s %s %*s", name, mountpoint) != 2) {
            continue;
        }
        if (!strcmp(name, dir)) {
            is_mounted = 1;
            break;
        }
    }
    fclose(fp);

    if (is_mounted) {
        if (statvfs(mountpoint, &vfsd) < 0) {
           goto out;
        }
        osnp->mountpoint = strdup(mountpoint);
        osnp->size = vfsd.f_bsize * vfsd.f_blocks;
        osnp->used = vfsd.f_bsize * (vfsd.f_blocks - vfsd.f_bavail);
    } else {
        sscanf(dir, "/dev/%s", part_name);
        if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
            goto out;
        }
        while(!feof(fp)) {
            fgets(buff, MAX_NAME_LEN, fp);
            if (!strstr(buff, part_name)) {
                continue;
            }
            if ((sscanf(buff, "%*s %*s %"PRIu64" %*s", &part_size)) != 1) {
                break;
            }
            osnp->size = part_size * 1024;
            break;
        }
        fclose(fp);
    }
out:
    return osnp;
err:
    if(osnp) {
        osndisk_free_one_part(osnp);
    }
    return NULL;
}

/**
 * dir: such as '/dev/sda'
 * parts: list of disk's partitions
 * return partition's quantity 
 */
int osndisk_get_parts(const char *dir, struct list_head *parts)
{/*{{{*/
	FILE *fp;
	struct osn_part *opart;
	char buf[MAX_NAME_LEN];
	char part_name[MAX_NAME_LEN];
	char part_dir[MAX_NAME_LEN];
	char disk_name[MAX_NAME_LEN];
	int ret, len, sum = 0;

	if (!dir || !parts) {
		log_error("Input parameter must be non-NULL");
		return -1;
	}

	ret = sscanf(dir, "/dev/%s", disk_name);
	if (ret != 1) {
		log_error("Invalid path: %s", dir);
		return 0;
	}

	if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
		log_error("Failed to open %s", PROC_PARTITIONS);
		return 0;
	}
	while (!feof(fp)) {
		memset(buf, 0, sizeof (buf));
		fgets(buf, MAX_NAME_LEN, fp);
		if ((sscanf(buf, "%*s %*s %*s %s", part_name)) != 1)
			continue;
		len = strlen(part_name);

		/* ends in a digit, clearly a partition */
		if (strstr(part_name, disk_name) && isdigit(part_name[len-1])) {
			snprintf(part_dir, MAX_NAME_LEN, "/dev/%s", part_name);
			opart = osndisk_get_one_part(part_dir);
			if (!opart)
				continue;

			list_add_tail(&opart->list, parts);
			sum++;
		}
	}
	fclose(fp);
	return sum;
}/*}}}*/

int osndisk_get_cciss_parts(const char *dir, struct list_head *parts)
{/*{{{*/
	FILE *fp;
	struct osn_part *opart;
	char buf[MAX_NAME_LEN];
	char part_name[MAX_NAME_LEN];
	char part_dir[MAX_NAME_LEN];
	char disk_name[MAX_NAME_LEN];
	int ret, len, sum = 0;

	if (!dir || !parts) {
		log_error("Input parameter must be non-NULL");
		return -1;
	}

	ret = sscanf(dir, "/dev/cciss/%s", disk_name);
	if (ret != 1) {
		log_error("Invalid  path: %s", dir);
		return 0;
	}

	if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
		log_error("Failed to open %s", PROC_PARTITIONS);
		return 0;
	}

	while (!feof(fp)) {
		memset(buf, 0, sizeof(buf));
		fgets(buf, MAX_NAME_LEN, fp);
		if ((sscanf(buf, "%*s %*s %*s %s", part_name)) != 1) 
			continue;
		len = strlen(part_name);

		/* ends in a digit, clearly a partition */
		if (strstr(part_name, disk_name) && isdigit(part_name[len-1]) && part_name[len-2] == 'p') {
			snprintf(part_dir, MAX_NAME_LEN, "/dev/%s", part_name);
			opart = osndisk_get_one_cciss_part(part_dir);
			if (!opart)
				continue;
			list_add_tail(&opart->list, parts);
			sum++;
		}
	}
	fclose(fp);
	return sum;
}/*}}}*/

static int osndisk_get_citrix_parts(const char *dir, struct list_head *parts) {
    FILE *fp;
    int ret, len, sum;
    char buff[MAX_NAME_LEN];
    char part_dir[MAX_NAME_LEN];
    char part_name[MAX_NAME_LEN];
    char disk_name[MAX_NAME_LEN] = {0};
    struct osn_part *opart;

    if (! dir || ! parts) {
        return -1;
    }

    sum = 0;
    ret = sscanf(dir, "/dev/%s", disk_name);
    if (ret != 1) {
        log_error("Invalid path: %s", dir);
        return 0;
    }

    if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
        log_error("Failed to open %s", PROC_PARTITIONS);
        return 0;
    }
    
    while (! feof(fp)) {
        memset(buff, 0, MAX_NAME_LEN);
        fgets(buff, MAX_NAME_LEN, fp);
        if ((sscanf(buff, "%*s %*s %*s %s", part_name)) != 1) {
            continue;
        }
        len = strlen(part_name);

        if (strstr(part_name, disk_name) && isdigit(part_name[len -1])) {
            snprintf(part_dir, MAX_NAME_LEN, "/dev/%s", part_name);
            opart = osndisk_get_one_citrix_part(part_dir);
            if (!opart) {
                continue;
            }
            list_add_tail(&opart->list, parts);
            sum ++;
        }
    }
    fclose(fp);
    return sum;
}

/**
 * dir: such as '/sys/class/..'
 * flag: 1 - get partition attribute of this disk; 0 - don't do it
 */
static struct osn_disk *sysfs_get_one_dev(const char *dir, int flag)
{/*{{{*/
	char sub_dir[MAX_NAME_LEN];
	char attr_file[MAX_NAME_LEN];
	char *attr_buf;
	struct dirent **filelist, **sub_filelist;
	struct osn_disk *odisk;
	int num, sub_num, i;

	if (!dir)
		return NULL;

	if (!(odisk = malloc(sizeof(struct osn_disk))))
		return NULL;
	memset(odisk, 0, sizeof(*odisk));
	INIT_LIST_HEAD(&odisk->parts);

	/* fill hctl domain */
	if (4 != sscanf(dir, "%*[^0-9]%d:%d:%d:%d", &odisk->hctl.h,
		&odisk->hctl.c, &odisk->hctl.t, &odisk->hctl.l)) {
		osndisk_free_one_dev(odisk);
		return NULL;
	}

	/* fill target domain */
	odisk->target = get_target(&odisk->hctl);

	/* fill other domain */
	if(-1 == (num=scandir(dir, &filelist, filter, alphasort))) {
		osndisk_free_one_dev(odisk);
		return NULL;
	}
	for (i = 0; i < num; i++) {
		static char tmp_file[MAX_NAME_LEN];

		memset(tmp_file, 0, sizeof (tmp_file));
		snprintf(tmp_file, MAX_NAME_LEN, "%s/%s", dir, filelist[i]->d_name);
		if (-1 == access(tmp_file, 0))
			goto bad;
      
		if (!strcmp(filelist[i]->d_name, "block")) {
			/********************* rhel 6.x *******************/
			snprintf(sub_dir, MAX_NAME_LEN, "%s/block", dir);
			/* fill device domain */
			if (!(odisk->dev_name = (char *)calloc(1, MAX_NAME_LEN))) {
				log_error("Failed to allocate memory");
				goto bad;
			}
			if (!(odisk->dev_path = (char *)calloc(1, MAX_NAME_LEN))) {
				log_error("Failed to allocate memory");
				goto bad;
			}

			sub_num = scandir(sub_dir, &sub_filelist, filter, NULL);
            if (-1 == sub_num){
                goto bad;
            }
			if (1 != sub_num) {
				for (i = 0; i < sub_num; i++)
					free(sub_filelist[i]);
				free(sub_filelist);
				goto bad;
			}

			strncpy(odisk->dev_name, sub_filelist[0]->d_name, MAX_NAME_LEN);
         		odisk->block_name = strdup(odisk->dev_name);
			snprintf(odisk->dev_path, MAX_NAME_LEN, "/dev/%s", odisk->dev_name);
        	 	odisk->block_path = strdup(odisk->dev_path);
			free(sub_filelist[0]);
			free(sub_filelist);

			/* fill size domain */
#ifdef FROM_SYSFS
			snprintf(attr_file, MAX_NAME_LEN, "%s/%s/size",
				sub_dir, odisk->dev_name);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			odisk->size = atoi_large(attr_buf);
			free(attr_buf);
#else
			/* get count of sectors */
			odisk->size = scsi_read_capacity(odisk->dev_path) / 512;
#endif
		} else if (strstr(filelist[i]->d_name, "block:")) {
			/********************* rhel 5.x *******************/
			snprintf(sub_dir, MAX_NAME_LEN, "%s/%s", dir, filelist[i]->d_name);

			/* fill device name & path domain */
			if (!(odisk->dev_name = (char *)calloc(1, MAX_NAME_LEN))) {
				log_error("Failed to allocate memory");
				goto bad;
			}
			if (!(odisk->dev_path = (char *)calloc(1, MAX_NAME_LEN))) {
				log_error("Failed to allocate memory");
				goto bad;
			}
			sscanf(filelist[i]->d_name, "block:%s", odisk->dev_name);
         		odisk->block_name = strdup(odisk->dev_name);
			snprintf(odisk->dev_path, MAX_NAME_LEN, "/dev/%s", odisk->dev_name);
         		odisk->block_path = strdup(odisk->dev_path);

			/* fill size domain */
#ifdef FROM_SYSFS
			snprintf(attr_file, MAX_NAME_LEN, "%s/size", sub_dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			odisk->size = atoi_large(attr_buf);
			free(attr_buf);
#else
			/* get count of sectors */
			odisk->size = scsi_read_capacity(odisk->dev_path) / 512;
#endif
		} else if (!strcmp(filelist[i]->d_name, "vendor")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/vendor", dir);
			odisk->vendor = get_value(attr_file, MAX_ATTR_LEN);
		} else if (!strcmp(filelist[i]->d_name, "model")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/model", dir);
			odisk->model = get_value(attr_file, MAX_ATTR_LEN);
		} else if (!strcmp(filelist[i]->d_name, "rev")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/rev", dir);
			odisk->revision = get_value(attr_file, MAX_ATTR_LEN);
		} else if (!strcmp(filelist[i]->d_name, "queue_type")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/queue_type", dir);
			odisk->queue_type = get_value(attr_file, MAX_ATTR_LEN);
		} else if (!strcmp(filelist[i]->d_name, "queue_depth")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/queue_depth", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->queue_depth = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "type")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/type", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->type = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "scsi_level")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/scsi_level", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->scsi_level = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "device_blocked")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/device_blocked", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->device_blocked = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "timeout")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/timeout", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->timeout = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "iocounterbits")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/iocounterbits", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				odisk->iocounterbits = atoi(attr_buf);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "iodone_cnt")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/iodone_cnt", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				sscanf(attr_buf, "0x%x", &odisk->iodone_cnt);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "ioerr_cnt")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/ioerr_cnt", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				sscanf(attr_buf, "0x%x", &odisk->ioerr_cnt);
			free(attr_buf);
		} else if (!strcmp(filelist[i]->d_name, "iorequest_cnt")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/iorequest_cnt", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf)
				sscanf(attr_buf, "0x%x", &odisk->iorequest_cnt);
			free(attr_buf);
#if 0
		} else if (!strcmp(filelist[i]->d_name, "state")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/state", dir);
			attr_buf = get_value(attr_file, MAX_ATTR_LEN);
			if (attr_buf && !strcmp(attr_buf, "running"))
				odisk->online = 1;
			free(attr_buf);
#endif
		}

	}

	for (i = 0; i < num; i++)
		free(filelist[i]);
	free(filelist);

	if (odisk->dev_path && scsi_tur(odisk->dev_path))
		odisk->online = 1;

	/* get all partitions' information of this disk.
	 * if disk is Solution continue, avoic I/O error */
	if ((flag == GET_PARTITION) && odisk->dev_path && odisk->online && strcmp(odisk->model, "Solution")) {
		osndisk_get_parts(odisk->dev_path, &odisk->parts);
	}
	/* if osndisk name dev_path.. is NULL,
	 * free disk and return NULL;
	 */
	if (!odisk->block_name || !odisk->dev_name || !odisk->block_path || !odisk->dev_path) {
//		log_error("Get disk name or path failed.");
		osndisk_free_one_dev(odisk);
        return NULL;
	}
	return odisk;

bad:
	for (i = 0; i < num; i++)
		free(filelist[i]);
	free(filelist);

   if (odisk) {
       osndisk_free_one_dev(odisk);
   }
	return NULL;
}/*}}}*/

static struct osn_disk *sysfs_get_one_cciss_dev(const char *dir, int flag)
{/*{{{*/
	//char sub_dir[MAX_NAME_LEN];
	char attr_file[MAX_NAME_LEN];
	//char *attr_buf;
	struct dirent **filelist;
	struct osn_disk *odisk;
	int num, i;

	if (!dir) {
		return NULL;
	}

	if ((odisk = calloc(1, sizeof(struct osn_disk))) == NULL) {
		return NULL;
	}

	INIT_LIST_HEAD(&odisk->parts);

	/* Get device path */
	if (!(odisk->dev_name = (char *)calloc(1, MAX_NAME_LEN))) {
		log_error("Failed to allocate memory");
		goto bad;
	}
	if (!(odisk->dev_path = (char *)calloc(1, MAX_NAME_LEN))) {
		log_error("Failed to allocate memory");
		free(odisk->dev_name);
		goto bad;
	}
	
	strncpy(odisk->dev_name, strstr(dir, "!")+1, MAX_NAME_LEN);
	*(strstr(odisk->dev_name, "/")) = '\0';

   odisk->block_name = strdup(odisk->dev_name);
	snprintf(odisk->dev_path, MAX_NAME_LEN, "/dev/cciss/%s", odisk->dev_name);
	odisk->block_path = strdup(odisk->dev_path);
	/* Fill size domain */
	odisk->size = scsi_read_capacity(odisk->dev_path) / 512;

	/* CCISS disk no hctl domain */
	/* CCISS target ? */
	if (-1 == (num = scandir(dir, &filelist, filter, alphasort))) {
		osndisk_free_one_dev(odisk);
		return NULL;
	}

	for (i = 0; i < num; i++) {
		static char tmp_file[MAX_NAME_LEN];

		memset (tmp_file, 0, sizeof(tmp_file));
		snprintf(tmp_file, MAX_NAME_LEN, "%s/%s", dir, filelist[i]->d_name);
		if (-1 ==  access(tmp_file, F_OK)) {
			goto bad;
		}
		
		/* Fiil vender domaiin */
		if (strcmp(filelist[i]->d_name, "vendor") == 0) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/vendor", dir);
			odisk->vendor = get_value(attr_file, MAX_ATTR_LEN);
		}
		/* Fill model domain */
		else if (strcmp(filelist[i]->d_name, "model") == 0) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/model", dir);
			odisk->model = get_value(attr_file, MAX_ATTR_LEN);
		}
		/* Fill rev domaiin */
		else if (!strcmp(filelist[i]->d_name, "rev")) {
			snprintf(attr_file, MAX_NAME_LEN, "%s/rev", dir);
			odisk->revision = get_value(attr_file, MAX_ATTR_LEN);
		}
		/* Compare with normal scsi device
		 * NO QUEUE TYPE
		 * NO QUEUE DEPTH
		 * NO TYPE
		 * NO SCSI LEVEL
		 * NO TIMEOUT
		 * NO IOCOUNTERBITS
		 * NO IODONE_CNT
		 * NO IOERROR_CNT
		 * NO IOREQUEST_CNT
		 */
	}

	for (i = 0; i < num; i++) {
		free(filelist[i]);
	}
	free(filelist);

	if (odisk->dev_path && scsi_tur(odisk->dev_path))
		odisk->online = 1;

	/* get all partitions' information of this disk */
	if ((flag == GET_PARTITION) && odisk->dev_path && odisk->online && strcmp(odisk->model, "Solution")) {
		osndisk_get_cciss_parts(odisk->dev_path, &odisk->parts);
	}
	if (!(odisk->dev_name) || !(odisk->dev_path)){
		osndisk_free_one_dev(odisk);
		return NULL;
	}

	if (!odisk->block_name || !odisk->dev_name || !odisk->block_path || !odisk->dev_path) {
//		log_error("Get disk name or path failed.");
		osndisk_free_one_dev(odisk);
        return NULL;
	}

	return odisk;

bad:
	for (i = 0; i < num; i++)
		free(filelist[i]);
	free(filelist);

	return NULL;

}/*}}}*/


static ssize_t sysfs_blocking_read(int fd, void *buff, size_t count) {
    ssize_t ioret;
    size_t offset, remain;

    if (fd < 0) {
        log_error("Invalid fd [%d].", fd);
        return -1;
    }
    if (buff == NULL) {
        log_error("Null buffer, cannot read.");
        return -1;
    }
    if (count == 0) {
        log_error("Invalid byte count: 0");
        return -1;
    }

    offset = 0;
    remain = count;
    while (remain > 0) {
        ioret = read(fd, buff + offset, remain);
        if (ioret < 0) {
            if (ioret == EAGAIN || ioret == EINTR) {
                continue;
            } else {
                return -1;
            }
        }
        else if (ioret == 0) {
            return offset;
        }
        offset += ioret;
        remain -= ioret;
    }
    return offset;
}

static int sysfs_is_device_available(const char *path) {
    int fd;
    void *buff;
    ssize_t ioret;

    if (path == NULL) {
        return 0;
    }

    buff = NULL;
    if (posix_memalign(&buff, 512, 512) != 0) {
        log_error("Failed to allocate aligned RAM for buffer.");
        return 0;
    }
    
    fd = -1;
    fd = open(path, O_DIRECT, O_RDONLY);
    if (fd < 0) {
        log_error("Failed to open device [%s].", path);
        goto err;
    }

    ioret = sysfs_blocking_read(fd, buff, 512);
    if (ioret != 512) {
        log_error("Failed to read device [%s], "
                "it doesn't seem to be available.", path);
        goto err;
    }
    
    free(buff);
    close(fd);
    return 1;     
err:
    if (buff) {
        free(buff);
    }
    if (fd >= 0) {
        close(fd);
    }
    return 0;
}

static struct osn_disk *sysfs_get_one_citrix_dev(const char *dir, int flag) {

    int num, i;
    struct dirent **filelist;
    struct osn_disk *odisk;
    char filename[MAX_NAME_LEN];
    char *last_slash, *disk_attr;
    uint64_t disk_size;
    size_t path_len;

    if (! dir) {
        return NULL;
    }

    path_len = strlen(dir);
    if (path_len == 0) {
        log_error("Empety subclass path, cannot access sysfs.");
        return NULL;
    }
    if (path_len > 0 && dir[path_len - 1] == '/') {
        log_error("Invalid device path [%s].", dir);
        return NULL;
    }

    /* Initialization of osn_disk. */
    odisk = calloc(1, sizeof(struct osn_disk));
    if (odisk == NULL) {
        return NULL;
    }
    INIT_LIST_HEAD(&odisk->parts);

    if ((odisk->dev_name = calloc(MAX_NAME_LEN, sizeof(char))) == NULL) {
        log_error("Failed to allocate RAM for device name.");
        goto error;
    }
    if ((odisk->dev_path = calloc(MAX_NAME_LEN, sizeof(char))) == NULL) {
        log_error("Failed to allocate RAM for device path.");
        goto error;
    }
    if ((odisk->vendor = calloc(MAX_NAME_LEN, sizeof(char))) == NULL) {
        log_error("Failed to allocate RAM for device vendor.");
        goto error;
    }

    /* Get device name.
     * e.g. Extract the name 'xvda' from '/sys/block/xvda'. */
    last_slash = strrchr(dir, '/');
    if (last_slash == NULL) {
        log_warning("Cannot find / in path [%s], use it as device name.", dir);
        snprintf(odisk->dev_name, MAX_NAME_LEN, "%s", dir);
    } else {
        snprintf(odisk->dev_name, MAX_NAME_LEN, "%s", last_slash + 1);
    }
         
    /* Get device path. */
    snprintf(odisk->dev_path, MAX_NAME_LEN, "/dev/%s", odisk->dev_name);

    log_debug(DEBUG_VERBOSE, "Read device name: %s", odisk->dev_name);
    log_debug(DEBUG_VERBOSE, "Read device path: %s", odisk->dev_path);

    /* Get other device informations */ 
    num = scandir(dir, &filelist, filter, alphasort);
    if (num < 0) {
        goto error;
    }

    for (i = 0; i < num; i ++) {

        memset(filename, 0, MAX_NAME_LEN);
        snprintf(filename, MAX_NAME_LEN, "/sys/block/%s/%s",
                odisk->dev_name, filelist[i]->d_name);

        if (access(filename, F_OK) < 0) {
            continue;
        }

        /* read size */
        if (strcmp(filelist[i]->d_name, "size") == 0) {
            disk_attr = get_value(filename, MAX_ATTR_LEN);
            sscanf(disk_attr, "%"SCNu64, &disk_size);
            odisk->size = disk_size; /* Number of sectors. */
            log_debug(DEBUG_VERBOSE, "Read device size %"PRIu64, odisk->size);
            free(disk_attr); 
        }
        /* Set vendor */
        snprintf(odisk->vendor, MAX_NAME_LEN, "%s", "Citrix Xen");

        /* XXX: NO OTHER ATTRIBUTES */
    }
    
    for (i = 0; i < num; i ++) {
        free(filelist[i]);
    }
    free(filelist);

    /* The device doesn't accept SCSI command, no TUR performed. */
    /* if (odisk->dev_path && scsi_tur(odisk->dev_path)) { */
    if (odisk->dev_path) { 
        odisk->online = sysfs_is_device_available(odisk->dev_path);
    }

    if (flag ==  GET_PARTITION && odisk->dev_path && odisk->online) {
        osndisk_get_citrix_parts(odisk->dev_path, &odisk->parts);
    }
    if (!(odisk->dev_name) || !(odisk->dev_path)){
	osndisk_free_one_dev(odisk);
	return NULL;
    }
    return odisk;
error:
    osndisk_free_one_dev(odisk);
    return NULL;
}

/*
 * /etc/multipath.conf check.
 *
 * @ -1: no file. 0: file exist.
 */
//int is_multipath_conf_exist()
//{
//   if (access(MULTIPATH_CONF_FILE, F_OK)) {
//       log_debug(DEBUG_VERBOSE, "Failed to access multipath.conf file.");
//       return -1;
//   }
//   return 0;
//}

/*
 * dir such as '/dev/mapper/mpatha'
 */
struct osn_part *osndisk_get_mpath_one_parts(const char *dir)
{	
   FILE *fp;
	struct statvfs vfsd;
	struct osn_part *osnp = NULL;
	char buf[MAX_NAME_LEN];
	char name[MAX_NAME_LEN];
	char part_name[MAX_NAME_LEN];
	char mountpoint[MAX_NAME_LEN]; /* save mountpoint in /proc/mounts */
	int is_mounted = 0;
	uint64_t part_size;
	blkid_cache cache = NULL;
	blkid_dev dev;
	blkid_tag_iterate iter;
	const char *type, *value;
   int ret = 0;
   char file_dm_name[MAX_NAME_LEN];
	if (!dir)
		return NULL;

	/* step 1. get uuid & fs type from libblkid api*/
	osnp = (struct osn_part*)malloc(sizeof (*osnp));
	if (!osnp) {
		log_error("Failed to allocate memory");
		return NULL;
	}
	memset(osnp, 0, sizeof (*osnp));

	osnp->name = strdup(dir);

	if (blkid_get_cache(&cache, NULL) < 0) {
		log_error("Failed to open %s", dir);
		goto err;
	}
	dev = blkid_get_dev(cache, dir, BLKID_DEV_NORMAL);
	if (dev) {
		iter = blkid_tag_iterate_begin(dev);
		while (blkid_tag_next(iter, &type, &value) == 0) {
			if (!strcmp(type, "UUID"))
				osnp->uuid = strdup(value);
			else if (!strcmp(type, "TYPE"))
				osnp->fstype = strdup(value);
		}
		blkid_tag_iterate_end(iter);
	}
	blkid_put_cache(cache);

	/* step 2. get partition size */

	/* step 2.1 check if partition be mounted */
	if ((fp = fopen(PROC_MOUNTS, "r")) == NULL) {
		log_error("Failed to open %s", PROC_MOUNTS);
		goto out;
	}
	while (!feof(fp)) {
		fgets(buf, MAX_NAME_LEN, fp);
		if (sscanf(buf, "%s %s %*s", name, mountpoint) != 2)
			continue;
		if (!strcmp(name, dir)) {
			is_mounted = 1;
			break;
		}
	}
	fclose(fp);

	/* step 2.2 get partition attr */
	if (is_mounted) {
		if (statvfs(mountpoint, &vfsd) < 0) {
			log_error("statvfs(): %m");
			goto out;
		}
		osnp->mountpoint = strdup(mountpoint);
		/* total size, unit: Byte */
		osnp->size = vfsd.f_bsize * vfsd.f_blocks;
		/* used size, unit:Byte */
		osnp->used = vfsd.f_bsize * (vfsd.f_blocks - vfsd.f_bavail);
	} else {
      
      ret = readlink(dir, part_name, MAX_NAME_LEN - 1);
      if (ret < 0 || (ret >= MAX_NAME_LEN-1)) {
         log_error("Get dm partition link failed.");
         return NULL; 
      }
      part_name[ret] = '\0'; //dm_name such as ../dm-3.

		if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
			log_error("Failed to open %s", PROC_PARTITIONS);
			goto out;
		}
		while (!feof(fp)) {
			fgets(buf, MAX_NAME_LEN, fp);
         
         if ((sscanf(buf, "%*s %*s %*s %s", file_dm_name)) != 1)
            continue;
			if (!strstr(part_name, file_dm_name))
				continue;
			if ((sscanf(buf, "%*s %*s %"PRIu64" %*s", &part_size)) != 1) {
				log_error("Failed to get size of %s", dir);
				break;
			}
         osnp->block_name = strdup(file_dm_name);

			/* part_size's unit is KB */
			osnp->size = part_size * 1024;
			break;
		}
		fclose(fp);
	}

out:
	return osnp;
err:
	if (osnp)
		osndisk_free_one_part(osnp);
	return NULL;

}
/*
 * Get multipath disk part
 *
 */
int osndisk_get_mpath_parts(const char *dir, struct list_head *parts)
{
   FILE *fp;
   struct osn_part *opart;
   char buf[MAX_NAME_LEN];
   char part_name[MAX_NAME_LEN];
   char dir_name[MAX_NAME_LEN];
   char dm_name[MAX_NAME_LEN];
   char file_dm_name[MAX_NAME_LEN];
   int ret, len, sum = 0;
   int num = -1, i;
   struct dirent **filelist;
   //name: maptha
   if(!dir || !parts) {
      log_error("Input parameter must be non-NULL.");
      return -1;
   }
   if (strstr(dir, MULTIPATH_DIR_5)) {
      strncpy(dir_name, MULTIPATH_DIR_5, MAX_NAME_LEN);
   }
   else if (strstr(dir, MULTIPATH_DIR_6)) {
      strncpy(dir_name, MULTIPATH_DIR_6, MAX_NAME_LEN);
   }
   else {
      log_error("Failed to get multipath dirtecory.");
   }
   
   if (-1 == (num = scandir(dir_name, &filelist, filter, alphasort))) {
      return 0;
   }
   for (i = 0; i< num; i++) {
      snprintf(part_name, MAX_NAME_LEN, "%s/%s",
            dir_name, filelist[i]->d_name);
      len = strlen(part_name);// part_name such as /dev/mapper/mpathap1
      /*if part_name is dir's partition.*/
      if (strstr(part_name, dir) && isdigit(part_name[len-1])) {
         ret = readlink(part_name, dm_name, MAX_NAME_LEN - 1);
         if (ret < 0 || (ret >= MAX_NAME_LEN-1)) {
            log_error("Get dm partition link failed.");
            continue;
         }
         dm_name[ret] = '\0'; //dm_name such as ../dm-3.

         if ((fp = fopen(PROC_PARTITIONS, "r")) == NULL) {
            log_error("Failed to open %s", PROC_PARTITIONS);
            continue;
         }
         while (!feof(fp)) {
            memset(buf, 0, sizeof (buf));
            fgets(buf, MAX_NAME_LEN, fp);
            if ((sscanf(buf, "%*s %*s %*s %s", file_dm_name)) != 1)
               continue;
            if (strstr(dm_name, file_dm_name)) {
               opart = osndisk_get_mpath_one_parts(part_name);
               if (!opart)
                  continue;
               //log_info("dm part:%s %s", opart->name, opart->block_name);
               list_add_tail(&opart->list, parts);
               sum++;
            }
         }
         fclose(fp);
      }
      free(filelist[i]);
   }
   free(filelist);
   return 0;
}
/*
 * Add multipath disk to osndisk.
 *
 * @-1:failed   0:success.
 */
//static int osndisk_merge_mpath_devs(struct list_head *dev_head, struct list_head *odmdisk, int flag)
//{
//   if (!dev_head || !odmdisk) 
//      return 0;
//   struct osn_dmdisk *ite_dmdisk;
//   struct dm_src_disk *dmsrcdisk;
//   struct osn_disk *odisk;
//   struct osn_disk *ite_disk, *ite_disk_safe;
//   char blockpath[MAX_NAME_LEN] = {0};
//   int found = 0;
//
//   list_for_each_entry(ite_dmdisk, odmdisk, list) {
//      log_debug(DEBUG_VERBOSE, "Start to list all of multipath.");
//      if (!(odisk = calloc(1, sizeof(struct osn_disk))))
//         continue;
//      INIT_LIST_HEAD(&odisk->parts);
//      odisk->hctl.h = 0;
//      odisk->hctl.c = 0;
//      odisk->hctl.t = 0;
//      odisk->hctl.l = 0;
//
//      odisk->dev_name = strdup(ite_dmdisk->dev_name);// mpatha
//      odisk->dev_path = strdup(ite_dmdisk->dev_path);///dev/mapper/mpatha
//      odisk->block_name = strdup(ite_dmdisk->dm_name); // dm-2
//      sprintf(blockpath, "/dev/%s", odisk->block_name); //Streamer 6.3  /dev/dm-3
//      odisk->block_path = strdup(blockpath);
//
//      list_for_each_entry(dmsrcdisk, &ite_dmdisk->src_disk, list) {
//         list_for_each_entry_safe(ite_disk, ite_disk_safe, dev_head, disk_list) {
//            if (strcmp(dmsrcdisk->name, ite_disk->dev_name) == 0) {
//               if ((found == 0) && (ite_disk->online == 1)) {
//                  odisk->size = ite_disk->size;
//                  odisk->vendor = strdup(ite_disk->vendor);
//                  odisk->model = strdup(ite_disk->model);
//                  odisk->revision = strdup(ite_disk->revision);
//                  odisk->queue_type = strdup(ite_disk->queue_type);
//                  odisk->online = ite_disk->online;
//                  found = 1;
//                  if (flag == GET_PARTITION) {
//                     osndisk_get_mpath_parts(odisk->dev_path, &odisk->parts);
//                  }
//               }
//               list_del(&ite_disk->disk_list);
//               osndisk_free_one_dev(ite_disk);
//            }
//         }
//      }
//      found = 0;
//      list_add_tail(&odisk->disk_list, dev_head);
//   }
//
//   return 0;
//}
/*
 * get devices which type is direct-access
 * flag: 1 - get partition attribute of this disk; 0 - don't do it
 */
int osndisk_get_devs(struct list_head *dev_head, int flag)
{
	struct dirent **filelist;
	char dev_dir[MAX_NAME_LEN]; /* /sys/class/scsi_devices */
	char dev_file[MAX_NAME_LEN]; /* /sys/class/scsi_device/<hctl> */
	struct osn_disk *odisk;
	int num, i, dest_num = 0;
   
   /*dm multipath*/
   struct list_head odmdisk;
   INIT_LIST_HEAD(&odmdisk);

	if (!dev_head)
		return 0;
	pthread_mutex_lock(&g_osndisk_mutex);
	/* Get narmal scsi disk for /sys/class/scsi_device type = 0 */
	strncpy(dev_dir, SYS_CLASS_SCSI_DEV, MAX_NAME_LEN);
	if(-1 == (num = scandir(dev_dir, &filelist, filter, alphasort))) {
		pthread_mutex_unlock(&g_osndisk_mutex);
		return 0;
	}
	for (i = 0; i < num; i++) {
		snprintf(dev_file, MAX_NAME_LEN, "%s/%s/device",
			dev_dir, filelist[i]->d_name);
		if (dev_is_direct_access(dev_file) &&
			(odisk = sysfs_get_one_dev(dev_file, flag))) {
			list_add_tail(&odisk->disk_list, dev_head);
			dest_num++;
		}
		free(filelist[i]);
	}
	free(filelist);

	/* Get cciss HP Smart Array Controller scsi disk, This controller do not
	 * register scsi device to system.
         * So we just can find it from /sys/class/block or /sys/class/bus/cciss  */
	strncpy(dev_dir, SYS_BLOCK_CCISS, MAX_NAME_LEN);
	if (-1 == (num = scandir(dev_dir, &filelist, filter_cciss_block, alphasort))) {
		pthread_mutex_unlock(&g_osndisk_mutex);
		return 0;
	}
	/*printf("cciss blocks:%d\n", num);*/
	for (i = 0; i < num; i++) {
		snprintf(dev_file, MAX_NAME_LEN, "%s/%s/device",
				dev_dir, filelist[i]->d_name);
		/*printf("%s\n", dev_file);*/
		if ((odisk = sysfs_get_one_cciss_dev(dev_file, flag)) != NULL) {
			list_add_tail(&odisk->disk_list, dev_head);
			dest_num++;
		}
		free(filelist[i]);
	}
	free(filelist);

   /* Add support for Citrix Xen virtualization platform. */
   strncpy(dev_dir, SYS_BLOCK_CCISS, MAX_NAME_LEN);
   num = scandir(dev_dir, &filelist, filter_citrix_xen_disk, alphasort);
   if (num < 0) {
  	   pthread_mutex_unlock(&g_osndisk_mutex);
      return 0;
   }
   for (i = 0; i < num; i ++) {
      /* e.g. /sys/block/xvda/device */
      snprintf(dev_file, MAX_NAME_LEN, "%s/%s",
          dev_dir, filelist[i]->d_name);
      if ((odisk = sysfs_get_one_citrix_dev(dev_file, flag)) != NULL) {
          list_add_tail(&odisk->disk_list, dev_head);
          dest_num ++;
      }
      free(filelist[i]);
   }
   free(filelist);
	/*********Get multipath disk************/
//   if (is_multipath_conf_exist() == 0 ) {
//   	//get multipath disk list.
//   	log_debug(DEBUG_VERBOSE,"Start to get multipath disk.");
//   	if (osnmultipath_get_devs(&odmdisk) == 0) {
//     	   if (osndisk_merge_mpath_devs(dev_head, &odmdisk, flag) < 0) {
//         	log_error("Failed to merge multipath disk to osndisk.");
//     	   }
//   	} 
//   	else {
//      	log_error("Failed to get multipath disk.");
//   	}
//   	osn_free_dmdisklist(&odmdisk);
//   }
	pthread_mutex_unlock(&g_osndisk_mutex);

	return dest_num;
}

/**
 * src is count of sectors
 */
static int size_convert(char *dest, uint64_t src)
{
	float size;
	uint64_t src_byte = src * 512; /* a sector is 512 Byte */
	uint64_t k = 1024;
	uint64_t m = k * k;
	uint64_t g = m * k;
	uint64_t t = g * k;
	uint64_t p = t * k;
	uint64_t e = p * k;

	if (!dest)
		return 0;

	if (src_byte/e) {
		size = (float)src_byte/e;
		snprintf(dest, MAX_ATTR_LEN, "%.2fEB", size);
	} else if (src_byte/p) {
		size = (float)src_byte/p;
		snprintf(dest, MAX_ATTR_LEN, "%.2fPB", size);
	} else if (src_byte/t) {
		size = (float)src_byte/t;
		snprintf(dest, MAX_ATTR_LEN, "%.2fTB", size);
	} else if (src_byte/g) {
		size = (float)src_byte/g;
		snprintf(dest, MAX_ATTR_LEN, "%.2fGB", size);
	} else if (src_byte/m) {
		size = (float)src_byte/m;
		snprintf(dest, MAX_ATTR_LEN, "%.2fMB", size);
	} else if (src_byte/k) {
		size = (float)src_byte/k;
		snprintf(dest, MAX_ATTR_LEN, "%.2fKB", size);
	} else {
		size = (float)src_byte;
		snprintf(dest, MAX_ATTR_LEN, "%.2fB", size);
	}

	return 1;
}

/**
 * @param[in] all: list all devices include offline ones
 * @param[in] t: list devices' transport
 */
static int osndisk_list_dev(int all, int t)
{
	struct list_head devs;
	struct osn_disk *od_node;
	char size[MAX_ATTR_LEN] = {0};
	char hctl[MAX_ATTR_LEN] = {0};
	unsigned int align_size = strlen(LIST_SIZE);
	unsigned int align_hctl = strlen(LIST_HCTL);
	unsigned int align_vendor = strlen(LIST_VENDOR);
	unsigned int align_model = strlen(LIST_MODEL);
	unsigned int align_rev = strlen(LIST_REVISION);
   unsigned int align_dmname = strlen(LIST_DMNAME);
	unsigned int align_path = strlen(LIST_PATH);
	unsigned int align_target = strlen(LIST_TARGET);

	INIT_LIST_HEAD(&devs);
	osndisk_get_devs(&devs, 0);
	if (list_empty(&devs)) {
		fprintf(stdout, "No device\n");
		return 1;
	}

	list_for_each_entry(od_node, &devs, disk_list) {
		size_convert(size, od_node->size);
		snprintf(hctl, MAX_ATTR_LEN, "%d:%d:%d:%d",
			od_node->hctl.h, od_node->hctl.c,
			od_node->hctl.t, od_node->hctl.l);
		align_size = MAX(align_size, strlen(size));
		align_hctl = MAX(align_hctl, strlen(hctl));
		if (od_node->vendor)
			align_vendor = MAX(align_vendor, strlen(od_node->vendor));
		if (od_node->model)
			align_model = MAX(align_model, strlen(od_node->model));
		if (od_node->revision)
			align_rev = MAX(align_rev, strlen(od_node->revision));
      if (od_node->block_name)
         align_dmname = MAX(align_dmname, strlen(od_node->block_name));
		if (od_node->dev_path)
			align_path = MAX(align_path, strlen(od_node->dev_path));
		if (od_node->target)
			align_target = MAX(align_target, strlen(od_node->target));
	}
	/* print title */
	fprintf(stdout, "  %-*s%-*s%-*s%-*s%-*s%-*s%-*s%-*s\n", 
		align_hctl+1, LIST_HCTL,
		align_path+1, LIST_PATH,
		align_size+1, LIST_SIZE,
		align_vendor+1, LIST_VENDOR,
		align_model+1, LIST_MODEL,
		align_rev+1, LIST_REVISION,
      align_dmname+1, LIST_DMNAME,
		t?align_target+1:0, t?LIST_TARGET:"");
	/* print all disk */
	list_for_each_entry(od_node, &devs, disk_list) {
		size_convert(size, od_node->size);

		if (!od_node->online && !all)
			continue;

		snprintf(hctl, MAX_ATTR_LEN, "%d:%d:%d:%d",
			od_node->hctl.h, od_node->hctl.c,
			od_node->hctl.t, od_node->hctl.l);
		fprintf(stdout, "  %-*s%-*s%-*s%-*s%-*s%-*s%-*s%-*s\n", 
			align_hctl+1, hctl,
			align_path+1, od_node->dev_path?od_node->dev_path:"--",
			align_size+1, size,
			align_vendor+1, od_node->vendor?od_node->vendor:"--",
			align_model+1, od_node->model?od_node->model:"--",
			align_rev+1, od_node->revision?od_node->revision:"--",
         align_dmname+1, od_node->block_name?od_node->block_name:"--",
			t?align_target+1:0, (!t)?"":od_node->target?od_node->target:"--");
	}

	osndisk_free_devs(&devs);
	return 1;
}

/**
 * sdev_path: such as '/dev/sda'
 * return 0 if success 
 */
static int osndisk_info_dev(const char *sdev_path)
{
	struct list_head devs;
	struct osn_disk *odisk = NULL, *od_node;
	struct osn_part *op_tmp;
	char base_name[MAX_NAME_LEN];
	char size[MAX_ATTR_LEN];
	char *total, *used;
	unsigned int align_name = strlen(LIST_PARTITION);
	unsigned int align_guid = strlen(LIST_GUID);
	unsigned int align_total_size = strlen(LIST_TOTAL_SIZE);
	unsigned int align_used_size = strlen(LIST_USED_SIZE);
	unsigned int align_fs = strlen(LIST_FS);
	unsigned int align_mountpoint = strlen(LIST_MOUNTPOINT);

	if (!sdev_path)
		return E_POINTER_NONE;

	if (-1 == access(sdev_path, 0))
		return E_FILE_NOT_EXIST;

	if (strstr(sdev_path, "cciss")) {
		if (!sscanf(sdev_path, "/dev/cciss/%s", base_name))
			return E_SDEV_FORMAT;
	}
	else {
		if (!sscanf(sdev_path, "/dev/%s", base_name))
			return E_SDEV_FORMAT;
	}
	INIT_LIST_HEAD(&devs);
	osndisk_get_devs(&devs, GET_PARTITION);

	list_for_each_entry(od_node, &devs, disk_list) {
		if (od_node->dev_name && !strcmp(base_name, od_node->dev_name)) {
			odisk = od_node;
			break;
		}
	}

	if (odisk) {
		size_convert(size, odisk->size);
		fprintf(stdout, "  H:C:T:L:       %d:%d:%d:%d\n",
			odisk->hctl.h, odisk->hctl.c,
			odisk->hctl.t, odisk->hctl.l);
		fprintf(stdout, "  DevicePath:    %s\n",
			odisk->dev_path?odisk->dev_path:"--");
		fprintf(stdout, "  Size:          %s (%"PRIu64" Sectors)\n", size, odisk->size);
		fprintf(stdout, "  Vendor:        %s\n",
			odisk->vendor?odisk->vendor:"--");
		fprintf(stdout, "  Model:         %s\n",
			odisk->model?odisk->model:"--");
		fprintf(stdout, "  Revision:      %s\n",
			odisk->revision?odisk->revision:"--");
		fprintf(stdout, "  Type:          %s\n", scsi_types[odisk->type]);
		fprintf(stdout, "  Transport:     %s\n",
			odisk->target?odisk->target:"--");
		fprintf(stdout, "  Queue type:    %s\n",
			odisk->queue_type?odisk->queue_type:"--");
		fprintf(stdout, "  Queue depth:   %d\n", odisk->queue_depth);
		fprintf(stdout, "  Scsi level:    %d\n", odisk->scsi_level);
		fprintf(stdout, "  Blocked:       %d\n", odisk->device_blocked);
		fprintf(stdout, "  Timeout:       %d\n", odisk->timeout);
		fprintf(stdout, "  IOcounterbits: %d\n", odisk->iocounterbits);
		fprintf(stdout, "  IOdone:        %d\n", odisk->iodone_cnt);
		fprintf(stdout, "  IOerr:         %d\n", odisk->ioerr_cnt);
		fprintf(stdout, "  IOrequest:     %d\n", odisk->iorequest_cnt);
		if (!list_empty(&odisk->parts)) {
			list_for_each_entry(op_tmp, &odisk->parts, list) {
				if (op_tmp->name)
					align_name = MAX(align_name, strlen(op_tmp->name));
				if (op_tmp->uuid)
					align_guid = MAX(align_guid, strlen(op_tmp->uuid));

				total = byte_to_str(op_tmp->size ? op_tmp->size : 0);
				align_total_size = MAX(align_total_size, strlen(total));
				used = byte_to_str(op_tmp->used ? op_tmp->used : -1);
				align_used_size = MAX(align_used_size, strlen(used));
				free(used);
				free(total);
				if (op_tmp->fstype)
					align_fs = MAX(align_fs, strlen(op_tmp->fstype));
				if (op_tmp->mountpoint)
					align_fs = MAX(align_mountpoint, strlen(op_tmp->mountpoint));
			}
			fprintf(stdout, "  ----- Partitions -----\n");
			fprintf(stdout, "  %-*s%-*s%-*s%-*s%-*s%-*s\n", 
				align_name+1, LIST_PARTITION,
				align_guid+1, LIST_GUID,
				align_total_size+1, LIST_TOTAL_SIZE,
				align_used_size+1, LIST_USED_SIZE,
				align_fs+1, LIST_FS,
				align_mountpoint+1, LIST_MOUNTPOINT);
			list_for_each_entry(op_tmp, &odisk->parts, list) {
				total = byte_to_str(op_tmp->size ? op_tmp->size : 0);
				used = byte_to_str(op_tmp->used ? op_tmp->used : -1);
				fprintf(stdout, "  %-*s%-*s%-*s%-*s%-*s%-*s\n", 
					align_name+1, op_tmp->name,
					align_guid+1, op_tmp->uuid?op_tmp->uuid:"--",
					align_total_size+1, total,
					align_used_size+1, used,
					align_fs+1, op_tmp->fstype?op_tmp->fstype:"--",
					align_mountpoint+1, op_tmp->mountpoint?op_tmp->mountpoint:"--");
				free(total);
				free(used);
			}
		}
	}

	osndisk_free_devs(&devs);
	return 0;
}

/**
 * @param[in] hctl: such as '3:0:0:0'
 * @return: 1 - changed; 0 - not changed
 */
static int is_sdev_changed(const char *hctl)
{
	char sdev_path[MAX_NAME_LEN];
	char sys_dev_file[MAX_NAME_LEN];
	struct sdev_info_t *sinfo = NULL;
	struct osn_disk *sysdisk = NULL;

	if (!hctl) {
		log_error("input arg is null");
		return 1;
	}

	snprintf(sys_dev_file, MAX_NAME_LEN, "%s/%s/device",
		SYS_CLASS_SCSI_DEV, hctl);
	if (-1 == access(sys_dev_file, 0)) {
		log_error("%s not exist", sys_dev_file);
		return 1;
	}

	/* need not to get partition */
	if (!(sysdisk = sysfs_get_one_dev(sys_dev_file, 0))) {
		log_error("Failed to get %s's information from sysfs", hctl);
		return 1;
	}

	/* without device name, not Direct-Access device,
	 * ignore this device, so return 0 indicate it is not changed */
	if (!sysdisk->dev_name) {
		goto not_changed;
   }

	snprintf(sdev_path, MAX_NAME_LEN, "/dev/%s", sysdisk->dev_name);

	if (-1 == access(sdev_path, 0)) {
		log_error("%s is not exist", sdev_path);
		goto changed;
	}
	if (!scsi_tur(sdev_path)) {
		log_error("Failed to TUR for %s", sdev_path);
		goto changed;
	}

	if (!(sinfo = scsi_inquiry(sdev_path))) {
		log_error("Failed to get scsi device %s's information", sdev_path);
		goto changed;
	}

	log_debug(DEBUG_VERBOSE, "%s->Qual: %d", sysdisk->dev_name, sinfo->qualifier);
	if (sinfo->qualifier)
		goto changed;

	log_debug(DEBUG_VERBOSE, "%s->type: %d", sysdisk->dev_name, sinfo->sdev_type);
	if (sinfo->sdev_type != sysdisk->type)
		goto changed;

	sanitize_string(sinfo->vendor);
	log_debug(DEBUG_VERBOSE, "%s->Vendor: #%s# (scsi_query: #%s#)",
		sysdisk->dev_name, sysdisk->vendor, sinfo->vendor);
	if (strcmp(sinfo->vendor, sysdisk->vendor))
		goto changed;

	sanitize_string(sinfo->product);
	log_debug(DEBUG_VERBOSE, "%s->Product: #%s# (scsi_query: #%s#)",
		sysdisk->dev_name, sysdisk->model, sinfo->product);
	if (strcmp(sinfo->product, sysdisk->model))
		goto changed;

	sanitize_string(sinfo->revision);
	log_debug(DEBUG_VERBOSE, "%s->Revision: #%s# (scsi_query: #%s#)",
		sysdisk->dev_name, sysdisk->revision, sinfo->revision);
	if (strcmp(sinfo->revision, sysdisk->revision))
		goto changed;

not_changed:
	free_sdev_info(sinfo);
	osndisk_free_one_dev(sysdisk);
	return 0;
changed:
	osndisk_free_one_dev(sysdisk);
	free_sdev_info(sinfo);
	return 1;
}

static int _wwn_trans(char *dst, const char *src)
{
   char *tmp;
   int len, i = 0;
                    
   if (!dst || !src)
      return -1;
 
   len = strlen(src);
   if (len <= 2)
      return -1;
   if (len % 2)
      return -1;
   src += 2;
   tmp = dst;
   while (*src) {
      *tmp++ = *src++;
      i++;
      if (!(i % 2)) {
         *tmp++ = ':';
      }
   }
   len = strlen(dst);
   if (len < 1)
      return -1;

   dst[len-1] = 0;
   return len-1;
}

static int host_has_rports(const char *hostname, char *wwn, struct list_head *chns)
{
	struct dirent **filelist;
   struct osn_chn *chn = NULL;
   char dest_file[MAX_NAME_LEN] = {0};
   char _wwn[MAX_NAME_LEN] = {0};
	int yes = 0, num, i, ret;
	int rports_num = -1, host_num = -1;

	if (!hostname)
		return 0;

	if (sscanf(hostname, "host%d", &host_num) != 1)
		return 0;

	if(-1 == (num = scandir(SYS_CLASS_FC_REMOTE_PORTS, &filelist, filter, alphasort)))
		return 0;

	for (i = 0; i < num; i++) {
		if (!yes) { 
		// not yet find target
			sscanf(filelist[i]->d_name, "rport-%d:%*s", &rports_num);
			if (host_num == rports_num) {
		      snprintf(dest_file, MAX_NAME_LEN, "%s/%s/port_name",
			      SYS_CLASS_FC_REMOTE_PORTS, filelist[i]->d_name);
            if (!sysfs_read_attribute(_wwn, dest_file)) {
               log_error("Failed to get target of %s.", filelist[i]->d_name);
		         free(filelist[i]);
               continue;
            } else {
               if (0 > (ret = _wwn_trans(wwn, _wwn))) {
                  log_error("Failed to transport wwn.");
		            free(filelist[i]);
                  continue;
               }
               list_for_each_entry (chn, chns, list) {
                  if (strcmp(chn->target, wwn) == 0) {
				         yes = 1;
                     log_info("Find ChannelTarget %s.", wwn);
                     break;
                  }
                  log_info("ChannelTarget is %s.", chn->target);
                  log_info("ChannelWWN is %s.", wwn);
               }
		         free(filelist[i]);
               continue;
            }
         }
		}
		free(filelist[i]);
	}
	free(filelist);
	return yes;
}

/**
 * compare hostname with files lie in /sys/fc_transport/
 * @param[in] hostname: such as 'host0'
 * @return: 1 - host num is same as transport num; else - 0
 */
static int host_has_target(const char *hostname, char *wwn, struct list_head *chns)
{
	struct dirent **filelist;
   struct osn_chn *chn = NULL;
   char dest_file[MAX_NAME_LEN] = {0};
   char _wwn[MAX_NAME_LEN] = {0};
	int yes = 0, num, i, ret;
	int tgt_num = -1, host_num = -1;

	if (!hostname)
		return 0;

	if (sscanf(hostname, "host%d", &host_num) != 1)
		return 0;

	if(-1 == (num = scandir(SYS_CLASS_FC_TRANSPORT, &filelist, filter, alphasort)))
		return 0;

	for (i = 0; i < num; i++) {
		if (!yes) { 
		// not yet find target
			sscanf(filelist[i]->d_name, "target%d:%*s", &tgt_num);
			if (host_num == tgt_num) {
		      snprintf(dest_file, MAX_NAME_LEN, "%s/%s/port_name",
			      SYS_CLASS_FC_TRANSPORT, filelist[i]->d_name);
            if (!sysfs_read_attribute(_wwn, dest_file)) {
               log_error("Failed to get target of %s.", filelist[i]->d_name);
		         free(filelist[i]);
               continue;
            } else {
               if (0 > (ret = _wwn_trans(wwn, _wwn))) {
                  log_error("Failed to transport wwn.");
		            free(filelist[i]);
                  continue;
               }
               list_for_each_entry (chn, chns, list) {
                  if (strcmp(chn->target, wwn) == 0) {
				         yes = 1;
                     log_info("Find ChannelTarget %s.", wwn);
                     break;
                  }
                  log_info("ChannelTarget is %s.", chn->target);
                  log_info("ChannelWWN is %s.", wwn);
               }
		         free(filelist[i]);
               continue;
            }
         }
		}
		free(filelist[i]);
	}
	free(filelist);
	return yes;
}

int sysfs_read_attribute(char *attr, char *path)
{
   int fd;
   char buf[MAX_NAME_LEN];
   char *endline;
                       
   if (!attr || !path)
      return -1;
   if ((fd = open(path, O_RDONLY)) < 0) { 
      log_error("Failed to open '%s': %s", path, strerror(errno));
      return -1;
   }
   if (read(fd, buf, sizeof (buf)-1) < 0) { 
      log_error("Failed to read '%s': %s", path, strerror(errno));
      close(fd);
      return -1;
   }
   endline = strchr(buf, '\n');
   if (endline)
      *endline = 0; 
   strncpy(attr, buf, MAX_NAME_LEN);
   close(fd);
   return strlen(attr);
}

int osndisk_rescan_dev(int force, struct list_head *chns)
{
	struct dirent **filelist;
	char dev_dir[MAX_NAME_LEN] = {0}; /* /sys/class/scsi_devices */
   char wwn[MAX_NAME_LEN] = {0};
	char dest_file[MAX_NAME_LEN] = {0};
	char *state; /* fc port state*/
	int online; /* if fc port is online */
	int num, i;
	char *proc_name = NULL;

	pthread_mutex_lock(&g_osndisk_mutex);
	strncpy(dev_dir, SYS_CLASS_SCSI_DEV, MAX_NAME_LEN);
	if(-1 == (num = scandir(dev_dir, &filelist, filter, alphasort))) {
		pthread_mutex_unlock(&g_osndisk_mutex);
		return 0;
	}
	log_info("Rescan all scsi device");

	/* step1. rescan all of the scsi device in sysfs
	 * if device have changed or offline, delete it */
	for (i = 0; i < num; i++) {
		log_info("Processing disk %s    [%d/%d]",
			filelist[i]->d_name, i+1, num);

		if (force) {
			log_info("Rescan disk %s forcedly", filelist[i]->d_name);
	      snprintf(dest_file, MAX_NAME_LEN, "%s/%s/device/rescan",
			   SYS_CLASS_SCSI_DEV, filelist[i]->d_name);
		   if (!set_value(dest_file, "1"))
			   log_error("Failed to rescan %s", filelist[i]->d_name);
			free(filelist[i]);
			continue;
		}
		if (is_sdev_changed(filelist[i]->d_name)) {
			log_info("Disk %s changed, delete it", filelist[i]->d_name);
			snprintf(dest_file, MAX_NAME_LEN, "%s/%s/device/delete",
				SYS_CLASS_SCSI_DEV, filelist[i]->d_name);
			if (!set_value(dest_file, "1"))
				log_error("Failed to delete %s", filelist[i]->d_name);
		}
		free(filelist[i]);
	}
	free(filelist);

	/* step2. issue lip for fc host */
	if (-1 == access(SYS_CLASS_FC_HOST, 0)) {
		log_info("There's no FC host");
		goto step3;
	}
	log_info("Issue lip for all FC host");
	if(-1 == (num = scandir(SYS_CLASS_FC_HOST, &filelist, filter, alphasort)))
		goto step3;
	log_info("The number of host : %d",num);
	for (i = 0; i < num; i++) {
//#if NEED_LIP_FOR_ALL
		if (force) {
			log_info("Issuing LIP %s forcedly    [%d/%d]",
				filelist[i]->d_name, i+1, num);
			goto force_issue_lip;
		}
//#endif
		/* check if fc port state online firstly */
		snprintf(dest_file, MAX_NAME_LEN, "%s/%s/port_state",
			SYS_CLASS_FC_HOST, filelist[i]->d_name);
		state = get_value(dest_file, MAX_ATTR_LEN);
		if (!state) {
			log_info("  Failed to get fc port state, ignore it");
			free(filelist[i]);
			continue;
		}
		online = 0;
		if (strstr(state, "Online") || strstr(state, "Active"))
			online = 1;
		free(state);
		state = NULL;
		if (!online) { /* if offline, skip it */
			log_info("  FC port is offline, ignore it");
			free(filelist[i]);
			continue;
		}
force_issue_lip:
      /* if host num is not exist in fc_transport/target*:*:*. 
       * don't known which host to LIP, ignore this host.*/
      if (!host_has_target(filelist[i]->d_name, wwn, chns)) {
         log_info("%s has no target, ignore it!",filelist[i]->d_name);
         if (!host_has_rports(filelist[i]->d_name, wwn, chns)) {
            log_info("%s has no remote port, ignore it!",filelist[i]->d_name);
            free(filelist[i]);
            continue;
         }
      }
		/* then issue LIP */
		log_info("Issuing LIP %s    [%d/%d]", filelist[i]->d_name, i+1, num);
		snprintf(dest_file, MAX_NAME_LEN, "%s/%s/issue_lip",
		   SYS_CLASS_FC_HOST, filelist[i]->d_name);
		if (!set_value(dest_file, "1")) {
		   log_error("Failed to issue lip for %s", filelist[i]->d_name);
      }
		free(filelist[i]);
	}
	free(filelist);

step3:
	/* step3. scan all of the scst host */
	if (-1 == access(SYS_CLASS_SCSI_HOST, 0)) {
		log_info("There's no SCSI host");
		goto out;
	}
	if(-1 == (num = scandir(SYS_CLASS_SCSI_HOST, &filelist, filter, alphasort)))
		goto out;
	for (i = 0; i < num; i++) {
		snprintf(dest_file, MAX_NAME_LEN, "%s/%s/proc_name",
			SYS_CLASS_SCSI_HOST, filelist[i]->d_name);
		proc_name = get_value(dest_file, MAX_ATTR_LEN);
		if (proc_name == NULL) {
			log_info("Failed to get proc_name state, ignore it");
			free(filelist[i]);
			continue;
		}
		if (strstr(proc_name, ATA_DEVICE_HOST)) {
			log_info("Scanning host:%s [%d/%d]is ata device, continue.", filelist[i]->d_name, i+1, num);
			free(proc_name);
			free(filelist[i]);
			continue;
		}
		snprintf(dest_file, MAX_NAME_LEN, "%s/%s/scan",
			SYS_CLASS_SCSI_HOST, filelist[i]->d_name);
		log_info("Scanning %s    [%d/%d]", filelist[i]->d_name, i+1, num);
		if (!set_value(dest_file, "- - -"))
			log_error("Failed to scan %s", filelist[i]->d_name);
		free(filelist[i]);
		if (proc_name)
			free(proc_name);
	}
	free(filelist);
out:
	pthread_mutex_unlock(&g_osndisk_mutex);
	return 1;
}

static int parse_args(struct osndisk_param *op, int argc, char **argv)
{
	int ch;
   struct osn_chn *chn = NULL;
   char *target = NULL;
	while ((ch = getopt_long(argc, argv, "lati:rT:fqh", 
		long_options, NULL)) != -1) {

		switch (ch) {
		case 'l':
			op->list = 1;
			break;
		case 'a':
			op->list_all = 1;
			break;
		case 't':
			op->transport = 1;
			break;
		case 'i':
			op->info = 1;
			op->dev_path = optarg;
			break;
      case 'T':
         op->target_list = 1;
         target = optarg;
         break;
		case 'r':
			op->rescan = 1;
			break;
		case 'f':
			op->force_rescan = 1;
			break;
		case 'h':
			usage();
			return 0;
		default:
			fprintf(stderr, "try '%s -h' for help\n", argv[0]);
			return 0;
		}
	}

	if (op->list + op->list_all + op->info + op->rescan > 1) {
		fprintf(stderr, "multi-operation is forbbiden\n");
		return 0;
	}

//   if (op->rescan && !op->fc_target_list) {
//      fprintf(stderr, "Option '-r' must be used with 'T'\n");
//      return 0;
//   }

	if (op->force_rescan && !op->rescan) {
		fprintf(stderr, "Option '-f' must be used with '-r'\n");
		return 0;
	}

	if (op->transport && !op->list && !op->list_all) {
		fprintf(stderr, "Option '-t' must be used with '-l' or '-a'\n");
		return 0;
	}

   if (op->target_list) {
      fprintf(stdout, "target is %s\n", target);
      if (target == NULL) {
         fprintf(stderr, "Optical '-T' need parameter\n");
         return 0;
      }
      chn = calloc(1, sizeof(struct osn_chn));
      if (chn == NULL) {
         log_error("Failed to allocate memory.");
         return 0;
      }
      chn->target = strdup(target);
      list_add_tail(&chn->list, &op->chns);
   }

	return 1;
}

int osndisk(int argc, char **argv)
{
	struct osndisk_param *op;

	optind = 0;
	optarg = 0;

	if (1 == argc) {
		usage();
		return 0;
	}

	osn_set_logdaemon(0);

	op = (struct osndisk_param*)malloc(sizeof(*op));
	if (!op) {
		fprintf(stderr, "Failed to allocate memory\n");
		return 0;
	}
	memset(op, 0, sizeof(struct osndisk_param));
   INIT_LIST_HEAD(&op->chns);

	if (!parse_args(op, argc, argv)) {
		free(op);
		return 0;
	}

	if (op->list) {
		osndisk_list_dev(0, op->transport);
	} else if (op->list_all) {
		osndisk_list_dev(1, op->transport);
	} else if (op->info) {
		osndisk_info_dev(op->dev_path);
	} else if (op->rescan) {
		osndisk_rescan_dev(op->force_rescan, &op->chns);
	}

   osndisk_free_chns(&op->chns);
	free(op);
	return 1;
}
