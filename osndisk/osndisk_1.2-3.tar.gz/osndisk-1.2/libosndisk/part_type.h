#ifndef __PART_TYPE_H
#define __PART_TYPE_H

#define PART_TYPE_UNKOWN 0
#define PART_TYPE_DOS 1
#define PART_TYPE_GPT 2
int get_part_type(const char *disk_path);

#endif
