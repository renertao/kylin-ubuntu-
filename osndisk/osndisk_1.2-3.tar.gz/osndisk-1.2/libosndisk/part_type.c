#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include "part_type.h"
#include "osnlog.h"

#define PARTITION_GPT 0xee
#define MBR_MAGIC 0xAA55

struct mbr_part_entry {
	uint8_t status;
	uint8_t start_head;
	uint16_t start_sector;
	uint8_t part_type;
	uint8_t end_head;
	uint16_t end_sector;
	uint32_t first_abs_sector;
	uint32_t sector_count;
} __attribute__((packed));

struct mbr_section {
	char boot_code[440];
	uint32_t mbr_signature;
	uint16_t unknown;
	struct mbr_part_entry partitions[4];
	uint16_t magic;
} __attribute__((packed));

int get_part_type(const char *disk_path)
{
	int fd, ret = 0;
	struct mbr_section mbr;

	if (!disk_path) {
		log_error("Invalid parameter\n");
		return PART_TYPE_UNKOWN;
	}

	fd = open(disk_path, O_RDONLY);
	if (fd == -1) {
		log_error("Failed to open %s\n", disk_path);
		return PART_TYPE_UNKOWN;
	}

	memset(&mbr, 0, sizeof (mbr));
	if (read(fd, &mbr, sizeof (mbr)) == -1) {
		/* in case of write large number of log in log/messages while run
		 * with streamer, so it use 'log_debug' instead of 'log_error' */
		log_debug(DEBUG_VERBOSE, "Failed to read %s\n", disk_path);
		goto unkown;
	}

	if (mbr.magic != MBR_MAGIC) {
		goto unkown;
	}

	if (mbr.partitions[0].part_type == PARTITION_GPT)
		ret = PART_TYPE_GPT;
	else
		ret = PART_TYPE_DOS;

	close(fd);
	return ret;
unkown:
	close(fd);
	return PART_TYPE_UNKOWN;
}
