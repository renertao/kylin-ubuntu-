#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <scsi/scsi_ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <scsi/sg.h>
#include <sys/ioctl.h>
#include <inttypes.h>
#include <ctype.h>
#include <errno.h>
#include "scsi_inquiry.h"
#include "osnlog.h"

#define SENSE_LEN       255
#define BLOCK_LEN       32
#define PRODUCT_LEN     32
#define TUR_CMD_LEN     6

unsigned char sense_buffer[SENSE_LEN];
unsigned char data_buffer[BLOCK_LEN*256];

static uint64_t hex_str_to_byte(char *s)
{
	uint64_t sum = 0L;
	int digit;

	if (!s)
		return 0;

	while (isspace(*s))
		s++;

	for (sum = 0L; isxdigit(*s); s++) {
		if (isdigit(*s))
		digit = *s - '0';
		else
		digit = toupper(*s) - 'A' + 10;

		sum = sum * 16 + digit;
	}

	return sum;
}

static struct  sg_io_hdr * init_io_hdr()
{
	struct sg_io_hdr * p_scsi_hdr;
	if (!(p_scsi_hdr = (struct sg_io_hdr *)malloc(sizeof(struct sg_io_hdr)))) {
		log_error("Failed to allocate memory");
		return NULL;
	}
	memset(p_scsi_hdr, 0, sizeof(struct sg_io_hdr));
	if (p_scsi_hdr) {
		/* 'S' is the only choice we have */
		p_scsi_hdr->interface_id = 'S';
		/* this would put the LUN to 2nd byte of cdb */
		p_scsi_hdr->flags = SG_FLAG_LUN_INHIBIT;
	}

	return p_scsi_hdr;
}

static void destroy_io_hdr(struct sg_io_hdr * p_hdr)
{
	if (p_hdr) {
		free(p_hdr);
	}
}

static void set_xfer_data(struct sg_io_hdr *p_hdr, void *data, unsigned int length)
{
	if (p_hdr) {
		p_hdr->dxferp = data;
		p_hdr->dxfer_len = length;
	}
}

static void set_sense_data(struct sg_io_hdr *p_hdr, unsigned char *data,
		unsigned int length)
{
	if (p_hdr) {
		p_hdr->sbp = data;
		p_hdr->mx_sb_len = length;
	}
}

static void set_inquiry_cmd(int fd, int page_code, int evpd, struct sg_io_hdr *p_hdr)
{
	unsigned char cdb[6];

	/* set the cdb format */
	cdb[0] = 0x12; /*This is for Inquery*/
	cdb[1] = evpd & 1;
	cdb[2] = page_code & 0xff;
	cdb[3] = 0;
	cdb[4] = 0xff;
	cdb[5] = 0; /*For control filed, just use 0*/
	
	p_hdr->dxfer_direction = SG_DXFER_FROM_DEV;
	p_hdr->cmdp = cdb;
	p_hdr->cmd_len = sizeof (cdb);
	if (-1 == ioctl(fd, SG_IO, p_hdr)) {
		log_error("Ioctl error\n");
	}
}

static char *get_sense_buffer(struct sg_io_hdr * hdr)
{
    int i;
    char *dst;
    unsigned char *buffer = hdr->sbp;

    if (!buffer)
        return NULL;

    if (!(dst = calloc(1, SENSE_LEN))) {
        log_error("Counldn't allocate memory\n");
        return NULL;
    }

    for (i = 0; i < hdr->mx_sb_len; i++) {
        dst[i] = buffer[i];
    }
    dst[i] = 0;

    return dst;
}


static unsigned char get_error_from_sense_buffer(char *sbp)
{
    unsigned char ret;
    ret = *(sbp+1)&0x0F;        /* Sense Key */
    if (ret != 0x0) return ret;
    ret = *(sbp+2);             /* Additional Sense Key */
    if (ret != 0x0) return ret;
    ret = *(sbp+3);             /* Additional Sense Code Qualifier */
    return ret;
}


/**
 * return the capacity of 'path', if failed, return 0
 */
static uint64_t scsi_read_capacity_10(const char *path)
{
    int fd;
    uint64_t dev_bytes = 0, blk_sz_byte, blks_cnt;
    unsigned char inq_buff[BLOCK_LEN] = {0};
    unsigned char sense_buff[252] = {0};
    unsigned char cmdblk[BLOCK_LEN] = {0};
    sg_io_hdr_t io_hdr;
    char blk_sz[128], blk_cnt[128];

    if (!path) {
            log_error("READ_CAPACITY: Invalid input\n");
            return 0;
    }

    memset(&io_hdr, 0, sizeof (sg_io_hdr_t));
    cmdblk[0] = 0x25; /* SCSI Command: Read Capacity(10) */

    io_hdr.interface_id = 'S';
    io_hdr.cmd_len = 10;
    io_hdr.mx_sb_len = sizeof (sense_buff);
    io_hdr.dxfer_direction = SG_DXFER_FROM_DEV;
    io_hdr.dxfer_len = BLOCK_LEN;
    io_hdr.dxferp = inq_buff;
    io_hdr.cmdp = cmdblk;
    io_hdr.sbp = sense_buff;
    io_hdr.timeout = 1000;

    fd = open(path, O_RDONLY);
    if (fd < 0) {
            log_error("Failed to open %s: %s\n", path, strerror(errno));
            return 0;
    }
    if (ioctl(fd, SG_IO, &io_hdr) < 0) {
            log_error("ioctl failed: %s\n", strerror(errno));
            close(fd);
            return 0;
    }
    close(fd);

    if ((io_hdr.info & SG_INFO_OK_MASK) != SG_INFO_OK)
            return 0;

    if (*(inq_buff) == 0xff && *(inq_buff+1) == 0xff
            && *(inq_buff+2) == 0xff && *(inq_buff+3) == 0xff)      /* the number of logical blocks exceeds the value */
        return 0;

    memset(blk_cnt, 0, sizeof (blk_cnt));
    snprintf(blk_cnt, sizeof (blk_cnt), "%02x%02x%02x%02x\n",
            inq_buff[0], inq_buff[1], inq_buff[2], inq_buff[3]);
    if (strcmp(blk_cnt, "FFFFFFFF"))
    memset(blk_sz, 0, sizeof (blk_sz));
    snprintf(blk_sz, sizeof (blk_sz), "%02x%02x%02x%02x\n",
             inq_buff[4], inq_buff[5], inq_buff[6], inq_buff[7]);

    blks_cnt = hex_str_to_byte(blk_cnt) + 1;
    blk_sz_byte = hex_str_to_byte(blk_sz);
    dev_bytes = blk_sz_byte * blks_cnt;

    return dev_bytes;

}

/**
 * return the capacity of 'path', if failed, return 0
 */
uint64_t scsi_read_capacity(const char *path)
{
	int fd;
	uint64_t dev_bytes = 0, blk_sz_byte, blks_cnt;
	unsigned char inq_buff[BLOCK_LEN] = {0};
	unsigned char sense_buff[252] = {0};
	unsigned char cmdblk[BLOCK_LEN] = {0};
	sg_io_hdr_t io_hdr;
	char blk_sz[128], blk_cnt[128];

	if (!path) {
		log_error("READ_CAPACITY: Invalid input\n");
		return 0;
	}

	memset(&io_hdr, 0, sizeof (sg_io_hdr_t));
	cmdblk[0] = 0x9e;
	cmdblk[1] = 0x10;
	cmdblk[13] = 32;
	io_hdr.interface_id = 'S';
	io_hdr.cmd_len = 16;
	io_hdr.mx_sb_len = sizeof (sense_buff);
	io_hdr.dxfer_direction = SG_DXFER_FROM_DEV;
	io_hdr.dxfer_len = BLOCK_LEN;
	io_hdr.dxferp = inq_buff;
	io_hdr.cmdp = cmdblk;
	io_hdr.sbp = sense_buff;
	io_hdr.timeout = 1000;

	fd = open(path, O_RDONLY);
	if (fd < 0) {
		log_error("Failed to open %s: %s\n", path, strerror(errno));
		return 0;
	}
	if (ioctl(fd, SG_IO, &io_hdr) < 0) {
		log_error("ioctl failed: %s\n", strerror(errno));
		close(fd);
		return 0;
	}
	close(fd);

    if ((io_hdr.info & SG_INFO_OK_MASK) != SG_INFO_OK) {
        char * sbp = get_sense_buffer(&io_hdr);
        unsigned char ret = get_error_from_sense_buffer(sbp);
        free(sbp);
        if (ret == 0x5)     /* ILLEGAL REQUEST */
            return scsi_read_capacity_10(path);
        else
            return 0;
    }

	memset(blk_cnt, 0, sizeof (blk_cnt));
	snprintf(blk_cnt, sizeof (blk_cnt), "%02x%02x%02x%02x%02x%02x%02x%02x\n",
		inq_buff[0], inq_buff[1], inq_buff[2], inq_buff[3],
		inq_buff[4], inq_buff[5], inq_buff[6], inq_buff[7]);

	memset(blk_sz, 0, sizeof (blk_sz));
	snprintf(blk_sz, sizeof (blk_sz), "%02x%02x%02x%02x\n",
		inq_buff[8], inq_buff[9], inq_buff[10], inq_buff[11]);

	blks_cnt = hex_str_to_byte(blk_cnt) + 1;
	blk_sz_byte = hex_str_to_byte(blk_sz);
	dev_bytes = blk_sz_byte * blks_cnt;

	return dev_bytes;
}
/*
static void show_hdr_outputs(struct sg_io_hdr * hdr)
{
	printf("status:%d\n", hdr->status);
	printf("masked_status:%d\n", hdr->masked_status);
	printf("msg_status:%d\n", hdr->msg_status);
	printf("sb_len_wr:%d\n", hdr->sb_len_wr);
	printf("host_status:%d\n", hdr->host_status);
	printf("driver_status:%d\n", hdr->driver_status);
	printf("resid:%d\n", hdr->resid);
	printf("duration:%d\n", hdr->duration);
	printf("info:%d\n", hdr->info);
}
*/
static char *get_vendor(struct sg_io_hdr * hdr)
{
	int i;
	char *dst;
	unsigned char * buffer = hdr->dxferp;

	if (!(dst = calloc(1, PRODUCT_LEN))) {
		log_error("Counldn't allocate memory\n");
		return NULL;
	}

	for (i = 8; i < 16; i++) {
		dst[i-8] = buffer[i];
	}
	dst[i-8] = 0;

	return dst;
}

static char *get_product(struct sg_io_hdr * hdr)
{
	int i;
	char *dst;
	unsigned char *buffer = hdr->dxferp;

	if (!(dst = calloc(1, PRODUCT_LEN))) {
		log_error("Counldn't allocate memory\n");
		return NULL;
	}

	for (i = 16; i < 32; i++) {
		dst[i-16] = buffer[i];
	}
	dst[i-16] = 0;

	return dst;
}

static char *get_product_rev(struct sg_io_hdr * hdr)
{
	int i;
	char *dst;
	unsigned char *buffer = hdr->dxferp;

	if (!(dst = calloc(1, PRODUCT_LEN))) {
		log_error("Counldn't allocate memory\n");
		return NULL;
	}

	for (i = 32; i < 36; i++) {
		dst[i-32] = buffer[i];
	}
	dst[i-32] = 0;

	return dst;
}

void free_sdev_info(struct sdev_info_t *sinfo)
{
	if (!sinfo)
		return;
	free(sinfo->sense);
	free(sinfo->vendor);
	free(sinfo->product);
	free(sinfo->revision);
	free(sinfo);
}

struct sdev_info_t *scsi_inquiry(const char *path)
{
	int fd;
	struct sg_io_hdr *p_hdr;
	struct sdev_info_t *si;

	if (-1 == (fd = open(path, O_RDONLY))) {
		log_error("Failed to open %s\n", path);
		return NULL;
	}

	if (!(p_hdr = init_io_hdr())) {
		log_error("Failed to initiator sg_io_hdr %s\n", path);
		close(fd);
		return NULL;
	}
	set_xfer_data(p_hdr, data_buffer, BLOCK_LEN*256);
	set_sense_data(p_hdr, sense_buffer, SENSE_LEN);
	set_inquiry_cmd(fd, 0, 0, p_hdr);
	close(fd);

	if (p_hdr->status != 0) {
		log_error("Ioctl return status: %d\n", p_hdr->status);
		destroy_io_hdr(p_hdr);
		return NULL;
	} else{
		si = calloc(1, sizeof (struct sdev_info_t));
		si->vendor = get_vendor(p_hdr);
		si->product = get_product(p_hdr);
		si->revision = get_product_rev(p_hdr);
		si->qualifier = (((char *)p_hdr->dxferp)[0] & 0xe0) >> 5;
		si->sdev_type = ((char *)p_hdr->dxferp)[0] & 0x1f;
	}
	destroy_io_hdr(p_hdr);

	return si;
}

/**
 * test unit ready
 * @return: 0 - offline; 1 - online
 */
int scsi_tur(const char *path)
{
	struct sg_io_hdr io_hdr;
	unsigned char turCmdBlk[TUR_CMD_LEN] = { 0x00, 0, 0, 0, 0, 0 };
	unsigned char sense_buffer[32];
	int retry_tur = 1;
	int fd = 0;

	fd = open(path, O_RDONLY, 0);
	if (fd < 0) {
		log_error("Failed to open %s: %s\n", path, strerror(errno));
		return 0;
	}

retry:
	memset(&io_hdr, 0, sizeof (struct sg_io_hdr));
	memset(&sense_buffer, 0, 32);
	io_hdr.interface_id = 'S';
	io_hdr.cmd_len = sizeof (turCmdBlk);
	io_hdr.mx_sb_len = sizeof (sense_buffer);
	io_hdr.dxfer_direction = SG_DXFER_NONE;
	io_hdr.cmdp = turCmdBlk;
	io_hdr.sbp = sense_buffer;
	io_hdr.timeout = 30000;
	io_hdr.pack_id = 0;
	if (ioctl(fd, SG_IO, &io_hdr) < 0) {
		close(fd);
		log_error("ioctl failed");
		return 0;
	}

	if (io_hdr.info & SG_INFO_OK_MASK) {
		int key = 0, asc, ascq;

		switch (io_hdr.host_status) {
			case DID_OK:
			case DID_NO_CONNECT:
			case DID_BAD_TARGET:
			case DID_ABORT:
			case DID_TRANSPORT_FAILFAST:
				break;
			default:
				/* Driver error, retry */
				if (--retry_tur)
					goto retry;
				break;
		}
		if (io_hdr.sb_len_wr > 3) {
			if (io_hdr.sbp[0] == 0x72 || io_hdr.sbp[0] == 0x73) {
				key = io_hdr.sbp[1] & 0x0f;
				asc = io_hdr.sbp[2];
				ascq = io_hdr.sbp[3];
			} else if (io_hdr.sb_len_wr > 13 &&
					((io_hdr.sbp[0] & 0x7f) == 0x70 ||
					 (io_hdr.sbp[0] & 0x7f) == 0x71)) {
				key = io_hdr.sbp[2] & 0x0f;
				asc = io_hdr.sbp[12];
				ascq = io_hdr.sbp[13];
			}
		}
		if (key == 0x6) {
			/* Unit Attention, retry */
			if (--retry_tur)
				goto retry;
		}
		else if (key == 0x2) {
			/* Not Ready */
			/* Note: Other ALUA states are either UP or DOWN */
			if( asc == 0x04 && ascq == 0x0b){
				/*
				 * LOGICAL UNIT NOT ACCESSIBLE,
				 * TARGET PORT IN STANDBY STATE
				 */
				close(fd);
				return 0;
			}
		}
		close(fd);
		return 0;
	}
	close(fd);
	return 1;
}
