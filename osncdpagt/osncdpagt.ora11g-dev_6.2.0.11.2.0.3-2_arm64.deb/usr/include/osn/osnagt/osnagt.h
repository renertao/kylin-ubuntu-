/*
 * osnagt.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 22, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNAGENT_H_
#define OSNAGENT_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <osn/osnpub/list.h>
#include <osn/osndev/osndev.h>


#define APP_ORACLE	1
#define APP_NOTES	2
#define APP_SYBASE	3
#define APP_DB2		4
#define APP_INFOMIX	5
#define APP_MYSQL	6
#define APP_MAXNUM	6
#define MAX_NAME_LEN	512
#define BY_ID_DIR "/dev/disk/by-id"

#define SYBASE_SCRIPT_CONF_FILE "/usr/local/osncdpagt/scripts/sybase"


    typedef struct _OsnApp OsnApp;

    struct _OsnApp {
        struct list_head	osn_app_list_entry;
        char* server;			/* oracle SID, sybase server name,etc. */
        int type;				/* App type, oracle,domino,infomix,etc. */
        int status;
        int mode;				/* archive or not, etc.*/
        char* name;
        char* usrname;
        char* usrgroup;
        char* passwd;
        char* installpath;
        char* datapath;
        char* env;

        char* host;
        char* port;

        void* priv;				/* reserved */
        int id;
    };

    typedef struct _OsnAgtOps {
        /*scripts before or after mark cdp */
        int (*osnprecdp_scripts) (OsnApp* app);
        int (*osnpostcdp_scripts) (OsnApp* app);

        /* non-archivelog mode process */
        int (*osncdp_process) (OsnApp* app);

        /* archivelog mode process */
        int (*osnprecdp_process) (OsnApp* app);
        int (*osnpostcdp_process) (OsnApp* app);

        /* connect, disconnect to db*/
        int (*osncdp_conndb)(OsnApp* app);
        void (*osncdp_disconndb)(OsnApp* app);
    } OsnAgtOps;

    typedef struct _Osndevgrp {
        struct list_head grp_list_entry;
        struct list_head devs_list;
        char* grp_name;
    } Osndevgrp;

    //extern OsnAgtOps osnora;
    typedef struct _Osndev {
        struct list_head	osn_dev_list_entry; /* Device list */
        struct list_head	osn_grp_dev_entry; /* Device group */
        Osndevgrp *dgrp;
        uint8_t	guid[GUID_LEN + 1];
        uint8_t	forcecheck;
        char*	path;
        int id;
    } Osndev;

#ifdef oracle
    extern OsnAgtOps osnora;
#endif

#ifdef _mysql_
    extern OsnAgtOps osnmql;
#endif

#ifdef domino
    extern OsnAgtOps osndmo;
#endif

#ifdef _db2_
    extern OsnAgtOps osndb2;
#endif

#ifdef sybase
    extern OsnAgtOps osnase;
#endif

    Osndev* Osn_getdev(const char* guid, const char *path, int save);
    int Osn_markcdp(Osndev* dev);
    int Osn_marktimecdp(Osndev* dev);

    /* type 0 -- cdp
     * type 1 -- timemark cdp
     */
    void osn_call_markcdp(const char *guid, const char *path, int type);
    int osn_call_disk_markcdp(const char *guid, const char *path);
    int osn_call_grp_markcdp(Osndevgrp *);

    int Osn_try_connect_db(OsnApp *app);
    int Osn_connect_db_flush_cfg(OsnApp *app);
    int Osn_preprocess();
    void Osn_postprocess();

    int Osn_add_dev_to_group(const char *guid, const char *group);
    int Osn_list_app(struct list_head *oapp_list);
    int Osn_list_dev(struct list_head *odev_list);
    int Osn_delete_app(const char *server);
    int Osn_delete_dev(const char *group, const char *guid); 

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNAGENT_H_ */
