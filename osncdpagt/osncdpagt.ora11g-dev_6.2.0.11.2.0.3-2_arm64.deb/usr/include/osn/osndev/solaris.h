/*
 * solaris.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef SOLARIS_H_
#define SOLARIS_H_

extern OsnArch	osn_solaris_arch;

#endif /* SOLARIS_H_ */
