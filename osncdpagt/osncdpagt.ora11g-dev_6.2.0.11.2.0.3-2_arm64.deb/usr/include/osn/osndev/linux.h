/*
 * linux.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 17, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef LINUX_H_
#define LINUX_H_

extern OsnArch	osn_linux_arch;

#endif /* LINUX_H_ */
