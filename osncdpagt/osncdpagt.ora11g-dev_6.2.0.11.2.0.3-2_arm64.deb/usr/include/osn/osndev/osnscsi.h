/*
 * osnscsi.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNSCSI_H_
#define OSNSCSI_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <sys/types.h>
#include <stdint.h>
#include <osn/osnagt/osnagt.h> /* XXX: Probably a bad choice. */

#if defined(_BIT_HTOL)
#define DECL_BITFIELD2(_a, _b)                          \
   uint8_t _b, _a
#define DECL_BITFIELD3(_a, _b, _c)                      \
   uint8_t _c, _b, _a
#define DECL_BITFIELD4(_a, _b, _c, _d)                  \
   uint8_t _d, _c, _b, _a
#define DECL_BITFIELD5(_a, _b, _c, _d, _e)              \
   uint8_t _e, _d, _c, _b, _a
#define DECL_BITFIELD6(_a, _b, _c, _d, _e, _f)          \
   uint8_t _f, _e, _d, _c, _b, _a
#define DECL_BITFIELD7(_a, _b, _c, _d, _e, _f, _g)      \
   uint8_t _g, _f, _e, _d, _c, _b, _a
#define DECL_BITFIELD8(_a, _b, _c, _d, _e, _f, _g, _h)  \
   uint8_t _h, _g, _f, _e, _d, _c, _b, _a
#else
#define DECL_BITFIELD2(_a, _b)                          \
   uint8_t _a, _b
#define DECL_BITFIELD3(_a, _b, _c)                      \
   uint8_t _a, _b, _c
#define DECL_BITFIELD4(_a, _b, _c, _d)                  \
   uint8_t _a, _b, _c, _d
#define DECL_BITFIELD5(_a, _b, _c, _d, _e)              \
   uint8_t _a, _b, _c, _d, _e
#define DECL_BITFIELD6(_a, _b, _c, _d, _e, _f)          \
   uint8_t _a, _b, _c, _d, _e, _f
#define DECL_BITFIELD7(_a, _b, _c, _d, _e, _f, _g)      \
   uint8_t _a, _b, _c, _d, _e, _f, _g
#define DECL_BITFIELD8(_a, _b, _c, _d, _e, _f, _g, _h)  \
   uint8_t _a, _b, _c, _d, _e, _f, _g, _h
#endif /* _BIT_HTOL */

#define DEF_ALLOC_LEN		252
#define MAX_ALLOC_LEN		0xc00 + 0x80
#define OSN_CDP_CMD			0x55
#define OSN_CDP_PAGENUM		0x22
#define OSN_TIMECDP_PAGENUM	0x22
#define OSN_INQUIRY_USN		0x80
#define OSN_INQUIRY_ID		0x83
#define OSN_DESIGNATOR_T10	0x1

   /* SCSI INQUIRY CDB*/
   typedef struct osn_scsi_inquiry_cdb {
      uint8_t	ic_op_code;					/* operation code 0x12h */
      DECL_BITFIELD3(
            ic_evpd	:1,						/* EVPD */
            ic_obs	:1,						/* obsolete */
            ic_res	:6);					/* reserved */
      uint8_t	ic_pg_code;					/* page Code */
      uint8_t ic_alloc_len[2];			/* allocation Length */
      uint8_t ic_ctl;						/* control */
   } INQUIRY_CDB;

   /* Standard INQUIRY data */
   typedef struct osn_scsi_inquiry_data {
      DECL_BITFIELD2(
            id_peripheral_device_type	:5,	/* peripheral device type */
            id_peripheral_qualifier		:3);/* peripheral qualifier */
      DECL_BITFIELD2(
            _RES1	:7,						/* reserved */
            id_rmb	:1);					/* rmb */
      uint8_t id_version;					/* version */
      DECL_BITFIELD4(
            id_response_data_format	:4,		/* response data format */
            id_hisup		:1,				/* hisup */
            id_naca			:1,				/* normaca */
            _RES2			:2);			/* reserved */
      uint8_t additional_length;			/* additional length */
      DECL_BITFIELD6(
            id_protect	:1,					/* protect */
            _RES3		:2,					/* reserved */
            id_3pc		:1,					/* 3pc */
            id_tpgs		:2,					/* tpgs */
            id_acc		:1,					/* acc */
            id_sccs		:1);				/* sccs */
      DECL_BITFIELD7(
            id_addr16	:1,
            _RES4		:2,
            id_mchanger	:1,
            id_multip	:1,
            id_vs_6_5	:1,
            id_enc_serv	:1,
            id_b_que	:1);
      DECL_BITFIELD7(
            id_vs_7_0	:1,
            id_cmd_que	:1,
            _RES5		:1,
            id_linked	:1,
            id_sync		:1,
            id_wbus16	:1,
            _RES6		:2);
      uint8_t id_vendor_id[8];			/* T10 vendor identification */
      uint8_t id_product_id[16];			/* product identification */
      uint8_t id_product_revision[4];		/* product revision level */
      uint8_t id_vs_36[20];				/* vendor specific */
      DECL_BITFIELD4(
            id_ius		:1,
            id_qas		:1,
            id_clocking	:2,
            _RES7		:4);
      uint8_t _RES8;
      uint16_t id_version_descriptors[8];
      uint8_t _RES9[22];
      uint8_t id_vs_96[1];    /* Flexible */
   } INQUIRY_DATA;

   /* Unit Serial Number VPD Page*/
   typedef struct osn_scsi_inquiry_usn_data {
      DECL_BITFIELD2(
            id_peripheral_device_type	:5,
            id_peripheral_qualifier		:3);
      uint8_t	pg_code;					/* 0x80 */
      uint8_t _RES1;
      uint8_t pg_len;						/* page length */
      uint8_t _usn[DEF_ALLOC_LEN];		/* product serial number */
   } USN_DATA;

   /* Unit Serial Number VPD Page*/
   typedef struct osn_scsi_inquiry_t10_data {
      DECL_BITFIELD2(
            id_peripheral_device_type	:5,
            id_peripheral_qualifier		:3);
      uint8_t	pg_code;					/* 0x83 */
      uint8_t pg_len[2];					/* page length */
      uint8_t ddl[DEF_ALLOC_LEN];			/* Designation descriptor list */
   } T10_DATA;

   typedef struct osn_scsi_vpd_designator {
      DECL_BITFIELD2(
            code_set					:4,
            protocol_identifier			:4);
      DECL_BITFIELD4(
            designator_type				:4,
            association					:2,
            _RES1						:1,
            piv							:1);
      uint8_t designator_length;
      uint8_t *designator;
   } VPD_DES_DATA;

   typedef struct _MODE_SELECT10 {
      uint8_t op_code;					/* OSN CDP opration code, 0x55 */
      DECL_BITFIELD4(
            SPBit	:1,
            _RES1	:3,
            PFBit	:1,
            LUN	:3);
      uint8_t _RES2[5];
      uint8_t ParameterListLength[2];
      uint8_t Control;
   } MODE_SELECT10;

   typedef struct _MODE_PARAMETER_HEADER10 {
      uint8_t ModeDataLength[2];
      uint8_t MediumType;
      uint8_t DeviceSpecificParameter;
      uint8_t RES[2];
      uint8_t BlockDescriptorLength[2];
   } MODE_PARAMETER_HEADER10, *PMODE_PARAMETER_HEADER10;

   /*
    * Struct modified for Streamer 6.1.
    * Field Type and CreateTime are added to respect the new protocol.
    * Especially the CreateTime.
    * For all disks in the same consistency group,
    * their CreateTime should be the same.
    */
   typedef struct _OSN_MARKER_PAGE
   {
      MODE_PARAMETER_HEADER10	Header;
      DECL_BITFIELD3(
            PageCode:6,
            RES1:1,
            PageSavable:1);
      uint8_t PageLength[2];
      uint8_t Alignment[1];
//      uint8_t Type[1];
      uint8_t Pad[4];
//      uint8_t CreateTime[8];
   } OSN_MARKER_PAGE, *POSN_MARK_PAGE;

   typedef const struct _OsnScsiOps {
      /* invoke a SCSI INQUIRY command */
      int (*issue_inquiry) (OsnDevice* dev, int evpd, int pg_code,
            void *resp, int max_resp_len);
      int (*create_cdp) (OsnDevice* dev);
      int (*create_timecdp) (OsnDevice* dev);
      int (*create_grp_timecdp) (Osndevgrp *grp);
   } OsnScsiOps;

   int osn_device_issueinq_standard(OsnDevice* dev);
   int osn_device_issueinq_t10(OsnDevice* dev);
   int osn_device_issueinq_usn(OsnDevice* dev);
   int osn_device_createcdp(OsnDevice* dev);
   int osn_device_createtimecdp(OsnDevice* dev);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNSCSI_H_ */
