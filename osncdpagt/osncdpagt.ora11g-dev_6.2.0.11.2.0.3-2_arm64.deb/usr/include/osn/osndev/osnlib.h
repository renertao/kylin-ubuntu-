/*
 * osnlib.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNLIB_H_
#define OSNLIB_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <osn/osndev/osndev.h>
#include <osn/osndev/osnscsi.h>
#include <osn/osnpub/osnlog.h>

  /**
   * New enumerated type added since Streamer 6.1.
   * Before sending the SCSI MODE SELECT(10) command to target device,
   * we need to specify the attribute Type (unsigned char) of
   * struct OSN_MARKER_PAGE.
   */
  typedef enum {
    OSN_CDP_FOR_DISK = 2,
    OSN_CDP_FOR_GRP = 6
  } osn_cdp_type;

  /**
   * Union used to break an unsigned long integer into 8 unsigned bytes.
   * @attention: The byte order needs to be checked.
   */
  typedef union {
    unsigned long timestamp;
    unsigned char bytes[8];
  } osn_timestamp_t;

  typedef struct _OsnArch {
    OsnDevOps* dev_ops;
    OsnScsiOps* scsi_ops;
  } OsnArch;


  extern const OsnArch* osn_arch;
  extern int Osn_set_architecture(const OsnArch* arch);

  extern uint64_t get_current_timestamp_microsec();
  /*extern unsigned long get_current_timestamp_microsec();*/
  /*extern int using_little_endian();*/
  /*extern int endianness_swap();*/

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNLIB_H_ */
