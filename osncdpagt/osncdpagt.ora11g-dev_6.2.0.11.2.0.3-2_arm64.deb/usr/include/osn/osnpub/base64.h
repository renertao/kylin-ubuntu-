/*
 * base64.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 28, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef BASE64_H_
#define BASE64_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

char* base64_encode(const char *data);
char* base64_decode(const char *bdata); /* unsigned qualifier added by Yshou. */

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* BASE64_H_ */
