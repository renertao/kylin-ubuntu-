/*
 * osndes.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 9, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNDES_H_
#define OSNDES_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define OSN_DES_KEY	"infocore"

char* OSNEncrypt(char *Key, char *Msg, int size);
char* OSNDecrypt(char *Key, char *Msg, int size);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNDES_H_ */
