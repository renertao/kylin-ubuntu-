/*
 * osncfg.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 28, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNCFG_H_
#define OSNCFG_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <osn/osnpub/list.h>
#include <pthread.h>

#define OSNCFG_DEFAULT	"/etc/infocore/osn.cfg"
#define OSNCFG_ROOT		"osncfg"

   /*application subtree*/
#define	OSNCFG_APP		"app"
#define OSNCFG_APPENT	"appentry"
#define OSNCFG_APPENT_SVR	"server"
#define	OSNCFG_APPENT_TYPE	"type"
#define OSNCFG_APPENT_MODE	"mode"
#define OSNCFG_APPENT_NAME	"name"
#define OSNCFG_APPENT_USER	"username"
#define OSNCFG_APPENT_GRP	"usergroup"
#define OSNCFG_APPENT_PWD	"password"
#define OSNCFG_APPENT_IPATH	"installpath"
#define OSNCFG_APPENT_DPATH	"datapath"

#define OSNCFG_APPEND_HOST      "host"
#define OSNCFG_APPEND_PORT      "port"

#define OSNCFG_APPENT_ENV	"env"
#define OSNCFG_APPENT_PRIV	"private"
#define OSNCFG_APPENT_ID	"id"

   /*Device subtree*/
#define OSNCFG_DEV		"device"
#define OSNCFG_DEVENT	"deventry"
#define OSNCFG_DEVENT_GUID	"guid"
#define OSNCFG_DEVENT_PATH	"path"
#define OSNCFG_DEVENT_GRP	"group"
#define OSNCFG_DEVENT_CHK	"forcecheck"
#define OSNCFG_DEVENT_ID	"id"

   extern struct list_head	osndev_list;
   extern pthread_mutex_t osndev_list_lock;
   /*extern struct list_head	osndevgrp_list;*/
   extern struct list_head	osnapp_list;
   extern pthread_mutex_t osnapp_list_lock;

   int Osn_parse_cfgfile(char* docname);
   int Osn_update_cfgfile(char* docname);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNCFG_H_ */
