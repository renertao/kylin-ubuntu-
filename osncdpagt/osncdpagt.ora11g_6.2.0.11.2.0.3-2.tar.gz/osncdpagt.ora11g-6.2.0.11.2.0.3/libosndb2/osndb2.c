/*
 *   osndb2.c
 *   
 *   Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *   All rights reserved.
 *      
 *   Created on: Sep 6, 2012
 *   Author: tao.shang@infocore.cn
 *   http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

#include <osn/osnpub/osnlog.h>
#include <osn/osndb2/osndb2.h>

/*
 * Success: 1
 * Failure: 0
 *
 * I have no idea why the first dude who coded this had chosen these values. */ 
int osn_db2_precdpscripts(
        const char *usr, const char *dbname,
        const char *path) {

        int ret, status;
	setenv("DBADM",usr,1);
	char str[256] = "su - $DBADM  /usr/local/osncdpagt/scripts/precdp.sql ";

	strcat(str,path);
	strcat(str," ");
	strcat(str,dbname);
        log_info("Invoking Pre-CDP script: %s", str);

	ret = system(str);
	unsetenv("DBADM");
        if (ret < 0) {
            log_error("Failed to execute pre-CDP script.");
            return 0;
        }

        status = WEXITSTATUS(ret);
        if (status != 0) {
            log_error("Bad exit status of Pre-CDP script: %d.", status);
            return 0;
        } else {
            log_info("Pre-CDP script execution succeeded, ready to mark CDP point.");
            return 1;
        }
}

int osn_db2_postcdpscripts(
        const char *usr, const char *dbname,
        const char *path) {

	int ret, status;
	setenv("DBADM",usr,1);
	char str[256] = "su - $DBADM /usr/local/osncdpagt/scripts/postcdp.sql ";

	strcat(str,path);
	strcat(str," ");
	strcat(str,dbname);
        log_info("Invoking Post-CDP script: %s", str);

	ret = system(str);
	unsetenv("DBADM");
        if (ret < 0) {
            log_error("Failed to execute Post-CDP script.");
        }

        status = WEXITSTATUS(ret);
        if (status != 0) {
            log_error("Bad exit status of Post-CDP script: %d.", status);
            return 0;
        } else {
            log_info("Post-CDP script execution succeeded.");
            return 1;
        }
}

