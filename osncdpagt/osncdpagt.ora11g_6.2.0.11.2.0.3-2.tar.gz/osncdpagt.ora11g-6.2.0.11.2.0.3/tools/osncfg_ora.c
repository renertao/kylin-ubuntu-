/*
 * osncfg_ora.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 9, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include <string.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osncfg_ora";

static struct option const long_options[] =
{
   {"file", required_argument, 0, 'f'},
   {"replace", no_argument, 0, 'r'},
   {"verbose", required_argument, 0, 'v'},
   {"help", no_argument, 0, 'h'},
   {0, 0, 0, 0},
};

static void usage(int status)
{
   if (status != 0)
      fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
   else {
      printf("Usage: %s [OPTION]\n", program_name);
      printf("\
            Osncfg oracle tool.\n\
            -v, --verbose       in verbose mode(0-9), for debug only\n\
            -f, --file=[path]   using the specific config file.\n");
      printf("\
            -r, --replace       replace old config\n");
   }
   exit(1);
}

int main(int argc, char **argv){
   OsnApp *app, *n, *appentry = NULL;
   char input[256];
   char pwd1[256], pwd2[256];
   int level = 0;
   int replace = 0;
   int ch, longindex, id = 0, ret = -1;
   char *configfile = NULL;
   char *pwd = NULL;
   while ((ch = getopt_long(argc,argv,"f:v:rh",
               long_options, &longindex)) >= 0){
      switch (ch){
         case 'f':
            configfile = optarg;
            break;
         case 'v':
            level = strtol(optarg, NULL, 0);
            break;
         case 'r':
            replace = 1;
            break;
         case 'h':
            usage(0);
            break;
         default:
            usage(1);
            break;
      }
   }

   if(configfile == NULL){
      configfile = OSNCFG_DEFAULT;
   }
   osn_log_init(program_name);
   osn_set_logdaemon(0);
   osn_set_loglevel(level);

   ret = Osn_parse_cfgfile(configfile);
   if(ret && ret != -2){
      printf("Fail to parse config file %s\n", configfile);
      return -1;
   }

   appentry = malloc(sizeof(OsnApp));
   if(appentry == NULL){
      log_error("Unable to malloc memory for OsnApp");
      return -1 ;
   }
   memset(appentry, 0, sizeof(OsnApp));

   appentry->type = APP_ORACLE;
   appentry->name = "oracle";
   printf("Is Oracle running? (y/n)\n");
   scanf("%s", input);
   if(strcmp(input, "y") && strcmp(input, "Y") && strcmp(input, "yes")){
      return -1;
   }
   
   printf("Input the Oracle Service Name:\n");
   printf("(Check $ORACLE_HOME/network/admin/tnsnames.ora)\n");
   scanf("%s", input);
   list_for_each_entry_safe(app, n, &osnapp_list, osn_app_list_entry){
      if(app->id > id){
         id = app->id;
      }
      if(!strcmp(app->server, input)){
         if(replace){
            list_del(&app->osn_app_list_entry);
            free(app->name);
            free(app->server);
            free(app->usrname);
            free(app->usrgroup);
            free(app->passwd);
            free(app->datapath);
            free(app->installpath);
            free(app->priv);
            if (app->host) free(app->host);
            if (app->port) free(app->port);
            free(app);
         }
         else{
            printf("Oracle service %s exist,use -r to replace\n", app->server);
            return -1;
         }
      }
   }
   appentry->server = strdup(input);

   printf("Input the Oracle Host (default: 127.0.0.1):\n");
   scanf("%s", input);
   if (!strlen(input)) {
       appentry->host = strdup("127.0.0.1");
   } else {
       appentry->host = strdup(input);
   }

   printf("Input the Oracle port number (default: 1521):\n");
   scanf("%s", input);
   if(!strlen(input)) {
       appentry->port = strdup("1521");
   } else {
       appentry->port = strdup(input);
   }

   printf("Input the Oracle admin user id for service %s.(sys)\n", appentry->server);
   scanf("%s", input);
   if(!strlen(input)){
      appentry->usrname = strdup("sys");
   }
   else{
      appentry->usrname = strdup(input);
   }

   printf("Input the Oracle admin password for service %s.\n", appentry->server);
PWD:
   pwd = getpass("Password: ");
   sprintf(pwd1, "%s", pwd);
   if(pwd1[0] == '\0')
      goto PWD;
   pwd = getpass("Enter Again: ");
   sprintf(pwd2, "%s", pwd);
   if(strcmp(pwd1, pwd2)){
      printf("\n Passwords do not match!\n Try again.\n\n");
      goto PWD;
   }
   appentry->passwd = strdup(pwd);

ARC:
   printf("Is Oracle service %s archive logging on? (y/n).\n", appentry->server);
   scanf("%s", input);
   if(!strcmp(input, "y") || !strcmp(input, "Y")){
      appentry->mode = 1;
   }
   else if (!strcmp(input, "n") || !strcmp(input, "N")){
      appentry->mode = 0;
   }
   else{
      printf("bad input\n");
      goto ARC;
   }
   printf("What's the oracle home directory ?\n");
   scanf("%s", input);
   appentry->env = strdup(input);
   appentry->id = ++id;
   if ((ret = Osn_try_connect_db(appentry)) == -1) {
      printf("Unable to connect to %s, discard changes.\n", appentry->server);
      goto out;
   }
   list_add_tail(&appentry->osn_app_list_entry, &osnapp_list);
   ret = Osn_update_cfgfile(configfile);


out:
   return ret;
}
