/*
 * osncfg_db2.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: sep 14, 2012
 *      Author: tao.shang@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osncfg_db2";

static struct option const long_options[] =
{
	{"file", required_argument, 0, 'f'},
	{"replace", no_argument, 0, 'r'},
	{"verbose", required_argument, 0, 'v'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage: %s [OPTION]\n", program_name);
		printf("\
     Osncfg db2 tool.\n\
        -v, --verbose  level    in verbose mode, 0-9 for level\n\
        -f, --file=[path]   using the specific config file.\n");
		printf("\
        -r, --replace       replace old config\n");
	}
	exit(1);
}

int main(int argc, char **argv){
	OsnApp *app, *n, *appentry = NULL;
	char input[256];
	int level = 0;
	int replace = 0;
	int ch, longindex, id = 0, ret = -1;
	char *configfile = NULL;
	while ((ch = getopt_long(argc,argv,"f:v:rh",
			long_options, &longindex)) >= 0){
		switch (ch){
			case 'f':
				configfile = optarg;
				break;
			case 'v':
				level = strtol(optarg, NULL, 0);
				break;
			case 'r':
				replace = 1;
				break;
			case 'h':
				usage(0);
				break;
			default:
				usage(1);
				break;
		}
	}

	if(configfile == NULL){
		configfile = OSNCFG_DEFAULT;
	}
	osn_log_init(program_name);
	osn_set_logdaemon(0);
	osn_set_loglevel(level);

	ret = Osn_parse_cfgfile(configfile);
	if(ret && ret != -2){
		printf("Fail to parse config file %s\n", configfile);
		return -1;
	}

	appentry = malloc(sizeof(OsnApp));
	if(appentry == NULL){
		log_error("Unable to malloc memory for OsnApp");
		return -1 ;
	}
	memset(appentry, 0, sizeof(OsnApp));

	appentry->type = APP_DB2;
	appentry->name = "db2";
	printf("Is DB2 running? (y/n)\n");
	scanf("%s", input);
	if(strcmp(input, "y") && strcmp(input, "Y") && strcmp(input, "yes")){
		return -1;
	}
	printf("Input the DB2 DATABASE name\n");
	printf("(such as:sample):\n");
	scanf("%s", input);
	list_for_each_entry_safe(app, n, &osnapp_list, osn_app_list_entry){
		if(app->id > id){
			id = app->id;
		}
		if(!strcmp(app->server, input)){
			if(replace){
				list_del(&app->osn_app_list_entry);
				free(app->name);
				free(app->server);
				free(app->usrname);
				free(app->usrgroup);
				free(app->passwd);
				free(app->datapath);
				free(app->installpath);
				free(app->priv);
                                if (app->host) free(app->host);
                                if (app->port) free(app->port);
				free(app);
			}
			else{
				printf("DB2 service %s exist,use -r to replace\n", app->server);
				return -1;
			}
		}
	}
	appentry->server = strdup(input);
	
	printf("Input the DB2 INSTANCE name for DATABASE %s.\n(such as:db2inst):\n",appentry->server);
	scanf("%s",input);
	if(!strlen(input)){
		appentry->usrname = strdup("db2inst");
	}
	else{
		appentry->usrname = strdup(input);
	}

	printf("Input the DB2 bin directory\n");
env:	printf("(You can find it with command \"db2ls\"):\n");
	scanf("%s",input);
	if(!strlen(input)){
		printf("bad input directory ,please input again:\n");
		goto env;
	}else{
		appentry->env = strdup(input);
	}

	appentry->id = ++id;
	if((ret = Osn_try_connect_db(appentry)) == -1){
		printf("Unable to connect to %s,discard changes.\n",appentry->server);
		goto out;
	}
	list_add_tail(&appentry->osn_app_list_entry,&osnapp_list);
	ret = Osn_update_cfgfile(configfile);

out:
	return ret;

}	




