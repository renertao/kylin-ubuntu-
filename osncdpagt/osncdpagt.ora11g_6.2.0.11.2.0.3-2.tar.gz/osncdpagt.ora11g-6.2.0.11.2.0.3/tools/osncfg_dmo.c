/*
 * osncfg_dmo.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 22, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osncfg_dmo";

static struct option const long_options[] =
{
	{"file", required_argument, 0, 'f'},
	{"replace", no_argument, 0, 'r'},
	{"verbose", required_argument, 0, 'v'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage: %s [OPTION]\n", program_name);
		printf("\
     Osncfg Domino/Notes tool.\n\
        -v, --verbose  level    in verbose mode, 0-9 for level\n\
        -f, --file=[path]   using the specific config file.\n");
		printf("\
        -r, --replace       replace old config\n");
	}
	exit(1);
}

int main(int argc, char **argv){
	OsnApp *app, *n, *appentry = NULL;
	char input[256];
	int level = 0;
	int replace = 0;
	int ch, longindex, id = 0, ret = -1;
	char *configfile = NULL;
	input[0] = '\0';
	while ((ch = getopt_long(argc,argv,"f:v:rh",
			long_options, &longindex)) >= 0){
		switch (ch){
			case 'f':
				configfile = optarg;
				break;
			case 'v':
				level = strtol(optarg, NULL, 0);
				break;
			case 'r':
				replace = 1;
				break;
			case 'h':
				usage(0);
				break;
			default:
				usage(1);
				break;
		}
	}

	if(configfile == NULL){
		configfile = OSNCFG_DEFAULT;
	}
	osn_log_init(program_name);
	osn_set_logdaemon(0);
	osn_set_loglevel(level);

	ret = Osn_parse_cfgfile(configfile);
	if(ret && ret != -2){
		printf("Fail to parse config file %s\n", configfile);
		return -1;
	}

	appentry = malloc(sizeof(OsnApp));
	if(appentry == NULL){
		log_error("Unable to malloc memory for OsnApp");
		return -1 ;
	}
	memset(appentry, 0, sizeof(OsnApp));

	appentry->type = APP_NOTES;
	appentry->name = "domino";

	printf("What is the directory where Lotus Notes is installed?(/opt/ibm/lotus)\n");
	scanf("%s", input);
	if(input[strlen(input)-1] == '/'){
		input[strlen(input)-1] = '\0';
	}
	appentry->installpath = strdup(input);

	printf("What is the Lotus Notes data path?\n");
	scanf("%s", input);
	list_for_each_entry_safe(app, n, &osnapp_list, osn_app_list_entry){
		if(app->id > id){
			id = app->id;
		}
		if(app->type != APP_NOTES)
			continue;
		if(!strcmp(app->datapath, input)){
			if(replace){
				list_del(&app->osn_app_list_entry);
				free(app->name);
				free(app->server);
				free(app->usrname);
				free(app->usrgroup);
				free(app->passwd);
				free(app->datapath);
				free(app->installpath);
				free(app->priv);
                                if (app->host) free(app->host);
                                if (app->port) free(app->port);
				free(app);
			}
			else{
				printf("Domino/Notes data path %s exist,use -r to replace\n", app->datapath);
				return -1;
			}
		}
	}
	if(input[strlen(input)-1] == '/'){
		input[strlen(input)-1] = '\0';
	}
	appentry->datapath = strdup(input);
	printf("What is the Notes user ID?(notes)\n");
	scanf("%s", input);
	appentry->usrname = strdup(input);
	printf("What is the Notes group ID?(notes)\n");
	scanf("%s", input);
	appentry->usrgroup = strdup(input);
    if ((ret = Osn_try_connect_db(appentry)) == -1) {
        printf("Can not connect the DOMINO SERVER\n");
        goto out;
    }

	appentry->id = ++id;
	list_add_tail(&appentry->osn_app_list_entry, &osnapp_list);
	ret = Osn_update_cfgfile(configfile);
	printf("Please add Lotus Notes executable program libraries to $LIBPATH or $LD_LIBRARY_PATH variable\n");

out:
	return ret;
}


