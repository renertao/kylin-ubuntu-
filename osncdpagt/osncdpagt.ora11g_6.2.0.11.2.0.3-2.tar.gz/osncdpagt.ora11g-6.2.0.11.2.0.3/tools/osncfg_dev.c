/*
 * osncfg_dev.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 11, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osndev/osnlib.h>

const char program_name[] = "osncfg_dev";

static struct option const long_options[] =
{
   {"add", required_argument, 0, 'a'},
   {"delete", required_argument, 0, 'd'},
   {"file", required_argument, 0, 'f'},
   {"group", required_argument, 0, 'g'},
   {"verbose", no_argument, 0, 'v'},
   {"help", no_argument, 0, 'h'},
   {"list", no_argument, 0, 'l'},
   {0, 0, 0, 0},
};

static void usage(int status)
{
   if (status != 0)
      fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
   else {
      printf("Usage: %s [OPTION]\n", program_name);
      printf("\
            Osncfg device tool.\n\
            -l, --list	 list available osn storage device.\n");
      printf("\
            -a, --add   [device]       add new device\n\
            -f, --file  [path]         load configfile\n\
            -g, --group [group name]   add device to group,using with -a\n\
            -d, --del   [device]       delete device from configfile\n\
            -v, --verbose              print everything,for debugging\n");
   }
   exit(1);
}

static void list_devices()
{
   OsnDevice *ods = NULL;
   osn_device_probe_all(0);
   while ((ods = osn_device_get_next(ods))) {
      printf("%s\n", ods->path);
      printf("\tVid: %s\tPid: %s\tRev: %s\n",
            //				ods->vid, ods->pid, ods->rev);
         "NCS", "Solution", "4.0");
      printf("\tGUID: %s\n", ods->guid);
   }
}

   static Osndev*
search_cfg_device(char* path)
{
   Osndev *rdev = NULL;
   Osndev *dev;
   if(path == NULL){
      log_error("Input NULL device path");
      return NULL;
   }
   pthread_mutex_lock(&osndev_list_lock);
   list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
      if(!strcmp(dev->path, path)){
         rdev = dev;
         break;
      }
   }
   pthread_mutex_unlock(&osndev_list_lock);
   return rdev;
}

   static int
get_cfg_device_id()
{
   Osndev *dev;
   int id = 0;
   pthread_mutex_lock(&osndev_list_lock);
   list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
      if(dev->id > id){
         id = dev->id;
      }
   }
   pthread_mutex_unlock(&osndev_list_lock);
   return id;
}

int main(int argc, char **argv){
   int ch, longindex, ret = -1;
   int list = 0, add = 0, delete = 0, found = 0;
   int verbose = 0;
   char *device = NULL;
   char *group __attribute__((unused)) = NULL;
   char *cfgfile = NULL;
   Osndev *dev = NULL;
   while ((ch = getopt_long(argc, argv, "a:d:f:g:hlv",
               long_options, &longindex)) >= 0){
      switch (ch){
         case 'l':
            list = 1;
            break;
         case 'a':
            add = 1;
            device = optarg;
            break;
         case 'd':
            delete = 1;
            device = optarg;
            break;
         /*
         case 'g':
            group = optarg;
            break; */
         case 'f':
            cfgfile = optarg;
            break;
         case 'h':
            usage(0);
            break;
         case 'v':
            verbose = 1;
            break;
         default:
            usage(1);
            break;
      }
   }
   if(!add && !delete && !list){
      usage(0);
   }
   if(add && delete){
      printf("can't use -a with -d\n");
      exit(1);
   }
   if(add && device == NULL){
      printf("Please input the device to add\n");
      exit(1);
   }
   if(delete && device == NULL){
      printf("Please input the device to delete\n");
      exit(1);
   }

   if(verbose){
      osn_log_init(program_name);
      osn_set_logdaemon(0);
      osn_set_loglevel(DEBUG_SCSI);
   }

   if(list){
      list_devices();
      exit(1);
   }

   if(cfgfile == NULL){
      cfgfile = OSNCFG_DEFAULT;
   }
   ret = Osn_parse_cfgfile(cfgfile);
   if(ret && ret != -2){
      printf("Fail to parse config file %s\n", cfgfile);
      return -1;
   }
   if(ret == -2 && delete){
      exit(1);
   }

   if(add){
      OsnDevice *ods = NULL;
      osn_device_probe_all(0);
      while ((ods = osn_device_get_next(ods))) {
         if(!strcmp(ods->path, device)){
            found = 1;
            break;
         }
      }
      if(!found){
         printf("Disk not found!!\n");
         exit(1);
      }
      dev = search_cfg_device(device);
      if(dev != NULL){
         printf("Device %s already exist!\n", device);
         if(memcmp(dev->guid, ods->guid, GUID_LEN)){
            memcpy(dev->guid, ods->guid, GUID_LEN);
            ret = Osn_update_cfgfile(cfgfile);
         }
         exit(1);
      }
      else{
         dev = malloc(sizeof(Osndev));
         memset(dev, 0, sizeof(Osndev));
         dev->path = strdup(device);
         dev->id = get_cfg_device_id() + 1;
         memcpy(dev->guid, ods->guid, GUID_LEN);
         /*
         if(group != NULL){
            Osndevgrp *dgrp;
            list_for_each_entry(dgrp, &osndevgrp_list, grp_list_entry){
               if(!strcmp(dgrp->grp_name, group)){
                  dev->dgrp = dgrp;
                  list_add_tail(&dev->osn_grp_dev_entry, &dgrp->devs_list);
                  break;
               }
            }
            if(dev->dgrp == NULL){
               Osndevgrp *grp = malloc(sizeof(Osndevgrp));
               memset(dev, 0, sizeof(Osndevgrp));
               INIT_LIST_HEAD(&grp->grp_list_entry);
               INIT_LIST_HEAD(&grp->devs_list);
               list_add_tail(&grp->grp_list_entry, &osndevgrp_list);
               grp->grp_name = strdup((char *)group);
               dev->dgrp = grp;
               list_add_tail(&dev->osn_grp_dev_entry, &grp->devs_list);
            }
         }*/
         pthread_mutex_lock(&osndev_list_lock);
         list_add_tail(&dev->osn_dev_list_entry, &osndev_list);
         pthread_mutex_unlock(&osndev_list_lock);
         ret = Osn_update_cfgfile(cfgfile);
      }
   }
   else if(delete){
      dev = search_cfg_device(device);
      if(dev != NULL){
         list_del(&dev->osn_dev_list_entry);
         free(dev->path);
         free(dev);
         ret = Osn_update_cfgfile(cfgfile);
      }
   }
   return ret;
}
