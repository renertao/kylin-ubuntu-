/*
 * osncfg_ase.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 27, 2012
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osncfg_ase";

static struct option const long_options[] =
{
	{"file", required_argument, 0, 'f'},
	{"replace", no_argument, 0, 'r'},
	{"verbose", required_argument, 0, 'v'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage: %s [OPTION]\n", program_name);
		printf("\
     Osncfg mysql tool.\n\
        -v, --verbose  level    in verbose mode, 0-9 for level\n\
        -f, --file=[path]   using the specific config file.\n");
		printf("\
        -r, --replace       replace old config\n");
	}
	exit(1);
}

int main(int argc, char **argv){
	OsnApp *app, *n, *appentry = NULL;
	char input[256];
	char pwd1[256], pwd2[256];
	int level = 0;
	int replace = 0;
	int ch, longindex, id = 0, ret = -1;
	char *configfile = NULL;
	char *pwd = NULL;
	while ((ch = getopt_long(argc,argv,"f:v:rh",
			long_options, &longindex)) >= 0){
		switch (ch){
			case 'f':
				configfile = optarg;
				break;
			case 'v':
				level = strtol(optarg, NULL, 0);
				break;
			case 'r':
				replace = 1;
				break;
			case 'h':
				usage(0);
				break;
			default:
				usage(1);
				break;
		}
	}

	if(configfile == NULL){
		configfile = OSNCFG_DEFAULT;
	}
	osn_log_init(program_name);
	osn_set_logdaemon(0);
	osn_set_loglevel(level);

	ret = Osn_parse_cfgfile(configfile);
	if(ret && ret != -2){
		printf("Fail to parse config file %s\n", configfile);
		return -1;
	}

	appentry = malloc(sizeof(OsnApp));
	if(appentry == NULL){
		log_error("Unable to malloc memory for OsnApp");
		return -1 ;
	}
	memset(appentry, 0, sizeof(OsnApp));

	appentry->type = APP_SYBASE;
	appentry->name = "sybase";
	printf("Is Sybase running? (y/n)\n");
	scanf("%s", input);
	if(strcmp(input, "y") && strcmp(input, "Y") && strcmp(input, "yes")){
		return -1;
	}
	printf("Input the Sybase sock path:\n");
	scanf("%s", input);
	list_for_each_entry_safe(app, n, &osnapp_list, osn_app_list_entry){
		if(app->id > id){
			id = app->id;
		}
		if(!strcmp(app->server, input)){
			if(replace){
				list_del(&app->osn_app_list_entry);
				free(app->name);
				free(app->server);
				free(app->usrname);
				free(app->usrgroup);
				free(app->passwd);
				free(app->datapath);
				free(app->installpath);
				free(app->priv);
                                if (app->host) free(app->host);
                                if (app->port) free(app->port);
				free(app);
			}
			else{
				printf("Sybase sock %s exist,use -r to replace\n", app->server);
				return -1;
			}
		}
	}
	if(!strlen(input)){
		appentry->server = NULL;
	}
	else{
		appentry->server = strdup(input);
	}
	printf("Input the Sybase admin user id for sock %s\n", appentry->server);
	scanf("%s", input);
	if(!strlen(input)){
		appentry->usrname = strdup("sa");
	}
	else{
		appentry->usrname = strdup(input);
	}

	printf("Input the Sybase admin password for sock %s.\n", appentry->server);
PWD:
	pwd = getpass("Password: ");
	sprintf(pwd1, "%s", pwd);
	if(pwd1[0] == '\0')
		goto PWD;
	pwd = getpass("Enter Again: ");
	sprintf(pwd2, "%s", pwd);
	if(strcmp(pwd1, pwd2)){
		printf("\n Passwords do not match!\n Try again.\n\n");
		goto PWD;
	}
	appentry->passwd = strdup(pwd);
#if 0
    if ((ret = Osn_try_connect_db(appentry)) == -1) {
        printf("Can not connect the Sybase SERVER\n");
        goto out;
    }
#endif

	appentry->id = ++id;
	list_add_tail(&appentry->osn_app_list_entry, &osnapp_list);
	ret = Osn_update_cfgfile(configfile);

	return ret;
}
