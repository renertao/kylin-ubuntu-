/*
 * osncfg.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 11, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osncfg";
char *configfile = NULL;
static struct option const long_options[] =
{
	{"delete", required_argument, 0, 'd'},
	{"file", required_argument, 0, 'f'},
	{"help", no_argument, 0, 'h'},
	{"id", required_argument, 0, 'i'},
	{"list", required_argument, 0, 'l'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage: %s [OPTION]\n", program_name);
		printf("\
     Osncfg tool.\n\
        -f, --file   [path]           using the specific config file.\n");
		printf("\
        -d, --delete [app/dev]       delete defined app or device from config file\n\
        -i, --id     [app id/dev id] using -i with -d option\n\
        -l, --list   [all/app/dev]   list apps or devices defined in config file\n");
	}
	exit(1);
}

static void
printf_app_oracle(OsnApp *app)
{
	printf("\tServer:  \t\t%s\n", app->server);
	printf("\tLogin User:\t\t%s\n", app->usrname);
	printf("\tOracle HOME:\t\t%s\n", app->env);
}

static void
printf_app_domino(OsnApp *app)
{
	printf("\tData Path:   \t\t%s\n", app->datapath);
	printf("\tInstall Path:\t\t%s\n", app->installpath);
	printf("\tNotes User:\t\t%s\n", app->usrname);
	printf("\tNotes Group:\t\t%s\n", app->usrgroup);
}

static void
printf_app_sybase(OsnApp *app)
{
	printf("\tServer:  \t\t%s\n", app->server);
	printf("\tLogin User:\t\t%s\n", app->usrname);
}

static void
printf_app_db2(OsnApp *app)
{
	printf("\tServer:  \t\t%s\n", app->server);
	printf("\tLogin User:\t\t%s\n", app->usrname);
}

static void
printf_app_infomix(OsnApp *app)
{
	printf("\tServer:  \t\t%s\n", app->server);
	printf("\tLogin User:\t\t%s\n", app->usrname);
}

static void
printf_app_mysql(OsnApp *app)
{
	printf("\tSock:      \t\t%s\n", app->server);
	printf("\tLogin User:\t\t%s\n", app->usrname);
}

static void
list_allapp()
{
	OsnApp *app;
	printf("\napp list:\n");
	printf("--------------------------\n");
	list_for_each_entry(app, &osnapp_list, osn_app_list_entry){
		printf("ID: %d\n", app->id);
		printf("\tType:   \t\t%s\n", app->name);
		switch(app->type){
		case APP_ORACLE:
			printf_app_oracle(app);
			break;
		case APP_NOTES:
			printf_app_domino(app);
			break;
		case APP_SYBASE:
			printf_app_sybase(app);
			break;
		case APP_DB2:
			printf_app_db2(app);
			break;
		case APP_INFOMIX:
			printf_app_infomix(app);
			break;
		case APP_MYSQL:
			printf_app_mysql(app);
			break;
		}	

	}
}

static void
list_alldev()
{
	Osndev *dev;
	printf("\nDevice list:\n");
	printf("--------------------------\n");
	pthread_mutex_lock(&osndev_list_lock);
	list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
		printf("ID: %d\n", dev->id);
		if(dev->dgrp != NULL){
			printf("\tGroup:\t%s\n",dev->dgrp->grp_name);
		}
		printf("\tGUID:\t%s\n", dev->guid);
		printf("\tPath:\t%s\n", dev->path);
	}
	pthread_mutex_unlock(&osndev_list_lock);
}

static int
delete_app(int id)
{
	OsnApp *app;
	int found = 0;
	list_for_each_entry(app, &osnapp_list, osn_app_list_entry){
		if(app->id == id){
			list_del(&app->osn_app_list_entry);
			free(app->name);
			free(app->server);
			free(app->usrname);
			free(app->usrgroup);
			free(app->passwd);
			free(app->datapath);
			free(app->installpath);
			free(app->priv);
                        if (app->host) free(app->host);
                        if (app->port) free(app->port);
			free(app);
			found = 1;
			break;
		}
	}
	if(found){
		Osn_update_cfgfile(configfile);
	}
	else{
		printf("App with id %d not found!", id);
	}
	return found;
}

static int
delete_dev(int id)
{
	Osndev *dev;
	int found = 0;
	pthread_mutex_lock(&osndev_list_lock);
	list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
		if(dev->id == id){
			list_del(&dev->osn_dev_list_entry);
			free(dev->path);
			free(dev);
			found = 1;
			break;
		}
	}
	pthread_mutex_unlock(&osndev_list_lock);
	if(found){
		Osn_update_cfgfile(configfile);
	}
	else{
		printf("Device with id %d not found!", id);
	}
	return found;
}

int main(int argc, char **argv){
	int ch, longindex, ret = -1;
	char *list_opt = NULL;
	char *del_opt = NULL;
	int id = -1;
	int opt = 0; /* 1,2,3 for list ,4,5 for del */
	while ((ch = getopt_long(argc,argv,"d:f:hi:l:",
				long_options, &longindex)) >= 0){
		switch (ch){
		case 'l':
			list_opt = optarg;
			if(!strcmp(list_opt, "all")){
				opt = 1;
			}
			else if(!strcmp(list_opt, "app")){
				opt = 2;
			}
			else if(!strcmp(list_opt, "dev")){
				opt = 3;
			}
			else{
				usage(1);
			}
			break;
		case 'd':
			del_opt = optarg;
			if(!strcmp(del_opt, "app")){
				opt = 4;
			}
			else if(!strcmp(del_opt, "dev")){
				opt = 5;
			}
			else{
				usage(1);
			}
			break;
		case 'i':
			id = (int)strtoul(optarg, NULL, 0);
			break;
		case 'f':
			configfile = optarg;
			break;
		case 'h':
			usage(0);
			break;
		default:
			usage(1);
			break;
		}
	}
	if( opt == 4 || opt ==5 ){
		if(id == -1){
			printf("Please specify the app id or dev id with -i option\n");
			exit(1);
		}
	}
	if(configfile == NULL){
		configfile = OSNCFG_DEFAULT;
	}

	ret = Osn_parse_cfgfile(configfile);
	if(ret && ret != -2){
		printf("Fail to parse config file %s\n", configfile);
		return -1;
	}
	if(opt == 0){
		usage(0);
	}
	if(opt == 1 || opt == 2){
		list_allapp();
	}
	if(opt == 1 || opt == 3){
		list_alldev();
	}
	if(opt == 4){
		delete_app(id);
	}
	if(opt == 5){
		delete_dev(id);
	}
	return 0;
}
