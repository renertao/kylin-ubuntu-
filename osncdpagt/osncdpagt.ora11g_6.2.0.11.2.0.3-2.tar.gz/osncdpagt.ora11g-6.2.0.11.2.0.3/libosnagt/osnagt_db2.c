/*
 * osnagt_db2.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Sep 11, 2012
 *      Author: tao.shang@infocore.cn
 *      http://www.infocore.cn
 */

#include <osn/osnagt/osnagt.h>
#include <osn/osndb2/osndb2.h>
#include <osn/osnpub/osnlog.h>

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

/*return 1 success, 0 fail , -1 error*/

int db2_precdpscripts(OsnApp* app)
{
	int ret = 0;
	ret = osn_db2_precdpscripts(app->usrname,app->server,app->env);
	if(ret){
		app->status = 1;/*need post process*/
		log_debug(DEBUG_APP,"DB2 Pre-CDP script executed successfully");
	}else{
		log_error("DB2 Pre-CDP script execution failed.");
	}
	return ret;
}

int db2_postcdpscripts(OsnApp* app)
{
	int ret = 0;
	ret = osn_db2_postcdpscripts(app->usrname,app->server,app->env);
	if(ret){
		app->status = 0;/*clean status*/
		log_debug(DEBUG_APP,"DB2 Post-CDP script executed successfully");
	}else{
		log_error("DB2 Post-CDP script execution failed.");
	}
	return ret;
}

OsnAgtOps osndb2 = {
		.osnprecdp_scripts = db2_precdpscripts,
		.osnpostcdp_scripts = db2_postcdpscripts
};

