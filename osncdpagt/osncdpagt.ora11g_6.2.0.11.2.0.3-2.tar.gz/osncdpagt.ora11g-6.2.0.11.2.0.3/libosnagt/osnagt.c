/*
 * osncore.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 28, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>
#include <osn/osnpub/list.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osndev/osnlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#ifdef oracle
/** XXX: DEPRECATED
#include <osn/osnora/osnora.h> **/
#endif

#ifdef _mysql_
#include <osn/osnmql/osnmql.h>
#endif

#ifdef domino
#include <osn/osndmo/osndmo.h>
#endif

#ifdef _db2_
#include <osn/osndb2/osndb2.h>
#endif

static int _Osn_free_app(OsnApp *app) {
    if (app == NULL) {
        return  -1;
    }
    if(app->server) free(app->server);
    if(app->name) free(app->name);
    if(app->usrname) free(app->usrname);
    if(app->usrgroup) free(app->usrgroup);
    if(app->passwd) free(app->passwd);
    if(app->installpath) free(app->installpath);
    if(app->datapath) free(app->datapath);
    if(app->env) free(app->env);
    if(app->host) free(app->host);
    if(app->port) free(app->port);

    if(app->priv) {
        log_warning("Field <priv> of application is not null, "
                "don't know how to free it.");
    }
    free(app);
    return 0;
}

static int _Osn_free_dev(Osndev *dev) {
    
    if (dev == NULL) {
        return -1;
    }

    if (dev->path) free(dev->path);
    if (dev->dgrp) {
        if (dev->dgrp->grp_name)
            free(dev->dgrp->grp_name);
        free(dev->dgrp);
    }
    free(dev);
    return 0;
}

static int _Osn_clear_app_list() {
    
    OsnApp *ite_app, *tmp_app;

    log_debug(DEBUG_APP, "Clear global APP list.");
    pthread_mutex_lock(&osnapp_list_lock);
    if (list_empty(&osnapp_list)) {
        log_debug(DEBUG_APP, "Global APP list is already empty, nothing to free.");
        pthread_mutex_unlock(&osnapp_list_lock);
        return 0;
    }
    pthread_mutex_unlock(&osnapp_list_lock);
    
    pthread_mutex_lock(&osnapp_list_lock);
    list_for_each_entry_safe(ite_app, tmp_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "App [%s] free'd.", (ite_app->server ? ite_app->server : "Unknown"));
        list_del(&ite_app->osn_app_list_entry);
        _Osn_free_app(ite_app); 
    }
    pthread_mutex_unlock(&osnapp_list_lock);
    log_debug(DEBUG_APP, "Global APP list free'd.");

    return 0;
}

static int _Osn_clear_dev_list() {
    
    Osndev *ite_dev, *tmp_dev;

    log_debug(DEBUG_DEV, "Clear global device list.");
    pthread_mutex_lock(&osndev_list_lock);
    if (list_empty(&osndev_list)) {
        log_debug(DEBUG_DEV, "Global device list is already empty, nothing to free.");
        pthread_mutex_unlock(&osndev_list_lock);
        return 0;
    }
    pthread_mutex_unlock(&osndev_list_lock);

    pthread_mutex_lock(&osndev_list_lock);
    list_for_each_entry_safe(ite_dev, tmp_dev, &osndev_list, osn_dev_list_entry) {
        log_debug(DEBUG_DEV, "Device [%s] free'd.", (ite_dev->path ? ite_dev->path : "Unknown"));
        list_del(&ite_dev->osn_dev_list_entry);
        _Osn_free_dev(ite_dev);
    }
    pthread_mutex_unlock(&osndev_list_lock);
    log_debug(DEBUG_DEV, "Global device list free'd.");

    return 0;
}

static int _Osn_clear_global_lists() {
    if (_Osn_clear_app_list() < 0) {
        log_error("Failed to clear global APP list.");
        return -1;
    }
    if (_Osn_clear_dev_list() < 0) {
        log_error("Failed to clear global device list.");
        return -1;
    }
    return 0;
}

static int filter(const struct dirent *s)
{
   if (s == NULL || s->d_name[0] == '.')
       return 0;
   return 1;
}

int is_EIM_disk(Osndev *deventry)
{
   struct dirent **filelist;
   char dev_dir[MAX_NAME_LEN] = {0};
   int i, num, is_EIM = 0;
   char guid[GUID_LEN] = {0};

   if (!deventry) {
      log_error("deventry is NULL!");
   }
   
   strcpy(guid, ((char *)deventry->guid)+1);
   guid[strlen(guid) - 1] = '\0';

   strncpy(dev_dir, BY_ID_DIR, MAX_NAME_LEN);

   if (-1 == (num = scandir(dev_dir, &filelist, filter, alphasort))) {
      return 0;
   }
   for (i = 0; i < num; i++) {
      if (NULL != strstr(filelist[i]->d_name, guid)) {
//         if (NULL != strstr(filelist[i]->d_name, "EIM")) {
//            log_debug(DEBUG_APP, "%s|%s is EIM disk.", 
//                 deventry->path, filelist[i]->d_name);
        is_EIM = 1;
//         } else {
//            log_debug(DEBUG_APP, "%s|%s is not EIM disk.", deventry->path, filelist[i]->d_name);
//         }
//         break;
      }
   }
   for (i = 0; i < num; i++) {
        free(filelist[i]);
   }
   free(filelist);
   return is_EIM;
}

/**
 * Get the device having specified GUID.
 * If the device cannot be found, rescan all devices.
 *
 * @param guid The guid of device.
 * @param save Unused.
 * @return The device having specified guid, or NULL.
 */
Osndev* Osn_getdev(const char* guid, const char* path, int save) {
    Osndev *deventry, *dev = NULL;
    OsnDevice *ods = NULL;
    int _fd;
    if(guid == NULL || path == NULL) {
        log_error("Guid or Path parameter is NULL!");
        return NULL;
    }
    /*looking for device in device list according guid*/
    pthread_mutex_lock(&osndev_list_lock);
    log_debug(DEBUG_APP, "Osn_getdev: Try to get device of [%s] in osndev_list.",
            (guid ? guid : "Unkown"));
    list_for_each_entry(deventry, &osndev_list, osn_dev_list_entry) {
        log_debug(DEBUG_APP, "guid is %s, path is %s.", deventry->guid, deventry->path);
        if(!strcmp((const char *)deventry->guid, guid)) {
            log_debug(DEBUG_APP, "Osn_getdev: Found device [%s][%s] in osndev_list.",
                    (guid ? guid : "Unkown GUID"),
                    (deventry->path ? deventry->path : "Unknown path"));
            if (1 != is_EIM_disk(deventry)) {
               log_debug(DEBUG_APP, "%s is not EIM disk.", deventry->guid);
               dev = NULL;
            }  else if (strcmp(path, deventry->path)) {
               log_debug(DEBUG_APP, "disk path changed old : %s, new : %s.", deventry->path, path);
               dev = NULL;
            } else {
               dev = deventry;
            }
            break;
        }
    }
    pthread_mutex_unlock(&osndev_list_lock);

    if(dev == NULL) {
        /* scan for device */
        osn_device_probe_all(1);
        while ((ods = osn_device_get_next(ods))) {

            if(!strcmp((const char *) ods->guid, guid)) {
                dev = malloc(sizeof(Osndev));
                if(dev == NULL){
                    log_error("fail to alloc memory for Osndev");
                    return NULL;
                }
                memset(dev, 0, sizeof(Osndev));
                dev->path = strdup(ods->path);
                strcpy((char *) dev->guid, (const char *) ods->guid);

                /*XXX: These devices in the list will never be free'd. !!! */
                pthread_mutex_lock(&osndev_list_lock);
                list_add_tail(&dev->osn_dev_list_entry, &osndev_list);
                pthread_mutex_unlock(&osndev_list_lock);
                break;
            }
        }
        Osn_update_cfgfile(OSNCFG_DEFAULT);
    }

    /* FIXME fix strdup memory leak */
    return dev;
}

/*
 * 0 failed
 * 1 success
 */
int Osn_try_connect_db(OsnApp *app)
{
#ifdef _db2_
    int status; /* This variable is only used when compiled for db2. */
#endif
    int ret = 0;

    if(app->type == APP_ORACLE) {
#ifdef oracle
        /* Connect to database */
        if(osnora.osncdp_conndb) {
            ret = osnora.osncdp_conndb(app);
            if(!ret) {
                log_error("Connecting oracle database failed!");
                ret = -1;
            }
        } else {
            log_error("No Database Connection function defined!");
        }
#else
        log_error("Database(Oracle) Not supported yet!");
#endif
    } else if(app->type == APP_NOTES) {
#ifdef domino
        /* Initialize Domino/Notes */
        if(osndmo.osncdp_conndb){
            ret = osndmo.osncdp_conndb(app);
            if(!ret) {
                log_error("Initializing Domino/Notes failed!");
                ret = -1;
            } else {
                if(osndmo.osncdp_disconndb){
                    osndmo.osncdp_disconndb(app);
                }
            }
        } else{
            log_error("Domino/Notes initial function not defined!");
        }
#else
        log_error("Domino/Notes Not supported yet!");
#endif
    } else if(app->type == APP_SYBASE) {
#ifdef sybase
        if (osnase.osncdp_conndb) {
            ret = osnase.osncdp_conndb(app);
            if (!ret) {
                log_error("Initializing SYBASE failed!");
                ret = -1;
            } else {
                if (osnase.osncdp_disconndb) {
                    osnase.osncdp_disconndb(app);
                }
            }
        } else {
            log_error("SYBASE initial function not defined");
        }
#else
        log_error("SYBASE Not supported yet!");
#endif
        ret = 0;
    } else if(app->type == APP_DB2) {
#ifdef _db2_
        setenv("DBADM",app->usrname,1);
        char str[256] = "su - $DBADM /usr/local/osncdpagt/scripts/con_try.sh ";
        char *dbname = app->server;
        char *bin_path = app->env;
        strcat(str,bin_path);
        strcat(str," ");
        strcat(str,dbname);
        log_info("Invoking db connection script: %s", str);

        ret = system(str);
        unsetenv("DBADM");

        if (ret < 0) {
            log_error("Failed to execute db connection script.");
            ret = -1;
        }

        status = WEXITSTATUS(ret);
        if (status == 0) {
            log_info("DB2 connection succeeded.");
            ret = 1;
        } else {
            log_info("BAD exit status of db connection script: %d", status);
            ret = -1;
        }

#else
        log_error("Db2 Not supported yet!");
#endif

    } else if(app->type == APP_INFOMIX) {
        ret = 0;
    } else if(app->type == APP_MYSQL){
#ifdef _mysql_
        /* Connect to database */
        if(osnmql.osncdp_conndb) {
            ret = osnmql.osncdp_conndb(app);
            if(!ret){
                log_error("Connecting MySQL database failed!");
                ret = -1;
            } else {
                if(osnmql.osncdp_disconndb){
                    osnmql.osncdp_disconndb(app);
                }
            }
        } else {
            log_error("No Database Connection function defined!");
        }
#else
        log_error("Database(MySQL) Not supported yet!");
#endif
    } else {
        log_error("Application type[%d] not supported!", app->type);
    }
    return ret;
}

/**
 * Add a database to config file.
 * The function tries to connect to the given db, if success,
 * add the db to global list osnapp_list.
 * 
 * @param app The db to be added.
 * @return 0 if db is correctly connected and added, or -1.
 */
int Osn_connect_db_flush_cfg(OsnApp *app) {
    int ret;
    if ((ret = Osn_try_connect_db(app)) == -1) {
        log_error("Unable to connect to %s, discard changes.", app->server);
        return -1;
    }
    list_add_tail(&app->osn_app_list_entry, &osnapp_list);
    Osn_update_cfgfile(OSNCFG_DEFAULT);

    return 0;
}

/*
 * 0 failed
 * 1 success
 */
int Osn_preprocess()
{
    OsnApp *app;
    /*OsnApp *itr_app;*/
    int ret = 0;

    /*
    log_debug(DEBUG_APP, "app list before empty test.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/
    if(list_empty(&osnapp_list)){
        log_debug(DEBUG_APP, "No applicaton defined, mark cdp anyway.");
        return 1;
    }

    /*
    log_debug(DEBUG_APP, "app list before preprocess.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/

    /* application pre process */
    pthread_mutex_lock(&osnapp_list_lock);
    list_for_each_entry(app, &osnapp_list, osn_app_list_entry){
        if(app->type == APP_ORACLE){
#ifdef oracle
            /* Execute precdp scripts */
            if(osnora.osnprecdp_scripts){
                ret = osnora.osnprecdp_scripts(app);
                if(!ret)
                    break;
            }
            else{
                log_debug(DEBUG_APP, "Notice: precdp script not defined.");
            }
            /* Connect to database */
            if(app->mode == 1){
                /* archive mode */
                /* Execute precdp oracle commands */
                if(osnora.osnprecdp_process){
                    ret = osnora.osnprecdp_process(app);
                    if(!ret)
                        break;
                }
                else{
                    log_debug(DEBUG_APP, "No Database precdp function defined!");
                    return -1;
                }
            }else{
                /* non archive mode */
                if(osnora.osncdp_process){
                    ret = osnora.osncdp_process(app);
                    if(!ret)
                        break;
                }
                else{
                    log_debug(DEBUG_APP, "No Database flush function defined!");
                    return -1;
                }
            }
#else
            log_error("Database(Oracle) Not supported yet!");
            continue;
#endif
        }
        else if(app->type == APP_NOTES){
#ifdef domino
            /* Execute precdp scripts */
            if(osndmo.osnprecdp_scripts){
                ret = osndmo.osnprecdp_scripts(app);
                if(!ret)
                    break;
            }
            else{
                log_debug(DEBUG_APP, "Notice: Domino precdp script not defined.");
            }
            /* Initialize Domino/Notes */
            if(osndmo.osncdp_conndb){
                ret = osndmo.osncdp_conndb(app);
                if(!ret){
                    log_error("Initializing Domino/Notes failed!");
                    break;
                }
            }
            else{
                log_error("Domino/Notes initial function not defined!");
                return -1;
            }

            if(osndmo.osnprecdp_process){
                ret = osndmo.osnprecdp_process(app);
                if(!ret){
                    break;
                }
            }
            else{
                log_debug(DEBUG_APP, "No Domino/Lotus precdp function defined!");
                return -1;
            }
#else
            log_error("Domino/Notes Not supported yet!");
            continue;
#endif
        }
        else if(app->type == APP_SYBASE){
#ifdef sybase
            if(osnase.osncdp_process) {
                ret = osnase.osncdp_process(app);
                if(!ret) {
                    break;
                }
            } else {
                log_debug(DEBUG_APP, "No SYBASE flush function defined!");
                return -1;
            }
#else
            log_error("SYBASE Not supported yet!");
            continue;
#endif
        }
        else if(app->type == APP_DB2){
#ifdef _db2_
            /* Execute precdp scripts */
            if(osndb2.osnprecdp_scripts){
                ret = osndb2.osnprecdp_scripts(app);
                if(!ret)
                    break;
            }else{
                log_debug(DEBUG_APP, "Notice: precdp script not defined.");
            }
#else
            log_error("Database(DB2) Not supported yet!");
            continue;
#endif

        }
        else if(app->type == APP_INFOMIX){
            if(!ret)
                break;
        }
        else if(app->type == APP_MYSQL){
#ifdef _mysql_
            /* Execute precdp scripts */
            if(osnmql.osnprecdp_scripts){
                ret = osnmql.osnprecdp_scripts(app);
                if(!ret)
                    break;
            }
            else{
                log_debug(DEBUG_APP, "Notice: precdp script not defined.");
            }
            /* Connect to database */
            if(osnmql.osncdp_conndb){
                ret = osnmql.osncdp_conndb(app);
                if(!ret){
                    log_error("Connecting MySQL database failed!");
                    break;
                }
            }
            else{
                log_error("No Database Connection function defined!");
                return -1;
            }
            if(osnmql.osncdp_process){
                ret = osnmql.osncdp_process(app);
                if(!ret)
                    break;
            }
            else{
                log_debug(DEBUG_APP, "No Database flush function defined!");
                return -1;
            }
#else
            log_error("Database(MySQL) Not supported yet!");
            continue;
#endif
        }
        else{
            log_error("Application type[%d] not supported!", app->type);
            break;
        }
    }
    pthread_mutex_unlock(&osnapp_list_lock);
    return ret;
}

void Osn_postprocess() {
    int ret = 0;
    OsnApp *app;
    /* application post process */

    pthread_mutex_lock(&osnapp_list_lock);
    list_for_each_entry(app, &osnapp_list, osn_app_list_entry) {
        /*
        log_debug(DEBUG_APP, "Handling app No. %d [Prev: %ld] [Next: %ld].", counter,
                app->osn_app_list_entry.prev, app->osn_app_list_entry.next);*/
        if(app->type == APP_ORACLE) {
#ifdef oracle
            if(app->status){
                /* archive mode */
                if(app->mode == 1 && osnora.osnpostcdp_process) {
                    ret = osnora.osnpostcdp_process(app);
                    if(!ret)
                        log_error("Execute Oracle postcdp command failed!");
                }
            }
            if(osnora.osnpostcdp_scripts) {
                ret = osnora.osnpostcdp_scripts(app);
                if(!ret)
                    log_error("Oracle post scripts error");
            }
#endif
        }
        else if(app->type == APP_NOTES) {
#ifdef domino
            if(app->status){
                if(osndmo.osnpostcdp_process){
                    ret = osndmo.osnpostcdp_process(app);
                    if(!ret)
                        log_error("Execute Domino/Notes postcdp command failed!");
                }
            }
            if(osndmo.osnpostcdp_scripts) {
                ret = osndmo.osnpostcdp_scripts(app);
                if(!ret)
                    log_error("Domino/Notes post scripts error");
            }
#endif
        }
        else if(app->type == APP_SYBASE) {
#ifdef sybase
            if(app->status) {
                if(osnase.osnpostcdp_process) {
                    ret = osnase.osnpostcdp_process(app);
                    if(!ret)
                        log_error("Execute SYBASE postcdp command failed!");
                }
            }
            if(osnase.osnpostcdp_scripts) {
                ret = osnase.osnpostcdp_scripts(app);
                if(!ret)
                    log_error("SYBASE post scripts error");
            }
#endif
        }
        else if(app->type == APP_DB2) {
#ifdef _db2_
            if(app->status){
                if(osndb2.osnpostcdp_scripts) {
                    ret = osndb2.osnpostcdp_scripts(app);
                    if(!ret)
                        log_error("DB2 post scripts error");
                }
            }
#else
            log_error("Database(DB2) Not supported yet!");
#endif

        }
        else if(app->type == APP_INFOMIX){

        }
        else if(app->type == APP_MYSQL){
#ifdef _mysql_
            if(app->status){
                if(osnmql.osnpostcdp_process){
                    ret = osnmql.osnpostcdp_process(app);
                    if(!ret)
                        log_error("Execute MySQL postcdp command failed!");
                }
            }
            if(osnmql.osnpostcdp_scripts){
                ret = osnmql.osnpostcdp_scripts(app);
                if(!ret)
                    log_error("MySQL post scripts error");
            }
            if(osnmql.osncdp_disconndb){
                osnmql.osncdp_disconndb(app);
            }
#else
            log_error("Database(MySQL) Not supported yet!");
#endif
        }
        /*log_debug(DEBUG_APP, "App No. %d processed.", counter);*/
    }
    pthread_mutex_unlock(&osnapp_list_lock);
}

/**
 * Create CDP point by calling the utility osncdp_internal.
 */
static int Osn_markcdp_systemcall(Osndev* dev, int type) {
    char cmdline[256];
    int ret = 0;
    memset(cmdline, 0, sizeof (cmdline));
    if(!type)
        sprintf(cmdline,"%s %s", "osncdp_internal", dev->path);
    else
        sprintf(cmdline,"%s %s timemark", "osncdp_internal", dev->path);

    cmdline[sizeof (cmdline) - 1] = '\0';
    ret = system(cmdline);
    if(ret)
        log_error("Failed to mark cdp on device %s", dev->path);
    else
        log_debug(DEBUG_APP, "Marking cdp for %s successfully!", dev->path);

    return ret;
}

static int Osn_markcdp_single(Osndev* dev, int type) {

    OsnDevice *ods = NULL;
    int ret,res = 0;

    ods = calloc (1, sizeof(OsnDevice));
    if(ods == NULL){
        log_error("Failed to alloc memory for struct OsnDevice");
        return -1;
    }

    ods->path = strdup(dev->path);
    if(!type)
        ret = osn_device_createcdp(ods);
    else
        ret = osn_device_createtimecdp(ods);
    if(ret){
        log_error("Failed to mark cdp on device %s", ods->path);
        res = -1;
    }
    else{
        log_debug(DEBUG_APP, "Marking cdp for device %s successfully!", ods->path);
    }
    free(ods->path);
    free(ods);
    return res;
}

/**
 * @param type always 1
 */
int Osn_markcdp_group(Osndev* dev, int mode, int type) {
    Osndev *deventry __attribute__((unused));
    OsnDevice *ods __attribute__((unused)) = NULL;
    int rescan __attribute__((unused)) = 0 ;
    int res __attribute__((unused)) = 0;

    sync();
    /* Remove since Streamer 6.1
       if(dev->dgrp != NULL){
       list_for_each_entry(
       deventry, &dev->dgrp->devs_list, osn_grp_dev_entry){
       if(!rescan && deventry->forcecheck){
       osn_device_probe_all(1);
       rescan = 1;
       }
       ods = NULL;
       if(deventry->forcecheck){
       while ((ods = osn_device_get_next(ods))) {
       if(!memcmp(ods->guid, deventry->guid, GUID_LEN)){
       if(strcmp(deventry->path, ods->path)){
       free(deventry->path);
       deventry->path = strdup(ods->path);
       }
       }
       }
       }
       if(mode)
       res = Osn_markcdp_systemcall(deventry, type);
       else
       res = Osn_markcdp_single(deventry, type);
       }
       }
       else{ */
    if(mode) {
        res = Osn_markcdp_systemcall(dev, type);
    }
    else {
        res = Osn_markcdp_single(dev, type);
    }
    /* } */
    return res;
}

/* Always called with type = 1. */
static int _osn_markcdp(Osndev* dev, int type) {
    int ret,res = 0;

    ret = Osn_preprocess();
    if (ret != 1) {
        log_error("Failed to perform database preprocess.");
    }

    /* Do cdpmark now */
#ifdef domino	
    res = Osn_markcdp_group(dev, 1, type);
#else
    res = Osn_markcdp_group(dev, 0, type );
#endif	

    Osn_postprocess();
    return res;
}

int Osn_markcdp(Osndev* dev) {
    return _osn_markcdp(dev, 0);
}

int Osn_marktimecdp(Osndev* dev) {
    return _osn_markcdp(dev, 1);
}

/**
 * Function which creates a CDP point for the given disk.
 * According to my understanding, the function is only called by
 * Hostmirror daemon with the parameter type = 1.
 * 
 * Thus this function will then call the routine Osn_marktimecdp,
 * but not Osn_markcdp. 
 * Even by reading the function names, I can't figure out the difference
 * between them.
 */ 
void osn_call_markcdp(const char *guid, const char *path, int type) {
    Osndev *dev = NULL;

    if (!(dev = Osn_getdev(guid, path, 0))) {
        log_error("Failed to find mirror GUID %s, skip snapshot creation.", guid);
        return ;
    }

    if(!type) {
        Osn_markcdp(dev);
    }
    else {
        Osn_marktimecdp(dev);
    }
}

int osn_call_disk_markcdp(const char *guid, const char *path) {

    Osndev *dev = NULL;

    if (!(dev = Osn_getdev(guid, path, 0))) {
        log_error("Failed to find mirror GUID %s, skip snapshot creation.", guid);
        return -1;
    }

    return Osn_marktimecdp(dev);
}

/**
 * Function added since Streamer 6.1 for CDP creation for group.
 * The function literally follows the execution flow of osn_call_markcdp(),
 * and encapsulates the entire bunch of weird operations into one single function.
 *
 * @param grp The group for whom we will create consistent CDP points.
 * @return 0 on success (hope so ...), -1 on error.
 */ 
int osn_call_grp_markcdp(Osndevgrp *grp) {

    int rescan = 0;
    int dev_registered = 0;
    Osndev *ite_dev = NULL;
    OsnDevice *device = NULL;
    /*OsnApp *itr_app;*/

    if (grp == NULL) {
        log_error("Null device group !");
        return -1;
    }

#ifdef domino
    log_error("Mark CDP for Domino via system call, not supported.");
    return -1;
#endif

    log_info("Mark CDP points for groupe %s.", grp->grp_name);
    log_info("Dumping group informations ...");
    list_for_each_entry(ite_dev, &grp->devs_list, osn_grp_dev_entry) {
        log_info("\tMirror GUID: %s, Mirror Path: %s Force Check: %hu.",
                ite_dev->guid, ite_dev->path, ite_dev->forcecheck);
    }

    device = NULL;
    log_debug(DEBUG_APP, "List all the registered devices before rescan.");
    while((device = osn_device_get_next(device))) {
        log_debug(DEBUG_APP, "Registered device [%s].",
                (device->path ? device->path : "Unknown path"));
    }
    log_debug(DEBUG_APP, "All registered devices listed.");

    /* Check if all devices in the group exist. */
    list_for_each_entry(ite_dev, &grp->devs_list, osn_grp_dev_entry) {
        log_info("Trying to get device of GUID: %s.", (char *) ite_dev->guid);
        if (Osn_getdev((char *)ite_dev->guid, ite_dev->path, 0) == NULL) {
            log_error("Failed to find device whose GUID is %s.", (char *)ite_dev->guid);
            return -1;
        }
    }

    /*
    log_debug(DEBUG_APP, "app list before entering preprocess.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/
    log_info("Database preprocess.");
    if (Osn_preprocess() != 1) {
        log_error("Database preprocess failed.");
    }

    /*
    log_debug(DEBUG_APP, "app list after preprocess.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/

    list_for_each_entry(ite_dev, &grp->devs_list, osn_grp_dev_entry) {
        if (! rescan && ite_dev->forcecheck) {
            log_debug(DEBUG_APP, "Complete device rescan needed.");
            osn_device_probe_all(1);
            rescan = 1;
        }

        device = NULL;
        if (! ite_dev->forcecheck) {
            continue;
        }

        log_info("Force to check path of disk %s.", ite_dev->guid);
        while ((device = osn_device_get_next(device))) {
            if (memcmp(device->guid, ite_dev->guid, GUID_LEN + 1) != 0) {
                continue;
            }

            if (strcmp(ite_dev->path, device->path)) {
                log_info("The path of device %s is updated.", ite_dev->guid);
                free(ite_dev->path);
                ite_dev->path = strdup(device->path);
                log_info("The new path of device %s is %s.", 
                        ite_dev->guid, ite_dev->path);
            }
        }
    }

    device = NULL;
    log_debug(DEBUG_APP, "List all the registered devices after rescan.");
    while((device = osn_device_get_next(device))) {
        log_debug(DEBUG_APP, "Registered device [%s].",
                (device->path ? device->path : "Unknown path"));
    }
    log_debug(DEBUG_APP, "All registered devices listed.");

    log_debug(DEBUG_APP, "Make sure that all group members are correctly registered.");
    list_for_each_entry(ite_dev, &grp->devs_list, osn_grp_dev_entry) {
        if (ite_dev->path == NULL) {
            continue;
        }
        device = NULL;
        dev_registered = 0;
        while((device = osn_device_get_next(device))) {
            if (device->path == NULL) {
                continue;
            }
            if (strcmp(ite_dev->path, device->path) == 0) {
                dev_registered = 1;
                break;
            }
        }
        if (! dev_registered) {
            log_error("Device [%s] is not correctly registered, operation cancelled.",
                    (ite_dev->path ? ite_dev->path : "Unknown path"));
            log_info("Database postprocess");
            Osn_postprocess();
            return -1;
        }
    }

    log_info("Calling group snapshot creation operation."); 
    if (osn_arch->scsi_ops->create_grp_timecdp(grp) < 0) {
        log_error("Error during group CDP creation.");
    }

    log_info("Database postprocess.");
    Osn_postprocess();
    return 0; 
}

Osndev *search_cfg_device(const char *guid) {
    Osndev *rdev = NULL;
    Osndev *dev;
    if(!guid){
        log_error("Input NULL device guid");
        return NULL;
    }
    pthread_mutex_lock(&osndev_list_lock);
    list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
        if(!strcmp((char *)dev->guid, guid)){
            rdev = dev;
            break;
        }
    }
    pthread_mutex_unlock(&osndev_list_lock);
    return rdev;
}

static int get_cfg_device_id(void) {
    Osndev *dev;
    int id = 0;
    pthread_mutex_lock(&osndev_list_lock);
    list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
        if(dev->id > id){
            id = dev->id;
        }
    }
    pthread_mutex_unlock(&osndev_list_lock);
    return id;
}

/**
 * Add a device to cdpagt's config file.
 * The former function is supposed to be deprecated since Streamer 6.1,
 * as the management of disk group has been moved to Streamer Client.
 * To avoid modifying the interface of osnagt, the function keeps
 * the parameter group even it is not used at all.
 *
 * Attention !! 
 * When the function is called by Streamer Client,
 * The argument guid is not enclosed in brackets {...}.
 * I don't understand why they have initially chosen such bloody design,
 * but sadly, during the device processing in this function,
 * you should take the brackets into account.
 * 
 * @param guid The guid of the disk to be added.
 * @param group unused.
 * @return 0 on success, -1 on failure.
 */ 
int Osn_add_dev_to_group(const char *guid, const char *group) {

    OsnDevice *sys_dev = NULL;
    Osndev *osn_dev = NULL;
    char osn_guid[GUID_LEN + 1] = {0};
    int ret, found = 0;

    if (guid == NULL) {
        log_error("Failed to add device, null guid.");
        return -1;
    }

    _Osn_clear_dev_list();
    log_debug(DEBUG_DEV, "Reload devices from config file.");

    ret = Osn_parse_cfgfile(OSNCFG_DEFAULT);
    if (ret && ret != -2) {
        log_error("Failed to parse cdpagt's config file: %s.", OSNCFG_DEFAULT);
        return -1;
    }

    sprintf(osn_guid, "{%s}", guid);
    osn_device_probe_all(0);
    while ((sys_dev = osn_device_get_next(sys_dev)) != NULL) {
        if (strcmp((char *)sys_dev->guid, osn_guid) == 0) {
            found = 1;
            break;
        }
    }

    if (! found) {
        log_error("Unable to find disk whose guid is %s.", osn_guid);
        return -1;
    }

    osn_dev = search_cfg_device(guid);
    if (osn_dev != NULL) {
        log_debug(DEBUG_DEV, "Failed to add device %s, already exist.", guid);
        if (memcmp(osn_dev->guid, sys_dev->guid, GUID_LEN + 1) != 0) {
            memcpy(osn_dev->guid, sys_dev->guid, GUID_LEN + 1);
            ret = Osn_update_cfgfile(OSNCFG_DEFAULT);
        }
        return -1;
    }
    else {
        if ((osn_dev = calloc(1, sizeof(Osndev))) == NULL) {
            log_error("Failed to allocate memory for new device %s.", guid);
            return -1;
        }

        osn_dev->path = strdup(sys_dev->path);
        osn_dev->id = get_cfg_device_id() + 1;
        memcpy(osn_dev->guid, sys_dev->guid, GUID_LEN + 1);
        INIT_LIST_HEAD(&osn_dev->osn_dev_list_entry);
        INIT_LIST_HEAD(&osn_dev->osn_grp_dev_entry);

        pthread_mutex_lock(&osndev_list_lock);
        list_add_tail(&osn_dev->osn_dev_list_entry, &osndev_list);
        pthread_mutex_unlock(&osndev_list_lock);
        ret = Osn_update_cfgfile(OSNCFG_DEFAULT);
        return ret;
    }
    return 0;
}

static void get_new_app(OsnApp *new_app, OsnApp *old_app)
{
   if (!new_app || !old_app) {
      log_error("app point is NUll.");
   }
   if (old_app->server) {
      new_app->server = strdup(old_app->server);
   }
   if (old_app->name) {
      new_app->name = strdup(old_app->name);
   }
   if (old_app->usrname) {
      new_app->usrname = strdup(old_app->usrname);
   }
   if (old_app->usrgroup) {
      new_app->usrgroup = strdup(old_app->usrgroup);
   }
   if (old_app->passwd) {
      new_app->passwd = strdup(old_app->passwd);
   }
   if (old_app->installpath) {
      new_app->installpath = strdup(old_app->installpath);
   }
   if (old_app->datapath) {
      new_app->datapath = strdup(old_app->datapath);
   }
   if (old_app->env) {
      new_app->env = strdup(old_app->env);
   }
   if (old_app->host) {
      new_app->host = strdup(old_app->host);
   }
   if (old_app->port) {
      new_app->port = strdup(old_app->port);
   }
   if (old_app->priv) {
      new_app->priv = strdup(old_app->priv);
   }
   new_app->type = old_app->type;
   new_app->status = old_app->status;
   new_app->mode = old_app->mode;
   new_app->id = old_app->id;

   INIT_LIST_HEAD(&new_app->osn_app_list_entry);
   return;
}

int Osn_list_app(struct list_head *oapp_list) {
    int ret = -1;
    OsnApp *itr_app, *tmp_app;
    OsnApp *new_app;

    if (oapp_list == NULL) {
        return -1;
    }

    _Osn_clear_global_lists();
    ret = Osn_parse_cfgfile(OSNCFG_DEFAULT);
    if (ret && ret != -2) {
        log_error("Fail to parse config file %s", OSNCFG_DEFAULT);
        return -1;
    }
    /*
    log_debug(DEBUG_APP, "app list before splice.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/

    INIT_LIST_HEAD(oapp_list);
    pthread_mutex_lock(&osnapp_list_lock);
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        new_app = calloc(1, sizeof(OsnApp));
        if (new_app == NULL) {
            log_error("Failed to allocate memory for OsnApp, cannot copy App config to client.");
            goto error;
        }
        get_new_app(new_app, itr_app);
        list_add_tail(&new_app->osn_app_list_entry, oapp_list);
        log_debug(DEBUG_APP, "App [%s] copied.", 
                (new_app->name ? new_app->name : "Unknown"));
    }
    pthread_mutex_unlock(&osnapp_list_lock);

    /*list_splice(&osnapp_list, oapp_list); Evil BUG !!! */

    /*
    log_debug(DEBUG_APP, "app list after splice.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
                &itr_app->osn_app_list_entry,
                itr_app->osn_app_list_entry.prev,
                itr_app->osn_app_list_entry.next);
    }*/
    return 0;
error:
    list_for_each_entry_safe(itr_app, tmp_app, oapp_list, osn_app_list_entry) {
        list_del(&itr_app->osn_app_list_entry);
        _Osn_free_app(itr_app);
    }
    return -1;
}

/**
 * Read config file and dump disks having cdp schedules into the given list.
 * @param odev_list The list which is used to store disks.
 * @return 0 on success, -1 on error.
 */
int Osn_list_dev(struct list_head *odev_list)
{
    int ret = -1;
    Osndev *ite_dev, *tmp_dev;
    Osndev *new_dev;

    if (odev_list == NULL) {
        return -1;
    }

    _Osn_clear_global_lists();
    ret = Osn_parse_cfgfile(OSNCFG_DEFAULT);
    if (ret && ret != -2) {
        log_error("Fail to parse config file %s", OSNCFG_DEFAULT);
        return -1;
    }

    INIT_LIST_HEAD(odev_list);
    list_for_each_entry(ite_dev, &osndev_list, osn_dev_list_entry) {
        new_dev = calloc(1, sizeof(Osndev));
        if (new_dev == NULL) {
            log_error("Failed to allocate memory for Osndev, cannot copy device config to client.");
            goto error;
        }
        memcpy(new_dev, ite_dev, sizeof(Osndev));
        list_add_tail(&new_dev->osn_dev_list_entry, odev_list);
        log_debug(DEBUG_DEV, "Device [%s] copied.",
                (new_dev->path ? new_dev->path : "Unknown"));
    }

    /** The one who wrote this will burn in hell.
    pthread_mutex_lock(&osndev_list_lock);
    list_splice(&osndev_list, odev_list);
    pthread_mutex_unlock(&osndev_list_lock); **/

    return 0;
error:
    list_for_each_entry_safe(ite_dev, tmp_dev, odev_list, osn_dev_list_entry) {
        list_del(&ite_dev->osn_dev_list_entry);
        _Osn_free_dev(ite_dev);
    }
    return -1;
}

int Osn_delete_app(const char *server)
{
    OsnApp *ite_app, *tmp_app = NULL;
    int ret, found = 0;

    if (server == NULL) {
        return -1;
    }

    _Osn_clear_global_lists();
    ret = Osn_parse_cfgfile(OSNCFG_DEFAULT);
    if(ret && ret != -2){
        log_error("Fail to parse config file %s", OSNCFG_DEFAULT);
        return -1;
    }

    pthread_mutex_lock(&osnapp_list_lock);
    list_for_each_entry_safe(ite_app, tmp_app, &osnapp_list, osn_app_list_entry) {
        if (strcmp(ite_app->server, server) != 0) {
            continue;
        }

        list_del(&ite_app->osn_app_list_entry);
        _Osn_free_app(ite_app);
        found = 1;
        break;
    }
    pthread_mutex_unlock(&osnapp_list_lock);

    if (found) {
        Osn_update_cfgfile(OSNCFG_DEFAULT);
    } else {
        log_debug(DEBUG_APP, "App(%s) not found!", server);
    }

    return found;
}

/**
 * Remove a device from cdpagt's config file.
 * To keep the interface (prototype) unchanged,
 * the function keeps the parameter group, but it's not used. 
 *
 * If the specified device is found,
 * The function removes it from the global list osndev_list,
 * then update the default config file.
 *
 * @param group unused;
 * @param guid The guid of the device to be removed.
 * @return 0 on success, -1 on failure.
 */
int Osn_delete_dev(const char *group, const char *guid) {
    Osndev *ite_dev, *tmp_dev;
    char osn_guid[GUID_LEN + 1] = {0};
    int ret, found = 0;

    if (guid == NULL) {
        return -1;
    }

    _Osn_clear_global_lists();
    ret = Osn_parse_cfgfile(OSNCFG_DEFAULT);
    if (ret && ret != -2) {
        log_error("Failed to parse config file %s.", OSNCFG_DEFAULT);
        return -1;
    }

    sprintf(osn_guid, "{%s}", guid);

    pthread_mutex_lock(&osndev_list_lock);
    list_for_each_entry_safe(ite_dev, tmp_dev, &osndev_list, osn_dev_list_entry) {
        if (strcmp((char *)ite_dev->guid, osn_guid) != 0) {
            continue;
        }
        list_del(&ite_dev->osn_dev_list_entry);
        _Osn_free_dev(ite_dev);
        found = 1;
        break;
    }
    pthread_mutex_unlock(&osndev_list_lock);

    if (found) {
        Osn_update_cfgfile(OSNCFG_DEFAULT);
    }
    else {
        log_debug(DEBUG_DEV, "Device %s not found.", guid);
    }
    return found;
}
