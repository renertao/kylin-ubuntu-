/*
 * osnagt_ora.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 23, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/wait.h>

#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/osnlog.h>

/*
 * Modified on: May 10, 2016
 * Author: Yanbo Shou <yanbo.shou@infocore.cn>
 *
 * Stop using the buggy Oracle Library,
 * use directly official C/C++ API, OCI. */

#define OCI_CRED_INFO_SIZE 512
#define OCI_STATE_MSG_SIZE 512
#define OCI_STMT_SIZE 1024
 
static char *_oci_fmtstr (const char *fmt, ...) {
    
    char *res;
    int length, ret;
    va_list args;

    va_start(args, fmt);
    length = vsnprintf(NULL, 0, fmt, args);
    va_end(args);
    if (length < 0) {
        log_error("Failed to format string.");
        return NULL;
    }

    length ++;
    res = calloc(length + 1, sizeof(char));
    va_start(args, fmt);
    ret = vsnprintf(res, length, fmt, args);
    va_end(args);

    if (ret < 0) {
        log_error("Failed to format string.");
        return NULL;
    }
    if (ret >= length) {
        log_error("Output string truncated.");
        res[length - 1] = '\0';
    }
    return res;
}

static int _oci_check_app (OsnApp *app) {

    if (app == NULL) {
        log_error("Null pointer to database entry.");
        return -1;
    }
    if (app->usrname == NULL) {
        log_error("No Oracle username.");
        return -1;
    }
    if (app->passwd == NULL) {
        log_error("No Oracle password.");
        return -1;
    }
    if (app->server == NULL) {
        log_error("No Oracle service name.");
        return -1;
    }
    return 0;
}

static int _oci_run_cmd (const char *cmd) {
    int status, ret;

    if (cmd == NULL) {
        log_error("No command to execute.");
        return -1;
    }

    status = system(cmd);
    if (status < 0) {
        log_error("Failed to execute command: %s", cmd);
        return -1;
    }

    ret = WEXITSTATUS(status);
    log_info("Command has returned [%d].", ret);
    if (ret != 0) {
        return -1;
    }
    return 0;
}

static int osn_setenv(const char *name, const char *value, int replace)
{
	char *envstr;
	if(name == NULL || value == NULL)
		return 1;
	if(getenv(name) == NULL ||
			(getenv(name) != NULL && replace)){
		envstr = (char *)malloc(strlen(name) + strlen(value) + 2);
		if(envstr == NULL)
			return -1;
		sprintf(envstr, "%s=%s", name, value);
		if(putenv(envstr))
			return 1;
	}

	return 0;
}

/* Added by Yanbo.Shou
 * Use OCI to establish connection to Oracle.
 *
 * XXX Return value: 1, success; 0, failure. (weired) */
int oci_connect(OsnApp *app) {

    char *cmd;

    if (_oci_check_app(app) < 0) {
        log_error("Database entry arguments check failed.");
        return 0;
    }
    
    cmd = _oci_fmtstr("/usr/bin/osnora --connect --username %s --password %s --service %s --host %s --port %s",
            app->usrname, app->passwd, app->server,
            (app->host ? app->host : "127.0.0.1"),
            (app->port ? app->port : "1521"));
    if (cmd == NULL) {
        log_error("Failed to format command.");
        return 0;
    }

    log_info("Command generated: %s", cmd);
    log_info("Try to connect to Oracle via osnora.");
    if (_oci_run_cmd(cmd) < 0) {
        log_error("Failed to connect to Oracle.");
        goto error;
    }
    log_info("Connection with Oracle succeeded.");
    free(cmd);
    return 1;
error:
    free(cmd);
    return 0;
}

int oci_precdp (OsnApp *app) {
    char *cmd;
    
    if (_oci_check_app(app) < 0) {
        log_error("Database entry arguments check failed.");
        return 0;
    }

    cmd = _oci_fmtstr("/usr/bin/osnora --begin-backup --username %s --password %s --service %s --host %s --port %s",
            app->usrname, app->passwd, app->server,
            (app->host ? app->host : "127.0.0.1"),
            (app->port ? app->port : "1521"));
    if (cmd == NULL) {
        log_error("Failed to format command.");
        return 0;
    }

    log_info("Command generated: %s", cmd);
    log_info("Try switch to online backup mode.");
    if (_oci_run_cmd(cmd) < 0) {
        log_error("Failed to switch to online backup mode.");
        goto error;
    }
    app->status = 1;
    log_info("Database switched to online backup mode.");
    free(cmd);
    return 1;
error:
    free(cmd);
    return 0; 
}

int oci_postcdp (OsnApp *app) {
    char *cmd;
    if (_oci_check_app(app) < 0) {
        log_error("Database entryu arguments check failed.");
        return 0;
    }

    cmd = _oci_fmtstr("/usr/bin/osnora --end-backup --username %s --password %s --service %s --host %s --port %s",
            app->usrname, app->passwd, app->server,
            (app->host ? app->host : "127.0.0.1"),
            (app->port ? app->port : "1521"));
    if (cmd == NULL) {
        log_error("Failed to format command.");
        return 0;
    }

    log_info("Command generated: %s", cmd);
    log_info("Try to switch out of online backup mode.");
    if (_oci_run_cmd(cmd) < 0) {
        log_error("Failed to switch out of online backup mode.");
        goto error;
    }
    app->status = 0;
    log_info("Database switched out of online backup mode.");
    free(cmd);
    return 1;
error:
    free(cmd);
    return 0;
}

int oci_ckpt (OsnApp *app) {
    char *cmd;

    if (_oci_check_app(app) < 0) {
        log_error("Database entry arguments check failed.");
        return 0;
    }

    cmd = _oci_fmtstr("/usr/bin/osnora --checkpoint --username %s --password %s --service %s --host %s --port %s",
            app->usrname, app->passwd, app->server,
            (app->host ? app->host : "127.0.0.1"),
            (app->port ? app->port : "1521"));
    if (cmd == NULL) {
        log_error("Failed to format command.");
        return 0;
    }

    log_info("Command generated: %s", cmd);
    log_info("Try to create checkpoint for Oracle via osnora.");
    if (_oci_run_cmd(cmd) < 0) {
        log_error("Failed to create Oracle checkpoint.");
        goto error;
    }
    log_info("Checkpoint creation succeeded.");
    free(cmd);
    return 1;
error:
    free(cmd);
    return 0;
}

OsnAgtOps osnora = {
    .osnprecdp_process = oci_precdp,
    .osnpostcdp_process = oci_postcdp,
    .osncdp_process = oci_ckpt,
    .osncdp_conndb = oci_connect,
};
