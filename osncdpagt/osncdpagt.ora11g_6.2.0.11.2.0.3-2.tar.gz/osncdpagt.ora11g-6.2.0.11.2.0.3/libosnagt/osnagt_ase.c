/*
 * osnagt_sbe.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Feb 27, 2013
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/osnlog.h>
#include <unistd.h>
#include <stdlib.h>

/*
 * return 1 success, 0 fail, -1 error
 */
int sybase_cdpprocess(OsnApp *app)
{
    if (app->server == NULL || app->usrname == NULL || 
            app->passwd == NULL) {
        log_debug(DEBUG_APP, "Check the connecting infomation");
        return 0;
    }

    return osn_handle_database(app->usrname, 
            app->passwd, app->server);
}

OsnAgtOps osnase = {
    .osncdp_process = sybase_cdpprocess,
};
