/*
 * osnagt_dmo.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 21, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <pwd.h>
#include <grp.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osndmo/osndmo.h>
#include <osn/osnpub/osnlog.h>

static uid_t
osn_getuid(OsnApp* app)
{
	struct passwd *pw = NULL;
	pw = getpwnam(app->usrname);
	if(!pw){
		log_debug(DEBUG_APP, "User %s is not exist", app->usrname);
		return 0;
	}
	return pw->pw_uid;
}

static gid_t
osn_getgid(OsnApp* app)
{
	struct group *grp = NULL;	
	grp = getgrnam(app->usrgroup);
	if(!grp){
		log_debug(DEBUG_APP, "Group %s is not exist", app->usrgroup);
		return 0;
	}
	return (grp->gr_gid);
}

/* return 1 success, 0 fail */
int
domino_precdpprocess(OsnApp* app)
{
	int ret = 0;

	if(app->priv == NULL){
		log_debug(DEBUG_APP, "NULL pointer");
		return 0;
	}
	ret = osn_domino_precdp((struct list_head *)app->priv);
	if(!ret){
		app->status = 1;
		ret = 1;
		log_debug(DEBUG_APP, "Domino/Notes precdp commands executed successfully");
	}
	else{
		if(ret == -1)
			app->status = 1;
		ret = 0;
		log_error("Domino/Notes precdp commands failed");
	}
	return ret;
}

/* return 1 success, 0 fail */
int
domino_postcdpprocess(OsnApp* app)
{
	int ret = 0;

	if(app->priv == NULL){
		log_debug(DEBUG_APP, "NULL pointer");
		return 0;
	}
	ret = osn_domino_postcdp((struct list_head *)app->priv);
	if(!ret){
		app->status = 0; /* clean status */
		ret = 1;
		log_debug(DEBUG_APP, "Domino/Notes postcdp commands executed successfully");
	}
	else{
		ret = 0;
		log_error("Domino/Notes postcdp commands failed");
	}
	return ret;
}

/* return 1 success, 0 fail */
int
domino_initflist(OsnApp* app)
{
	int ret = 0;
	uid_t uid = 0;
	struct list_head *flist;
	struct passwd *pw = NULL;
	if(app->datapath == NULL){
		log_debug(DEBUG_APP, "NULL Domino/Notes data path");
		return 0;
	}

	/* notes do not allowed connect domino with root */
	if(getuid() == 0){
		uid = osn_getuid(app);
		if(uid != 0)
			ret = setuid(uid);
		if(ret){
			log_error("failed setuid");
			return 0;
		}
	}
	log_debug(DEBUG_APP, "Initializing Domino/Notes backup NSF database list");
	ret = osn_domino_initdmo(app->datapath);
	if(ret){
		log_error("Initialization failed");
		return 0;
	}
	flist = osn_domino_initflist(app->datapath);
	if(flist){
		app->priv = (void *)flist;
		ret = 1;
		log_debug(DEBUG_APP, "Initialization succeed");
	}
	else{
		ret = 0;
		log_error("Initialization failed");
	}
	return ret;
}

OsnAgtOps osndmo = {
		.osnprecdp_process = domino_precdpprocess,
		.osnpostcdp_process = domino_postcdpprocess,
		.osncdp_conndb = domino_initflist
};
