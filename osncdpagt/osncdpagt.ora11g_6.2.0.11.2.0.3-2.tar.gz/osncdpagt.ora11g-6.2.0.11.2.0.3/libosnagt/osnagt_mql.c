/*
 * osnagt_mql.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 27, 2012
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#include <osn/osnagt/osnagt.h>
#include <osn/osnmql/osnmql.h>
#include <osn/osnpub/osnlog.h>
//#include <mysql/mysql.h>
#include <unistd.h>
#include <stdlib.h>

/* return 1 success, 0 fail, -1 error */
int
mysql_cdpprocess(OsnApp* app)
{
	int ret = 0;

	ret = osn_refresh_database((MYSQL *)app->priv);
	if(ret) {
		ret = 1;
		log_debug(DEBUG_APP, "Flush MySQL database succeed");
	} else{
		ret = 0;
		log_error("Flush MySQL database failed");
	}
	return ret;
}

/* return 1 success , 0 fail*/
int
mysql_connect(OsnApp* app)
{
	MYSQL *cn = malloc(sizeof(MYSQL));
	int ret = 0;

	if(app->server == NULL){
		log_debug(DEBUG_APP, "NULL Server string");
		return 0;
	}

	if(app->usrname == NULL){
		log_debug(DEBUG_APP, "NULL Username string");
		return 0;
	}
	if(app->passwd == NULL){
		log_debug(DEBUG_APP, "No Password");
		return 0;
	}
	if(app->status){
		log_debug(DEBUG_APP, "Dirty Database Status(non-zero)");
		return 0;
	}
	log_debug(DEBUG_APP, "Connecting to database...");
	ret = osn_mysql_connect(cn, app->usrname, app->passwd, app->server);
	if(ret) {
		app->priv = (void *)cn;
		log_debug(DEBUG_APP, "Connecting OK!");
		ret = 1;
	}
	return ret;
}

void
mysql_disconnect(OsnApp* app)
{
	osn_mysql_disconnect((MYSQL *)app->priv);
    free(app->priv);
	app->priv = NULL;
}

OsnAgtOps osnmql = {
//		.osnprecdp_process = mysql_precdpprocess,
//		.osnrecdp_scripts = mysql_precdpcripts;
//		.osnpostcdp_process = mysql_postcdpprocess,
//		.osnpostcdp_scripts = mysql_postcdpcripts;
		.osncdp_process = mysql_cdpprocess,
		.osncdp_conndb = mysql_connect,
		.osncdp_disconndb = mysql_disconnect
};
