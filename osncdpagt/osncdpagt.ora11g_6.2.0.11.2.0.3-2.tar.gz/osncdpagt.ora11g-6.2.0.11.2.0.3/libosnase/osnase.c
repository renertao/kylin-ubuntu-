/*
 * osnase.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Feb 27, 2013
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <osn/osnpub/osnlog.h>
#include <osn/osnase/osnase.h>
#include <osn/osnagt/osnagt.h>

#define EXECUTE_CMD_LENGTH  256
#define MAX_DATABASE        102400
#define MAX_DATABASE_NAME_LENGTH    32

char database[MAX_DATABASE][MAX_DATABASE_NAME_LENGTH];
int database_num;

int osn_match_string(char *source, char *dest, int len)
{
    int i = 0, j = 0;
    int source_len = strlen(source);

    if (source_len < len)
        return -1;

    for (i=0; i<source_len; i++) {
        for(j=0; j<len && i<source_len; i++,j++) {
            if (source[i] != dest[j])
                break;
        }

        if (j == len && i <= source_len)
            return 0;
    }

    return -1;
}

void osn_copy_string(char *source, char *dest, int len)
{
    int i = 0;

    while (dest[0] == ' ' || dest[i] == '\n') {
        dest++;
        len--;
    }

    for (i=0; i<len; i++) {
        if (dest[i] == ' ' || dest[i] ==  '\n')
            goto out;
        source[i] = dest[i];
    }

out:
    source[i] = 0;
}

int osn_exec_cmd(char *cmd, int type)
{
    int ret = 0;

    if (type == 1) {
        int start = 0;
        int len = 0;
        char buffer[1024];
        FILE *pipe = popen(cmd, "r");

        if (!pipe) {
            log_error("Get the database list failed");
            return -1;
        }

        while (!feof(pipe) && start < MAX_DATABASE) {
            memset(buffer, 0, 1024);
            if (fgets(buffer, 1024, pipe)) {
                start++;
/*
 * DONOT buffer the head 2 line in the result
 * example:
 *  name                                                         
 *  ------------------------------------------------------------ 
 *  master                                                       
 *  model                                                        
 *  sybsystemdb                                                  
 *  sybsystemprocs                                               
 *  tempdb                                                       
 *
 *  (5 rows affected)
 */
                buffer[strlen(buffer)-1] = 0;
                if (start > 2) {
                    len = strlen(buffer) < MAX_DATABASE_NAME_LENGTH ? 
                        strlen(buffer) : MAX_DATABASE_NAME_LENGTH;
                    if (len < 1 || (!osn_match_string(buffer, "rows", 4) && 
                                !osn_match_string(buffer, "affected", 8))) {
                    } else {
                        osn_copy_string(database[database_num], buffer, len-1);
                        database_num++;
                    }
                }
            }
        }
        pclose(pipe);
    } else if (type == 2) {
        char buffer[128];
        FILE *pipe = popen(cmd, "r");

        if (!pipe) {
            log_error("Check the database status failed");
            return -1;
        }

        while(!feof(pipe)) {
            memset(buffer, 0, 128);
            fgets(buffer, 128, pipe);
            if (!osn_match_string(buffer, "SUSPEND", 7)) {
                ret = -1;
                break;
            }
        }
        pclose(pipe);
    } else
        system(cmd);

    return ret;
}

int osn_form_execute_cmd(const char *username,
        const char *passwd, const char *server, 
        const char *db, const char *func, int store)
{
    char cmd[EXECUTE_CMD_LENGTH];

    memset(cmd, 0, EXECUTE_CMD_LENGTH);
    if (db)
        sprintf(cmd, "su - %s %s/%s sa %s %s %s", username, 
                SYBASE_SCRIPT_CONF_FILE, func, 
                passwd, server, db);
    else
        sprintf(cmd, "su - %s %s/%s sa %s %s", username, 
                SYBASE_SCRIPT_CONF_FILE, func, 
                passwd, server);
    log_debug(DEBUG_APP, "cmd = %s\n", cmd);

    return osn_exec_cmd(cmd, store);
}

int osn_get_database(const char *username, 
        const char *passwd, const char *server)
{
    return osn_form_execute_cmd(username, passwd, server,
        NULL, "get_database.sh", 1);
}

int osn_check_status(const char *username, 
        const char *passwd, const char *server, const char *db)
{
    return osn_form_execute_cmd(username, passwd, 
            server, db, "check_statue.sh", 2);
}

int osn_checkpoint_database(const char *username, 
        const char *passwd, const char *server, const char *db)
{
    if (osn_check_status(username, passwd, server, db)) {
        return ;
    }
    return osn_form_execute_cmd(username, passwd, server, 
            db, "checkpoint_database.sh", 0);
}

void osn_hold_database(const char *username, 
        const char *passwd, const char *server, const char *db)
{
    osn_form_execute_cmd(username, passwd, server, 
            db, "hold_database.sh", 0);
}

void osn_unhold_database(const char *username, 
        const char *passwd, const char *server, const char *db)
{
    osn_form_execute_cmd(username, passwd, server, 
            db, "unhold_database.sh", 0);
}

int osn_handle_database(const char *username, 
        const char *passwd, const char *server)
{
    int ret = 0, i = 0;

    database_num = 0;
    ret = osn_get_database(username, passwd, server);

    if (ret)
        return ret;

    for (i=0; i<database_num; i++) {
        osn_checkpoint_database(username, passwd, 
                server, database[i]);
    }
    
    for (i=0; i<database_num; i++) {
        if (!osn_match_string(database[i], "tempdb", 6))
            continue;
        osn_hold_database(username, passwd, server, 
                database[i]);
    }

    for (i=0; i<database_num; i++) {
        if (!osn_match_string(database[i], "tempdb", 6))
            continue;
        osn_unhold_database(username, passwd, server, 
                database[i]);
    }

    return 1;
}
