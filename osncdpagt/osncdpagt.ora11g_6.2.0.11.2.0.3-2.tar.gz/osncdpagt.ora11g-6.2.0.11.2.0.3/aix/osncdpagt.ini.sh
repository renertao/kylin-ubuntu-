#
# *****************************************************************
# * Copyright (C) 2006-2013 Enterprise Information Management.Inc *
# * All rights reserved.					  *
# * Author: feiwen.tong@infocore.cn				  *
# *****************************************************************		
# OSNCDPAgent environment variables

PATH=$PATH:/usr/local/osncdpagt/bin
export PATH
LIBPATH=$LIBPATH:/usr/local/osncdpagt/lib:/opt/freeware/lib
export LIBPATH
