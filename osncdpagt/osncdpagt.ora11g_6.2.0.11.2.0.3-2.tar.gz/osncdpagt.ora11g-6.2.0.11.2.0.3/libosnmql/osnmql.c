/*
 * osnmysql.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 31, 2012
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <mysql/mysql.h>
#include <osn/osnmql/osnmql.h>
#include <osn/osnpub/osnlog.h>

/**
 * SUCCESS: 1
 * FAILURE: 0
 * */

int osn_mysql_connect(MYSQL *cn, const char *user, const char *passwd, const char *unix_socket)
{
    char hostname[255];
    memset(&hostname, 0, sizeof(hostname));
    gethostname(hostname, sizeof(hostname));

    if (mysql_library_init(0, NULL, NULL)) {
        log_debug(DEBUG_APP, "Could not initialize MySQL library");
        return 0;
    }

    mysql_init(cn);

    log_debug(DEBUG_APP, "Sock: %s", unix_socket);
    if (!mysql_real_connect(cn, hostname, user, passwd, NULL, 0, unix_socket, 0)) {
        log_debug(DEBUG_APP, "Connect: %s\n", mysql_error(cn));
        return 0;
    } else {
        return 1;
    }
}

void osn_mysql_disconnect(MYSQL *cn)
{
    mysql_library_end();
    mysql_close(cn);
}

int osn_refresh_database(MYSQL *cn)
{
    unsigned int options = 0;
    int ret = 0;

/**
 * REFRESH_GRANT: like flush privileges
 * REFRESH_LOG: like flush logs
 * REFRESH_TABLES: like flush tables
 * REFRESH_HOSTS: like flush hosts
 * REFRESH_STATUS: like flush status
 * REFRESH_THREADS: flush the thread cache
 * REFRESH_SLAVE: like reset slave
 * REFRESH_MASTER: like reset master
 * */
    options = REFRESH_GRANT|REFRESH_LOG|REFRESH_TABLES|REFRESH_HOSTS|REFRESH_THREADS;

    if ((ret = mysql_refresh(cn, options)) != 0) {
        log_debug(DEBUG_APP, "%s", mysql_error(cn));
        return 0;
    }
    return 1;
}
