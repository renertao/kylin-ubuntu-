/*
 * xmltest.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 23, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnagent/osncfg.h>
#include <osn/osnpub/list.h>

#define OSNCFG_ROOT		"osncfg"
#define	OSNCFG_APP		"app"
#define OSNCFG_APPENT	"appentry"
#define OSNCFG_DEV		"device"
#define OSNCFG_DEVENT	"deventry"

#define OSNCFG_APPENT_SVR	"server"
#define	OSNCFG_APPENT_TYPE	"type"
#define OSNCFG_APPENT_MODE	"mode"
#define OSNCFG_APPENT_NAME	"name"
#define OSNCFG_APPENT_USER	"username"
#define OSNCFG_APPENT_GRP	"usergroup"
#define OSNCFG_APPENT_PWD	"password"
#define OSNCFG_APPENT_IPATH	"installpath"
#define OSNCFG_APPENT_DPATH	"datapath"
#define OSNCFG_APPENT_PRIV	"private"

#define OSNCFG_DEVENT_GUID	"guid"
#define OSNCFG_DEVENT_PATH	"path"
#define OSNCFG_DEVENT_GRP	"group"

struct list_head	osndev_list;
pthread_mutex_t		osndev_list_lock;
struct list_head	osndevgrp_list;
struct list_head	osnapp_list;

static int
Osn_parse_appentry(xmlDocPtr doc, xmlNodePtr cur)
{
	xmlChar	*key = NULL;

	OsnApp *appentry = NULL;
	appentry = malloc(sizeof(OsnApp));
	if(appentry == NULL){
		/*FIXME malloc failed*/
		return -1 ;
	}
	memset(appentry, 0, sizeof(OsnApp));
	INIT_LIST_HEAD(&appentry->osn_app_list_entry);
	cur = cur->xmlChildrenNode;
	while(cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_SVR)){
			key = xmlNodeGetContent(cur);
			appentry->server = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_MODE)){
			key = xmlNodeGetContent(cur);
			appentry->mode = strtoul(key, NULL, 0);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_NAME)){
			key = xmlNodeGetContent(cur);
			appentry->name = strdup((char *)key);
			xmlFree(key);
			key = xmlGetProp(cur, OSNCFG_APPENT_TYPE);
			if(key){
				int type = strtoul(key, NULL, 0);
				if(type == 0 || type > APP_MAXNUM){
					/*FIXME debug info*/
					return -1;
				}
				appentry->type = type;
				xmlFree(key);
			}else{
				xmlFree(key);
				/*FIXME debug info*/
				printf("Error: No type\n");
				return -1;
			}
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_USER)){
			key = xmlNodeGetContent(cur);
			appentry->usrname = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_GRP)){
			key = xmlNodeGetContent(cur);
			appentry->usrgroup = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_PWD)){
			key = xmlNodeGetContent(cur);
			appentry->passwd = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_IPATH)){
			key = xmlNodeGetContent(cur);
			appentry->installpath = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT_DPATH)){
			key = xmlNodeGetContent(cur);
			appentry->datapath = strdup((char *)key);
			xmlFree(key);
		}
		cur = cur->next;
	}
	list_add_tail(&appentry->osn_app_list_entry, &osnapp_list);
}

static int
Osn_parse_app(xmlDocPtr doc, xmlNodePtr cur)
{
	cur = cur->xmlChildrenNode;
	while(cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APPENT)){
			Osn_parse_appentry(doc, cur);
		}
		cur = cur->next;
	}
}

static int
Osn_parse_deventry(xmlDocPtr doc, xmlNodePtr cur)
{
	xmlChar	*key = NULL;
	Osndev *dev = NULL;
	dev = malloc(sizeof(Osndev));
	if(dev == NULL ){
		/*FIXME malloc failed*/
		return -1 ;
	}
	memset(dev, 0, sizeof(Osndev));
	INIT_LIST_HEAD(&dev->osn_dev_list_entry);
	INIT_LIST_HEAD(&dev->osn_grp_dev_entry);
        /*
	key = xmlGetProp(cur, OSNCFG_DEVENT_GRP);
	if(key != NULL){
		Osndevgrp *grpentry,*grp = NULL;
		list_for_each_entry(grpentry, &osndevgrp_list, grp_list_entry){
			if(!strcmp(grpentry->grp_name, key)){
				grp = grpentry;
			}
		}
		if(!grp){
			grp = malloc(sizeof(Osndevgrp));
			memset(dev, 0, sizeof(Osndevgrp));
			INIT_LIST_HEAD(&grp->grp_list_entry);
			INIT_LIST_HEAD(&grp->devs_list);
			grp->grp_name = strdup((char *)key);
			list_add_tail(&grp->grp_list_entry, &osndevgrp_list);
		}
		list_add_tail(&dev->osn_grp_dev_entry, &grp->devs_list);
		dev->dgrp = grp;
		xmlFree(key);
	}*/

	key = xmlGetProp(cur, OSNCFG_DEVENT_CHK);
	if(key != NULL){
		dev->forcecheck = strtoul(key, NULL, 0);
		xmlFree(key);
	}else{
		dev->forcecheck = 0;
	}

	cur = cur->xmlChildrenNode;
	while(cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_DEVENT_PATH)){
			key = xmlNodeGetContent(cur);
			dev->path = strdup((char *)key);
			xmlFree(key);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_DEVENT_GUID)){
			key = xmlNodeGetContent(cur);
			strncat(dev->guid, (char *)key, GUID_LEN);
			xmlFree(key);
		}
		cur = cur->next;
	}
	pthread_mutex_lock(&osndev_list_lock);
	list_add_tail(&dev->osn_dev_list_entry, &osndev_list);
	pthread_mutex_unlock(&osndev_list_lock);
}

static int
Osn_parse_dev(xmlDocPtr doc, xmlNodePtr cur)
{
	cur = cur->xmlChildrenNode;
	while(cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_DEVENT)){
			Osn_parse_deventry(doc, cur);
		}
		cur = cur->next;
	}
}

static int
Osn_parse_cfgfile(char* docname)
{
	xmlDocPtr	doc;
	xmlNodePtr	cur;

	doc = xmlParseFile(docname);
	if(doc == NULL){
		printf("Document not parsed successfully.\n");
	}
	cur = xmlDocGetRootElement(doc);
	if(cur == NULL){
		printf("Empty Document.\n");
		xmlFreeDoc(doc);
		return 0;
	}
	if(xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_ROOT)){
		printf("Wrong config file type.\n");
	}
	cur = cur->xmlChildrenNode;
	while (cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_APP)){
			Osn_parse_app(doc, cur);
		}
		if(!xmlStrcmp(cur->name, (const xmlChar*) OSNCFG_DEV)){
			Osn_parse_dev(doc, cur);
		}
		cur = cur->next;
	}
}

int main(int argc, char **argv)
{
	if(argv[1] == NULL){
		printf("Please input config file path\n");
		return 0;
	}
	Osndev *dev;
	OsnApp *app;
	Osndevgrp *dgrp;
	INIT_LIST_HEAD(&osndev_list);
	osndev_list_lock = PTHREAD_MUTEX_INITIALIZER;
	INIT_LIST_HEAD(&osndevgrp_list);
	INIT_LIST_HEAD(&osnapp_list);
	Osn_parse_cfgfile(argv[1]);
	printf("app list:\n");
	list_for_each_entry(app, &osnapp_list, osn_app_list_entry){
		printf("\tName:%s,Server:%s,Mode:%d\n", app->name, app->server, app->mode);
	}
	printf("Device list:\n");
	pthread_mutex_lock(&osndev_list_lock);
	list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
		printf("\tGuid:%s, path: %s", dev->guid, dev->path);
		if(dev->dgrp != NULL){
			printf(",group: %s\n",dev->dgrp->grp_name);
		}
		else{
			printf("\n");
		}
	}
	pthread_mutex_unlock(&osndev_list_lock);
        /*
	printf("Group list:\n");
	list_for_each_entry(dgrp, &osndevgrp_list, grp_list_entry){
		printf("Group: %s\n", dgrp->grp_name);
		list_for_each_entry(dev, &dgrp->devs_list, osn_grp_dev_entry){
			printf("\t\tGuid:%s, path: %s\n", dev->guid, dev->path);
		}
	}
        */
	return 0;
}
