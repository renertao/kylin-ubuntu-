/*
 * base64test.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 10, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <osn/osnpub/base64.h>
#include <stdlib.h>
int main(int argc, char **argv){
	char *buf;
	char *encrypted, *decrypted;
	printf("Input password\n");
	buf = getpass("Password:");
	encrypted = base64_encode(buf);
	printf("Encrypted: \n");
	printf("%s\n", encrypted);
	printf("Decrypted: \n");
	decrypted = base64_decode(encrypted);
	printf("%s\n", decrypted);
	return 0;
}
