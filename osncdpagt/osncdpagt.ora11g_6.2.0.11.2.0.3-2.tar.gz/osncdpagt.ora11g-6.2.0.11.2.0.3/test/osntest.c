#include <stdio.h>
#include <osn/osndev/osnlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char **argv) {
	int fp = -1;
	int ret = -1;
	osn_set_loglevel(9);
	osn_set_logdaemon(0);
	OsnDevice *ods = NULL;
	if (1) {
		osn_device_probe_all(1);
		while ((ods = osn_device_get_next(ods))) {
			printf("%s\n", ods->path);
			printf("\tVid: %s\tPid: %s\tRev: %s\n", ods->vid, ods->pid,
					ods->rev);
			printf("\tGUID: %s\n", ods->guid);
		}
	}
	if (0) {
		ods = malloc(sizeof(OsnDevice));
		if(argv[1] == NULL){
			printf("Please specify device path\n");
		}
		fp = open(argv[1], O_RDONLY | O_NONBLOCK);
		if (fp > 0) {
			ods->path = argv[1];
			ods->fd = fp;
			ret = osn_device_issueinq_standard(ods);
			ret = osn_device_issueinq_t10(ods);
			ret = osn_device_createcdp(ods);
			printf("%s, fd:%d,return: %d\n", ods->path, fp, ret);
			printf("\tVid: %s\tPid: %s\tRev: %s\n", ods->vid, ods->pid,
					ods->rev);
			printf("\tGUID: %s\n", ods->guid);
			close(fp);
		}
	}
	return 0;
}
