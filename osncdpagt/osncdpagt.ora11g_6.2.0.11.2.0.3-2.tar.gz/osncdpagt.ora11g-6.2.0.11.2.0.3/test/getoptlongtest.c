#include <stdio.h>
#include <osn/common/getopt.h>

static struct option const long_options[] = {
    {"config", required_argument, 0, 'c'},
    {"foreground",no_argument,0,'f'},
    {0, 0, 0, 0},
};

int main(int argc, char *argv[])
{
    int ch, longindex;
    while ((ch= getopt_long(argc,argv,"c:f",long_options,&longindex))>=0) {
        switch (ch){
            case 'c':
                printf("%s\n", optarg);
                break;
            case 'f':
                printf("input f\n");
                break;
            default:
                printf("input error\n");
                break;
        }
    }
    int i = 0;
    for (i=0; i<argc; i++) {
        printf("%d, %s\n", i, argv[i]);
    }
    return 0;
}
