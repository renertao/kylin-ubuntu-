#include <osn/osnora/ocilib.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char*argv[])
{
	OCI_Connection* cn;
	OCI_Statement* st;
	OCI_Resultset* rs;
	int ret;
 
	if(!OCI_Initialize(NULL, NULL, OCI_ENV_DEFAULT | OCI_ENV_CONTEXT))
 	{
		printf("init failed\n");
		exit -1;
	}
	//service name (maybe the same with oracle sid)
	cn = OCI_ConnectionCreate("ORACLE", "sys", "infocore", OCI_SESSION_SYSDBA);
	st = OCI_StatementCreate(cn);
 
	if(cn == NULL){
		OCI_Error *err = OCI_GetLastError();
		printf("errcode %d, errmsg %s\n", OCI_ErrorGetOCICode(err), OCI_ErrorGetString(err));
		exit -1;
	}

	ret = OCI_ExecuteStmt(st, "select database status from v$instance");

	if(!ret){
		OCI_Error *err = OCI_GetLastError();
		printf("errcode %d, errmsg %s\n", OCI_ErrorGetOCICode(err), OCI_ErrorGetString(err));
 	}
	else{
		rs = OCI_GetResultset(st);

//		printf("\n%d row(s) fetched\n", OCI_GetRowCount(rs));
//		printf("\n%d column(s) fetched\n", OCI_GetColumnCount(rs));
		while (OCI_FetchNext(rs))
		{
			printf("%s\n", OCI_GetString(rs,0));
		}
 	}
//	OCI_ExecuteStmt(st, "alter database begin backup");
//	OCI_ExecuteStmt(st, "alter database end backup");
	OCI_Cleanup();
 
	return EXIT_SUCCESS;
}
