/*
 * osn_pretest.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 25, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */
#include <unistd.h>
#include <stdlib.h>
#include "osn_domino.h"
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>

const char program_name[] = "osn_dmoprecdp";

static struct option const long_options[] =
{
	{"datapath",no_argument,0,'p'},
	{"foreground",no_argument,0,'f'},
	{"debug",required_argument,0,'d'},
	{"uid",required_argument,0,'u'},
	{"gid",required_argument,0,'g'},
	{0, 0, 0, 0},
};

/* Program declaration */
int main(int argc, char *argv[])
{
	int ch,longindex;
	int daemon = 1,debug = 0;
	int ret = 0;
	pid_t uid = 0;
	gid_t gid = 0;
	char* datapath = NULL;
	struct list_head *flist = NULL;

	while ((ch = getopt_long(argc,argv,"fd:p:u:g:",
			long_options, &longindex)) >= 0){
		switch (ch){
		case 'f':
			daemon = 0;
			break;
		case 'd':
			debug = strtol(optarg, NULL, 0);
			break;
		case 'p':
			datapath = optarg;
			break;
		case 'u':
			uid = (pid_t)strtol(optarg, NULL, 0);
			break;
		case 'g':
			gid = (gid_t)strtol(optarg, NULL, 0);
			break;
		default:
			break;
		}
	}
	osn_log_init(program_name);
	osn_set_logdaemon(daemon);
	osn_set_loglevel(debug);
	if(datapath == NULL){
		log_debug(DEBUG_APP, "NULL datapath");
		return (1);
	}
	flist = osn_domino_initflist(datapath);
	if(flist == NULL){
		log_error("failed to get Notes database files");
		return (1);
	}
	if(uid != 0){
		if(setuid(uid) != 0){
			log_error("failed to set uid to %d", (int)uid);
			return (1);
		}
	}
	if(gid != 0){
		if(setgid(uid) != 0){
			log_error("failed to set gid to %d", (int)gid);
			return (1);
		}
	}
	if(osn_domino_initdmo(datapath)){
		return (1);
	}
	ret = osn_domino_precdp(flist);
	return ret;
}
