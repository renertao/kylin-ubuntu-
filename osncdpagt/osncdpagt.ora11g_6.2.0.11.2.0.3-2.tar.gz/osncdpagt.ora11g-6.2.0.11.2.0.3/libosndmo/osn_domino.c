/*
 * osn_domino.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 14, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <dirent.h>
#include <osn/osnpub/osnlog.h>

/* Notes API include files */
#include <domino/global.h>
#include <domino/nsfdb.h>
#include <domino/nsfdata.h>
#include <domino/osmisc.h>
#include <domino/osfile.h>

#include <osn/osndmo/osndmo.h>

#define MAX_DIR     4096
char inipath[MAXPATH];

STATUS LNPUBLIC osn_domino_addnsf (void *, SEARCH_MATCH *, ITEM_TABLE *);

static void
osn_domino_flist_free(struct list_head *list)
{
	Osndmo_flist *flist, *tmp = NULL;
	list_for_each_entry_safe(flist, tmp, list, entry) {
		list_del(&flist->entry);
		free(flist->fname);
		free(flist);
	}
}

static int
osn_domino_initdir(const char *d_path, const struct list_head *list)
{
	DIR *dir = NULL;
	int ret = 0, len = 0, f_len = 0;
	struct dirent *dirp = NULL;
	char fullname[MAX_DIR];
	struct stat st;

	if ((dir = opendir(d_path)) == NULL) {
		log_error("Open directory %s failed: %s", d_path, strerror(errno));
		ret = -1;
		goto out;
	}

	while ((dirp = readdir(dir)) != NULL) {
		if (!strcmp(dirp->d_name, ".") || !strcmp(dirp->d_name, ".."))
			continue;

		memset(fullname, 0, sizeof(fullname));
		len = strlen(d_path);
		f_len = strlen(dirp->d_name);
		if ( (len + f_len) > sizeof(fullname)) {
			log_error("Too long filename");
			continue;
		}
		strncpy(fullname, d_path, len);
		fullname[len] = '/';
		len++;
		strncpy((fullname + len), dirp->d_name, f_len);
		fullname[len + f_len] = '\0';
		if (stat(fullname, &st)) {
			log_debug(DEBUG_APP, "Checking file %s status error: %s", fullname, strerror(errno));
			continue;
		}
		if (S_ISDIR(st.st_mode)) {
			osn_domino_initdir(fullname, list);
		}
		/* filter nsf files */
		if(strncmp(dirp->d_name + f_len - 4, ".nsf", 4))
			continue;

		f_len = strlen(fullname);

		Osndmo_flist *flist = malloc(sizeof(Osndmo_flist));
		memset(flist, 0, sizeof(Osndmo_flist));
		flist->fname = malloc(strlen(fullname) + 1);
		if (flist->fname == NULL) {
			log_error("Failed to alloc memory: %s", strerror(errno));
			ret = -1;
			goto out;
		}
		strncpy(flist->fname, fullname, f_len);
		flist->fname[f_len] = '\0';
		list_add_tail(&flist->entry, list);
	}
	out:
	return ret;
}

STATUS LNPUBLIC
osn_domino_addnsf(void *lst,
		SEARCH_MATCH far *pSearchMatch,
		ITEM_TABLE *summary_info)
{
#define     MAX_ITEMS           30
#define     MAX_TEXT_LEN        1000
#define     DATATYPE_SIZE       sizeof(USHORT)
#define     NAME_LENGTH_SIZE    sizeof(USHORT)
#define     ITEM_LENGTH_SIZE    sizeof(USHORT)
#define     NUMERIC_SIZE        sizeof(FLOAT)
#define     TIME_SIZE           ODSLength(_TIMEDATE)

	STATUS			error;
	SEARCH_MATCH	SearchMatch;
	BYTE		*summary_position;       /* current position in summary */
	ITEM_TABLE	item_table;              /* header at start of summary */
	USHORT		item_count;              /* number of items in summary */
	USHORT		name_length[MAX_ITEMS];  /* length of each item name */
	USHORT		item_length[MAX_ITEMS];  /* length of each item */
	char		item_name[MAX_TEXT_LEN]; /* name of a summary item */
	USHORT		datatype;                /* type of item */
	char		item_text[MAX_TEXT_LEN]; /* text of a summary item */
	char		fullpath[MAXPATH];
	USHORT		i;
	int			len;
	struct list_head *list = lst;
	memcpy( (char*)&SearchMatch, (char*)pSearchMatch, sizeof(SEARCH_MATCH) );

	/* Skip this object if it does not really match the search criteria (it
is now deleted or modified).  This is not necessary for full searches,
but is shown here in case a starting date was used in the search. */

	if (!(SearchMatch.SERetFlags & SE_FMATCH))
		return (NOERROR);
	item_table =  *summary_info;
	summary_position = (BYTE *) summary_info;
	item_count = item_table.Items;
	if(item_count > MAX_ITEMS){
		log_error("Number of items has exceeded boundary of defined array.");
		return 0;
	}
	summary_position += ODSLength(_ITEM_TABLE);

	for (i=0; i < item_count; i++){
		memcpy (&name_length[i], summary_position, NAME_LENGTH_SIZE);
		summary_position += NAME_LENGTH_SIZE;
		memcpy (&item_length[i], summary_position, ITEM_LENGTH_SIZE);
		summary_position += ITEM_LENGTH_SIZE;
	}

	for (i=0; i < item_count; i++){
		memcpy (item_name, summary_position, name_length[i]);
		item_name[name_length[i]] = '\0';
		summary_position += name_length[i];
		log_debug(DEBUG_APP, "Item Name: %s", item_name);
		if(strcmp(item_name, "$Path"))
			continue;
		memcpy (&datatype, summary_position, DATATYPE_SIZE);
		summary_position += DATATYPE_SIZE;

		strcpy(fullpath, inipath);
		len = strlen(fullpath);
		memcpy (fullpath + len, summary_position,
				item_length[i] - DATATYPE_SIZE);
		fullpath[len + item_length[i] - DATATYPE_SIZE] = '\0';

		Osndmo_flist *flist = malloc(sizeof(Osndmo_flist));
		memset(flist, 0, sizeof(Osndmo_flist));
		flist->fname = malloc(strlen(fullpath) + 1);
		strcpy(flist->fname, fullpath);
		list_add_tail(&flist->entry, list);
		log_debug(DEBUG_APP, "add nsf file: %s", flist->fname);
	}
}

/* call osn_domino_initdmo before do this*/
static int
osn_domino_nsfsea(const char *datapath, const struct list_head *list)
{
	char fullpath_name[MAXPATH] = "";
	DBHANDLE	dir_handle;
	STATUS error = NOERROR;
	if ((error = OSPathNetConstruct(NULL, NULL, datapath, fullpath_name)) != NOERROR) {
		log_error("OSPathNetConstruct: %s", datapath);
		return (1);
	}

	/* Open the directory. */
	if (error = NSFDbOpen (fullpath_name, &dir_handle))
	{
		log_error("Failed to open %s", fullpath_name);
		NotesTerm();
		return (1);
	}

	if (error = NSFSearch (
			dir_handle,			/* directory handle */
			NULLHANDLE,			/* selection formula */
			NULL,				/* title of view in formula */
			SEARCH_FILETYPE +	/* search for files */
			SEARCH_SUMMARY,		/* return a summary buffer */
			FILE_DBANY +		/* find any .NS? file */
			FILE_DIRS +			/* find subdirectories */
			FILE_NOUPDIRS,		/* don't find the ".." dir */
			NULL,				/* starting date */
			osn_domino_addnsf,	/* call for each file found */
			list,				/* argument to action routine */
			NULL))				/* returned ending date (unused) */
	{
		log_error("Failed to find Notes db files");
		NSFDbClose (dir_handle);
		NotesTerm();
		return (1);
	}

	/* Close the directory. */
	if (error = NSFDbClose (dir_handle)){
		log_error("Failed to close directory %s", datapath);
		return (2);
	}

	/* Terminate Domino and Notes. */
	return (0);
}

int osn_domino_initdmo(char *notespath)
{
	STATUS error = NOERROR;
	int ret = 0;
	int str_notespath_len = strlen(notespath);
	inipath[0] = '=';
	strncpy(inipath+1, notespath, str_notespath_len);
	inipath[str_notespath_len + 1] = '\0';
	char *path[2] = {NULL, inipath};
	if ((error = NotesInitExtended(2, path)) != NOERROR) {
		log_debug(DEBUG_APP, "Error initializing Notes");
		ret = 1;
	}
	return ret;
}

/*
 * notespath: the directory where notes.ini locates
 * return 0 success
 */
struct list_head *
osn_domino_initflist(char *notespath)
{
	int ret = 0;
	struct list_head *osndmo_list = NULL;
	osndmo_list = malloc(sizeof(struct list_head));

	INIT_LIST_HEAD(osndmo_list);
	ret = osn_domino_initdir(notespath, osndmo_list);
	//ret = osn_domino_nsfsea(notespath, osndmo_list);

	/* failed */
	if(ret){
		osn_domino_flist_free(osndmo_list);
		free(osndmo_list);
		return NULL;
	}
	return osndmo_list;
}

/* return 0 success */
int osn_domino_precdp(struct list_head* list)
{
	int ret = 0;
	Osndmo_flist *flist = NULL;
	char fullpath_name[MAX_DIR];
	STATUS error = NOERROR;


	list_for_each_entry(flist, list, entry) {
		memset(fullpath_name, 0, sizeof(fullpath_name));

		if ((error = OSPathNetConstruct(NULL, NULL, flist->fname, fullpath_name)) != NOERROR) {
			log_debug(DEBUG_APP, "OSPathNetConstruct: %s", flist->fname);
			continue;
		}

		if ((error = NSFDbOpen(fullpath_name, &(flist->h_db))) != NOERROR) {
			log_error("failed to open %s, errono %d", flist->fname, error);
			continue;
		}

		if ((error = NSFBackupStart(flist->h_db, 0L,
				&(flist->backup_context), &(flist->file_size_low),
				&(flist->file_size_high))) != NOERROR) {
			log_error("failed to start %s backup mode, errno %d", flist->fname, error);
			continue;
		}
		else{
			log_debug(DEBUG_APP, "Alter %s backup mode.d: %d handle %d", flist->fname, flist->h_db, flist->backup_context);
		}
	}

	return ret;
}

/*
 * Release the list and cleanup others
 * */
int osn_domino_postcdp(struct list_head* list)
{
	int ret = 0;
	STATUS error = NOERROR;
	Osndmo_flist *flist = NULL;
	list_for_each_entry(flist, list, entry) {
		if(!flist->h_db)
			continue;
		error = NSFBackupEnd(flist->h_db, flist->backup_context, BACKUPEND_ABORT);
		if(error != NOERROR){
			log_error("%s failed to end backup,errno %d", flist->fname, error);
		}
		else{
			log_debug(DEBUG_APP, "%s end backup mode", flist->fname);
		}

		NSFDbClose(flist->h_db);
	}
	NotesTerm();

	osn_domino_flist_free(list);
	if(list)
		free(list);

	return ret;
}
