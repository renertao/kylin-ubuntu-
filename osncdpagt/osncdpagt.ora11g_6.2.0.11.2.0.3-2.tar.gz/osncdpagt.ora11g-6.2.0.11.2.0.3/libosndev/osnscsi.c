/*
 * osnscsi.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <osn/osndev/osnlib.h>

static int osn_vpd_dev_id_iter(const unsigned char * initial_desig_desc, int page_len,
      int * off, int m_desig_type) {
   const unsigned char * ucp;
   int k, desig_type;

   for (k = *off, ucp = initial_desig_desc; (k + 3) < page_len;) {
      k = (k < 0) ? 0 : (k + ucp[k + 3] + 4);
      if ((k + 4) > page_len)
         break;
      desig_type = (ucp[k + 1] & 0xf);
      log_debug(DEBUG_SCSI, "desig_type is %d", desig_type);
      if (((m_desig_type >= 0) || (m_desig_type <= 9)) 
              && (m_desig_type != desig_type)) {
         /* if iscsi VPD is not 1(t10) but in 0~9 ,just return 1*/
         *off = k;
         return 1;
      }
      *off = k;
      return 0;
   }
   log_error("Failed desig_type is %d", desig_type);
   return (k == page_len) ? -1 : -2;
}

static int osn_device_guid(OsnDevice* dev, void* buffer, int length) {
   int off, u, i_len;
   const uint8_t *ucp;

   off = -1;
   u = osn_vpd_dev_id_iter(buffer, length, &off, OSN_DESIGNATOR_T10);
   if (u == 0) {
      ucp = buffer + off;
      i_len = ucp[3];
      if ((off + i_len + 4) > length) {
         log_debug(DEBUG_SCSI, "VPD page error: designator length(%d) "
               "longer than reponse length(%d)", i_len, length);
         return -1;
      }
      if ((GUID_LEN + 8) > i_len) {
         log_debug(DEBUG_SCSI, "VPD page error: GUID length(%d)+8 "
               "longer than reponse length(%d)", GUID_LEN, i_len);
         return -1;
      }
      memcpy(dev->guid, ucp + 12, GUID_LEN);
      dev->guid[GUID_LEN] = '\0';
      log_debug(DEBUG_SCSI, "Device [%s] returns GUID [%s].", dev->path, dev->guid);
      return 0;
   } else if (u == 1) {
      log_debug(DEBUG_SCSI, "device %s is not t10 vpd.", dev->path);
      return 1;
   }
   log_error("osn_device_guid failed.");
   return -1;
}

   int
osn_device_issueinq_standard(OsnDevice* dev)
{
   int ret = -1;
   INQUIRY_DATA inq;
   memset((char*) &inq, 0, sizeof(inq));
   ret = osn_arch->scsi_ops->issue_inquiry(dev, 0, 0, &inq, sizeof(inq));
   if (!ret) {
      memcpy(dev->vid, inq.id_vendor_id, VID_LEN);
      dev->vid[VID_LEN] = '\0';
      memcpy(dev->pid, inq.id_product_id, PID_LEN);
      dev->pid[PID_LEN] = '\0';
      memcpy(dev->rev, inq.id_product_revision, REV_LEN);
      dev->rev[REV_LEN] = '\0';
      log_debug(DEBUG_SCSI, "Get inquiry data: device: %s, "
            "vendor id %s, product id %s, revision %s",
            dev->path, dev->vid, dev->pid, dev->rev);
   }
   else{
      log_error("device %s SCSI inquiry failed", dev->path);
   }
   return ret;
}

int osn_device_issueinq_t10(OsnDevice* dev) {
   int len;
   int ret = -1;
   T10_DATA t10;

   memset((char*) &t10, 0, sizeof(t10));
   ret = osn_arch->scsi_ops->issue_inquiry(dev, 1, OSN_INQUIRY_ID, &t10,
         DEF_ALLOC_LEN);
   if (!ret) {
      len = (t10.pg_len[0] << 8) + t10.pg_len[1];
      if (OSN_INQUIRY_ID != t10.pg_code) {
//         log_debug(DEBUG_SCSI, "Invalid VPD page (%d) response for device %s",
         log_error("Invalid VPD page (%d) response for device %s",
               t10.pg_code, dev->path);
         ret = -1;
         goto out;
      }
      if (len > MAX_ALLOC_LEN) {
//         log_debug(DEBUG_SCSI, "Invalid VPD response page length (%d) for device %s",
         log_error("Invalid VPD response page length (%d) for device %s",
               len, dev->path);
         ret = -1;
         goto out;
      }
      return osn_device_guid(dev, t10.ddl + 20, len + 4 - 20);
   }
   else{
      log_debug(DEBUG_SCSI, "Failed to get guid for device %s", dev->path);
   }
out:
   return ret;
}

int osn_device_issueinq_usn(OsnDevice* dev) {
   int ret;
   USN_DATA usn;
   memset((char*) &usn, 0, sizeof(usn));
   ret = osn_arch->scsi_ops->issue_inquiry(dev, 1, OSN_INQUIRY_USN, &usn,
         sizeof(usn));
   if (!ret) {
      memcpy(dev->guid, usn._usn, GUID_LEN);
      dev->guid[GUID_LEN] = '\0';
   }
   return ret;
}

int osn_device_createcdp(OsnDevice* dev) {
   return osn_arch->scsi_ops->create_cdp(dev);
}

int osn_device_createtimecdp(OsnDevice* dev) {
   return osn_arch->scsi_ops->create_timecdp(dev);
}
