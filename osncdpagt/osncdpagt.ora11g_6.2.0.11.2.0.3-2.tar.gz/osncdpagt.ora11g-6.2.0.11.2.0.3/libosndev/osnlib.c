/*
 * osnlib.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdint.h>
#include <sys/time.h>
#include <osn/osndev/osnlib.h>
#ifdef solaris
#	include <osn/osndev/solaris.h>
#elif defined(aix)
#	include <osn/osndev/aix.h>
#elif defined(hpux)
#	include <osn/osndev/hpux.h>
#else
#	include <osn/osndev/linux.h>
#endif

const OsnArch*	osn_arch;

int Osn_set_architecture (const OsnArch* arch) {
  osn_arch = arch;
  return 1;
}

static void __init() __attribute__ ((constructor));
static void __init() {
#ifdef	solaris
  Osn_set_architecture (&osn_solaris_arch);
#elif defined(aix)
  Osn_set_architecture (&osn_aix_arch);
#elif defined(hpux)
  Osn_set_architecture (&osn_hpux_arch);
#else
  Osn_set_architecture (&osn_linux_arch);
#endif
}

static void __done() __attribute__ ((destructor));
static void __done() {
  osn_device_free_all ();
}

/**
 * Utility function added since Streamer 6.1.
 * Return the current system timestamp in microseconds.
 * @return An unsigned long integer containing the current timestamp in microseconds.
 */
uint64_t get_current_timestamp_microsec() {
  struct timeval t;
  uint64_t ts = 0;

  gettimeofday(&t, NULL);

  ts = t.tv_sec;
  ts *= 1000;
  ts *= 1000;
  ts += t.tv_usec;
  return ts;
}

/**
 * Utility function added since Streamer v6.1.
 * Check if the current hardware platform is using little-endian byte order.
 * @return 1 If the current architecture uses little endian, otherwise, 0.
 */
int using_little_endian() {

  int x = 1;
  if (*(char *)&x == 1) {
    return 1;
  }
  return 0;
}

/**
 * Utility function added since Streamer 6.1.
 * Function which is used to reverse the byte order of the given array.
 * A typical use case of this function is when the system ain't using
 * the expected byte order, and we need to reverse the byte order.
 *
 * @param buff The array containing the bytes whose order need to be reversed.
 * @param len The number of elements (bytes) in the array.
 * @return 0 If everything goes well, 0 when shit happens.
 */
int endianness_swap(unsigned char *buff, size_t len) {
  size_t i;
  size_t stop = len / 2;
  unsigned char swap;

  if (buff == NULL) {
    return -1;
  }

  for (i = 0; i < stop; i ++) {
    swap = buff[i];
    buff[i] = buff[len - i - 1];
    buff[len - i -1] = swap;
  }
  return 0;
}

