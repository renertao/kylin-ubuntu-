/*
 * linux.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 17, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <scsi/sg.h>
#include <scsi/scsi.h>
#include <scsi/scsi_ioctl.h>
#include <osn/osndev/osnlib.h>
#include <osn/osndev/linux.h>
#include <errno.h>

static inline int _compare_digit_state (char ch, int need_digit) {
   return !!isdigit(ch) == need_digit;
}

/* matches the regexp "[^0-9]+[0-9]+[^0-9]+[0-9]+$".
 * Motivation: accept devices looking like /dev/rd/c0d0, but
 * not looking like /dev/hda1 and /dev/rd/c0d0p1
 */
static int _match_rd_device (const char* name) {
   const char* pos;
   int state;

   /* exclude directory names from test */
   pos = strrchr(name, '/') ? : name;

   /* states:
    *      0       non-digits
    *      1       digits
    *      2       non-digits
    *      3       digits
    */
   for (state = 0; state < 4; state++) {
      int want_digits = (state % 2 == 1);
      do {
         if (!*pos)
            return 0;
         if (!_compare_digit_state(*pos, want_digits))
            return 0;
         pos++;
      } while (_compare_digit_state(*pos, want_digits));
   }

   return *pos == 0;
}

static int _probe_proc_partitions (int filter) {
   FILE* proc_part_file;
   int major, minor, size;
   char buf[512];
   char part_name[256];
   char dev_name[256];

   log_debug(DEBUG_DEV, "Search for devices in [proc/partitions].");

   proc_part_file = fopen("/proc/partitions", "r");
   if (!proc_part_file)
      return 0;

   if (fgets(buf, 256, proc_part_file) == NULL)
      return 0;

   if (fgets(buf, 256, proc_part_file) == NULL)
      return 0;

   while (fgets(buf, 512, proc_part_file) && sscanf(buf, "%d %d %d %255s",
            &major, &minor, &size, part_name) == 4) {
      /* Heuristic for telling partitions and devices apart
       * Probably needs to be improved
       */
      if (!_match_rd_device(part_name) && isdigit(part_name[strlen(part_name) - 1]))
         continue;

      strcpy(dev_name, "/dev/");
      strcat(dev_name, part_name);
      osn_device_add(dev_name, -1, filter);
   }

   fclose(proc_part_file);
   return 1;
}

struct _entry {
   const char *name;
   size_t len;
};

static int _skip_entry (const char *name) {
   struct _entry *i;
   static struct _entry entries[] = {
      { ".",    sizeof (".") - 1},
      { "..",   sizeof ("..") - 1},
      { "dm-",	sizeof ("dm-") - 1},
      { "md",   sizeof ("md") - 1},
      { "loop", sizeof ("loop") - 1},
      { "ram",  sizeof ("ram") - 1},
      { 0, 0 },
   };

   for (i = entries; i->name != 0; i++) {
      if (strncmp(name, i->name, i->len) == 0)
         return 1;
   }

   return 0;
}

static int _probe_sys_block (int filter) {
   DIR *blockdir;
   struct dirent *dirent;
   char dev_name[256];
   char *ptr;

   log_debug(DEBUG_DEV, "Search for devices in [/sys/block].");

   if (!(blockdir = opendir("/sys/block")))
      return 0;
   while ((dirent = readdir(blockdir))) {
      if (_skip_entry(dirent->d_name))
         continue;

      if (strlen(dirent->d_name) > sizeof(dev_name) - 6)
         continue; /* device name too long! */

      strcpy(dev_name, "/dev/");
      strcat(dev_name, dirent->d_name);
      /* in /sys/block, '/'s are replaced with '!' or '.' */
      for (ptr = dev_name; *ptr != '\0'; ptr++) {
         if (*ptr == '!' || *ptr == '.')
            *ptr = '/';
      }
      osn_device_add(dev_name, -1, filter);
   }

   closedir(blockdir);
   return 1;
}

static int _probe_standard_devices (int filter) {

   log_debug(DEBUG_DEV, "Search for devices in [/dev/].");

   osn_device_add("/dev/sda", -1, filter);
   osn_device_add("/dev/sdb", -1, filter);
   osn_device_add("/dev/sdc", -1, filter);
   osn_device_add("/dev/sdd", -1, filter);
   osn_device_add("/dev/sde", -1, filter);
   osn_device_add("/dev/sdf", -1, filter);
   osn_device_add("/dev/sdg", -1, filter);
   osn_device_add("/dev/sdh", -1, filter);
   return 1;
}

static int linux_ioctl_passthru(
      OsnDevice* dev, 
      void *cdb, int cdb_len,
      int flag, 
      void *buff, int buff_len) {
   sg_io_hdr_t io_hdr;
   int status, fd, ret;
   int tmp_fd = 0;
   
   if (dev->fd >= 0) {
      fd = dev->fd;
   } else {
      if ((fd = open(dev->path, (O_RDONLY | O_NONBLOCK))) < 0) {
         log_error("Can't open device %s", dev->path);
         return -1;
      }
      tmp_fd = 1;
   }
   memset(&io_hdr, 0, sizeof(io_hdr));
   io_hdr.interface_id = 'S';
   io_hdr.cmdp = cdb;
   io_hdr.cmd_len = cdb_len;
   io_hdr.dxfer_direction |= flag; /* SG_DXFER_TO_DEV etc.*/
   io_hdr.dxferp = buff;
   io_hdr.dxfer_len = buff_len;
   io_hdr.sbp = NULL;
   io_hdr.timeout = 6000; /* 6000 millisecs = 6 seconds */

   status = ioctl(fd, SG_IO, &io_hdr);
   if (status >= 0 && io_hdr.status == 0) {
      ret = 0;
   } else {
      /*
         if(io_hdr.masked_status)
         printf("%s,status=0x%x\n", dev->path, io_hdr.masked_status);
         if(io_hdr.host_status)
         printf("%s,host_status=0x%x\n", dev->path, io_hdr.host_status);
         if(io_hdr.driver_status)
         printf("%s,driver_status=0x%x\n", dev->path, io_hdr.driver_status);
         */
      log_error("device %s ioctl failed (%s)",
            dev->path, strerror(errno));
      ret = -1;
   }

   if (tmp_fd) {
      close(fd);
   }
   return ret;
}

int linux_issue_inquiry(OsnDevice* dev, int evpd, int pg_code,
      void *resp, int max_resp_len) {
   INQUIRY_CDB cdb;
   memset((char*) &cdb, 0, sizeof(cdb));
   cdb.ic_op_code = INQUIRY;
   cdb.ic_evpd = evpd & 0x1;
   cdb.ic_pg_code = pg_code;
   cdb.ic_alloc_len[0] = (uint8_t) DEF_ALLOC_LEN >> 8;
   cdb.ic_alloc_len[1] = (uint8_t) (DEF_ALLOC_LEN & 0xff);
   return linux_ioctl_passthru(dev, &cdb, sizeof(cdb), SG_DXFER_FROM_DEV,
         resp, max_resp_len);
}

/**
 * Initialize the SCSI command description bloc and marker page,
 * before sending the command to target device.
 * 
 * Since Streamer 6.1, this function is supposed to be used exclusively
 * for single disk CDP point creation.
 * 
 * @param dev The disk for whom we'll create a new CDP point.
 * @param pagecode The page code for marker page, and I don't know what
 * the hell does it mean.
 * @return 0 on success, -1 on error. 
 */
static int _linux_create_cdp(OsnDevice* dev, unsigned int pagecode) {
   MODE_SELECT10 cdb;
   OSN_MARKER_PAGE data;
//   uint64_t timestamp;

   memset((char*) &cdb, 0, sizeof(cdb));
   memset((char*) &data, 0, sizeof(data));

   cdb.op_code = OSN_CDP_CMD;
   cdb.ParameterListLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
   cdb.ParameterListLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

   data.PageCode = pagecode;
   data.PageLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
   data.PageLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
   data.Header.ModeDataLength[0] = (uint8_t)((sizeof(OSN_MARKER_PAGE) - 2) >> 8);
   data.Header.ModeDataLength[1] = (uint8_t)((sizeof(OSN_MARKER_PAGE) - 2) & 0xff);

   /* Initialize of newly added attribute Type and CreateTime. */
//   data.Type[0] = (uint8_t) OSN_CDP_FOR_DISK;

//   timestamp = get_current_timestamp_microsec();
//   memcpy(data.CreateTime, &timestamp, 8);
   dev->fd = -1;

   return linux_ioctl_passthru(dev, &cdb, sizeof(cdb), SG_DXFER_TO_DEV,
         &data, sizeof(data));
}


/**
 * Added since Streamer 6.1.
 * Creation of CDP points for all the members in the given consistency group.
 *
 * @param grp The consistency group for whom we'll create CDP points.
 * @param pagecode I don't know what hell it is.
 * @return 0 on success, -1 on failure.
 */
static int _linux_create_grp_cdp(Osndevgrp *grp, unsigned int pagecode) {
   MODE_SELECT10 cdb;
   OSN_MARKER_PAGE data;
   Osndev *dev = NULL;
   OsnDevice *device;
//   uint64_t timestamp;
   
   memset(&cdb, 0, sizeof(MODE_SELECT10));
   memset(&data, 0, sizeof(OSN_MARKER_PAGE));

   cdb.op_code = OSN_CDP_CMD;
   cdb.ParameterListLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
   cdb.ParameterListLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
   
   data.PageCode = pagecode;
   data.PageLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) - 2 >> 8);
   data.PageLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) - 2 & 0xff);
   data.Header.ModeDataLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
   data.Header.ModeDataLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
   
//   data.Type[0] = (uint8_t) OSN_CDP_FOR_GRP;

//   timestamp = get_current_timestamp_microsec();
//   memcpy(data.CreateTime, &timestamp, 8);

   log_info("Start to create CDP points for group: %s.", grp->grp_name);
   list_for_each_entry(dev, &grp->devs_list, osn_grp_dev_entry) {
      if ((device = calloc(1, sizeof(OsnDevice))) == NULL) {
        log_error("Failed to allocate memory for OsnDevice during group snapshot creation.");
        return -1;
      }

      device->fd = -1;
      device->path = strdup(dev->path);
      if (linux_ioctl_passthru(device, &cdb, sizeof(cdb), SG_DXFER_TO_DEV, &data, sizeof(data)) < 0) {
         log_error("Failed to create CDP point for device: %s.", dev->path);
         free(device->path);
         free(device);
         return -1;
      }
      free(device->path);
      free(device);
   }
   log_info("Snapshot creation completed for all group members.");
   return 0;
}

int linux_create_cdp(OsnDevice* dev) {
   return _linux_create_cdp(dev, OSN_CDP_PAGENUM);
}

int linux_create_timecdp(OsnDevice* dev) {
   return _linux_create_cdp(dev, OSN_TIMECDP_PAGENUM);
}

/**
 * Added since Streamer 6.1.
 * CDP point creation for consistency group,
 * for all the members in the same group,
 * their CDP points should be created with exactly the same timestamp.
 *
 * @param grp The structure Osndevgrp representing a consistency group.
 */
int linux_create_grp_timecdp(Osndevgrp *grp) {
   return _linux_create_grp_cdp(grp, OSN_TIMECDP_PAGENUM);
}

void linux_device_probe_all (int filter) {
   /* we should probe the standard devs too, even with /proc/partitions,
    * because /proc/partitions might return devfs stuff, and we might not
    * have devfs available
    */
   //_probe_standard_devices (filter);

   /* /sys/block is more reliable and consistent; fall back to using
    * /proc/partitions if the former is unavailable, however.
    */
   if (!_probe_sys_block (filter))
      _probe_proc_partitions (filter);
}

OsnDevOps linux_dev_ops = {
      device_probe_all : linux_device_probe_all
};

OsnScsiOps linux_scsi_ops = {
      issue_inquiry : linux_issue_inquiry,
      create_cdp : linux_create_cdp,
      create_timecdp : linux_create_timecdp,
      create_grp_timecdp: linux_create_grp_timecdp
};

OsnArch	osn_linux_arch = {
      dev_ops : &linux_dev_ops,
      scsi_ops : &linux_scsi_ops
};
