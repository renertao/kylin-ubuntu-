/*
 * aix.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 17, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/scsi.h>
#include <sys/scdisk.h>
#include <sys/scsi_buf.h>
#include <osn/osndev/osnlib.h>
#include <osn/osndev/aix.h>

static int
aix_ioctl_passthru(OsnDevice* dev, void *cdb, int cdb_len,
		int flag, void *buff, int buff_len)
{
	struct sc_passthru sc_cmd;
	int fd = -1;
	int ret = -1;
	int tmp_fd = 0;
	if (dev->fd > 0) {
		fd = dev->fd;
	} else {
		if ((fd = open(dev->path, (O_RDONLY | O_NONBLOCK))) < 0) {
			log_debug(DEBUG_SCSI, "Can't open device %s\n", dev->path);
			return -1;
		}
		tmp_fd = 1;
	}
	memset(&sc_cmd, 0, sizeof(struct sc_passthru));
	sc_cmd.version = SCSI_VERSION_2;
	memcpy(sc_cmd.scsi_cdb, cdb, cdb_len);
	sc_cmd.command_length = cdb_len;
	sc_cmd.timeout_value = 6;
	sc_cmd.buffer = buff;
	sc_cmd.data_length = buff_len;
	sc_cmd.flags = flag;
	sc_cmd.autosense_buffer_ptr = NULL;
	ret = ioctl(fd, DK_PASSTHRU, &sc_cmd);

	if(ret < 0){
		log_error("Device %s ioctl failed (%s)",
				dev->path, strerror(errno));
	}

	if (tmp_fd) {
		close(fd);
	}
	return ret;
}

int
aix_issue_inquiry(OsnDevice* dev, int evpd, int pg_code,
		void *resp, int max_resp_len)
{
	INQUIRY_CDB cdb;
	memset((char*) &cdb, 0, sizeof(cdb));
	cdb.ic_op_code = SCSI_INQUIRY;
	cdb.ic_evpd = evpd & 0x1;
	cdb.ic_pg_code = pg_code;
	cdb.ic_alloc_len[0] = (uint8_t) DEF_ALLOC_LEN >> 8;
	cdb.ic_alloc_len[1] = (uint8_t)(DEF_ALLOC_LEN & 0xff);
	return aix_ioctl_passthru(dev, &cdb, sizeof(cdb), B_READ, resp,
			max_resp_len);
}

static int _aix_create_cdp(OsnDevice* dev, unsigned int pagecode)
{
	MODE_SELECT10 cdb;
	OSN_MARKER_PAGE data;

	memset((char*) &cdb, 0, sizeof(cdb));
	memset((char*) &data, 0, sizeof(data));

	cdb.op_code = OSN_CDP_CMD;
	cdb.ParameterListLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	cdb.ParameterListLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	data.PageCode = pagecode; //OSN_CDP_PAGENUM
	data.PageLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.PageLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
	data.Header.ModeDataLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.Header.ModeDataLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	return aix_ioctl_passthru(dev, &cdb, sizeof(cdb), B_WRITE | SC_ASYNC,
			&data, sizeof(data));
}

int aix_create_cdp(OsnDevice* dev)
{
	return _aix_create_cdp(dev, OSN_CDP_PAGENUM);
}

int aix_create_timecdp(OsnDevice* dev)
{
	return _aix_create_cdp(dev, OSN_TIMECDP_PAGENUM);
}

void
aix_device_probe_all (int filter)
{
	DIR 	*dir;
	struct dirent *dp;
	struct stat buffer;
	char *dev_dir = NULL;
	char real_path[PATH_MAX + 1];
	char *p1 = NULL;
	int len = 0;
	int fp = -1;
	dev_dir = strdup("/dev/");
	p1 = strdup("hdisk");
	dir = opendir("/dev");
	while ((dp = readdir(dir)) != NULL) {
		len = strlen(p1);
		if (!strncmp(dp->d_name, p1, len)) {
			strcpy(real_path, dev_dir);
			strcat(real_path, dp->d_name);
			if (!stat(real_path, &buffer)) {
				fp = open(real_path, O_RDONLY | O_NONBLOCK);
				if (fp > 0) {
					osn_device_add(real_path, fp, filter);
					close(fp);
				}
			}
		}
	}
}

OsnDevOps aix_dev_ops = {
		device_probe_all : aix_device_probe_all
};

OsnScsiOps aix_scsi_ops = {
		issue_inquiry : aix_issue_inquiry,
		create_cdp : aix_create_cdp,
		create_timecdp : aix_create_timecdp,
                create_grp_timecdp : NULL /* TODO: Not supported. */
};

OsnArch	osn_aix_arch = {
		dev_ops : &aix_dev_ops,
		scsi_ops : &aix_scsi_ops
};
