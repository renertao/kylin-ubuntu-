/*
 * solaris.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <unistd.h>
#include <fcntl.h>
#include <limits.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/dkio.h>
#include <sys/scsi/scsi.h>
#include <stdio.h>
#include <errno.h>
#include <osn/osndev/osnlib.h>
#include <osn/osndev/solaris.h>

static int
solaris_ioctl_passthru(OsnDevice* dev, void *cdb, int cdb_len,
		int flag, void *buff, int buff_len)
{
	struct uscsi_cmd ucmd;
	int status, fd, ret;
	int tmp_fd = 0;
	if (dev->fd > 0) {
		fd = dev->fd;
	} else {
		if ((fd = open(dev->path, (O_RDONLY | O_NONBLOCK))) < 0) {
			log_error("Open device %s failed", dev->path);
			return -1;
		}
		tmp_fd = 1;
	}
	memset((char*) &ucmd, 0, sizeof(ucmd));
	ucmd.uscsi_cdb = (caddr_t) cdb;
	ucmd.uscsi_cdblen = cdb_len;
	ucmd.uscsi_flags |= flag;
	ucmd.uscsi_bufaddr = (caddr_t) buff;
	ucmd.uscsi_buflen = buff_len;
	status = ioctl(fd, USCSICMD, &ucmd);
	if (status == 0 && ucmd.uscsi_status == 0) {
		ret = 0;
	} else {
		log_error("device %s ioctl failed (%s)",
				dev->path, strerror(errno));
		ret = -1;
	}
	if (tmp_fd) {
		close(fd);
	}
	return ret;
}

int
solaris_issue_inquiry(OsnDevice* dev, int evpd, int pg_code,
			void *resp, int max_resp_len)
{
    INQUIRY_CDB cdb;
	memset((char*) &cdb, 0, sizeof(cdb));
	cdb.ic_op_code = SCMD_INQUIRY;
	cdb.ic_evpd = evpd & 0x1;
	cdb.ic_pg_code = pg_code;
	cdb.ic_alloc_len[0] = (uint8_t) DEF_ALLOC_LEN >> 8;
	cdb.ic_alloc_len[1] = (uint8_t)(DEF_ALLOC_LEN & 0xff);
	return solaris_ioctl_passthru(dev, &cdb, CDB_GROUP0, USCSI_READ, resp,
			max_resp_len);
}

static int _solaris_create_cdp(OsnDevice* dev, unsigned int pagecode)
{
	MODE_SELECT10 cdb;
	OSN_MARKER_PAGE data;

	memset((char*) &cdb, 0, sizeof(cdb));
	memset((char*) &data, 0, sizeof(data));

	cdb.op_code = OSN_CDP_CMD;
	cdb.ParameterListLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	cdb.ParameterListLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	data.PageCode = OSN_CDP_PAGENUM;
	data.PageLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.PageLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
	data.Header.ModeDataLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.Header.ModeDataLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	return solaris_ioctl_passthru(dev, &cdb, sizeof(cdb), USCSI_WRITE, &data,
			sizeof(data));
}

int solaris_create_cdp(OsnDevice* dev)
{
	return _solaris_create_cdp(dev, OSN_CDP_PAGENUM);
}

int solaris_create_timecdp(OsnDevice* dev)
{
	return _solaris_create_cdp(dev, OSN_TIMECDP_PAGENUM);
}

void
solaris_device_probe_all (int filter)
{
	DIR *dir;
	struct dirent *dp;
	struct stat buffer;
	char *dev_directory = NULL;
	char real_path[PATH_MAX + 1];
	char *p1 = NULL;
	int len = 0;
	char *path;
//	int     n=0;
	int fp;

	p1 = strdup("s2");
	bzero(real_path, sizeof(path));
	dev_directory = strdup("/dev/rdsk");

	dir = opendir("/dev/rdsk");
	while ((dp = readdir(dir)) != NULL) {
		len = strlen(dp->d_name);
		len = len - 2;
		path = strdup(dp->d_name);
		path = path + len;

		if (!strcmp(path, p1)) {
			strcpy(real_path, dev_directory);
			strcat(real_path, "/");
			strcat(real_path, dp->d_name);

			if (!stat(real_path, &buffer)) {
				fp = open(real_path, O_RDONLY | O_NONBLOCK);
//				ioctl(fp,DKIOCREMOVABLE,&n);
//				if(!n){
				if (fp > 0) {
					osn_device_add(real_path, fp, filter);
					close(fp);
				}
			}
		}
	}
}

OsnDevOps solaris_dev_ops = {
		device_probe_all : solaris_device_probe_all
};

OsnScsiOps solaris_scsi_ops = {
		issue_inquiry : solaris_issue_inquiry,
		create_cdp : solaris_create_cdp,
		create_timecdp : solaris_create_timecdp,
                create_grp_timecdp: NULL /* TODO: Not supported yet. */
};

OsnArch	osn_solaris_arch = {
		dev_ops : &solaris_dev_ops,
		scsi_ops : &solaris_scsi_ops
};
