/*
 * hpux.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 17, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <sys/scsi.h>
#include <unistd.h>
#include <fcntl.h>
#include <limits.h>
#include <dirent.h>
#include <sys/stat.h>
#include <osn/osndev/osnlib.h>
#include <osn/osndev/hpux.h>

static int hpux_ioctl_passthru(OsnDevice* dev,
		void *cdb, int cdb_len, int flag, void *buff, int buff_len)
{
	struct sctl_io sctl_io;
	int status, fd, ret = -1;
	int tmp_fd = 0;
	if (dev->fd > 0) {
		fd = dev->fd;
	} else {
		if ((fd = open(dev->path, (O_RDONLY | O_NONBLOCK))) < 0) {
			log_error("Open device %s failed", dev->path);
			return -1;
		}
		tmp_fd = 1;
	}
	memset(&sctl_io, 0, sizeof(sctl_io));
	sctl_io.flags = flag;
	memcpy(sctl_io.cdb, cdb, cdb_len);
	sctl_io.cdb_length = cdb_len;
	sctl_io.data = buff;
	sctl_io.data_length = buff_len;
	status = ioctl(fd, SIOC_IO, &sctl_io);
	if (status == 0 && sctl_io.cdb_status == S_GOOD) {
		ret = 0;
	} else {
		log_debug(DEBUG_SCSI, "ioctl return %d(%s), cdb_status %d, sense_status %d",
				status, strerror(errno), sctl_io.cdb_status, sctl_io.sense_status);
		ret = -1;
	}
	if (tmp_fd) {
		close(fd);
	}
	return ret;
}

int
hpux_issue_inquiry(OsnDevice* dev, int evpd, int pg_code,
		void *resp, int max_resp_len)
{
    INQUIRY_CDB cdb;
	memset((char*) &cdb, 0, sizeof(cdb));
	cdb.ic_op_code = CMDinquiry;
	cdb.ic_evpd = evpd & 0x1;
	cdb.ic_pg_code = pg_code;
	cdb.ic_alloc_len[0] = (uint8_t) DEF_ALLOC_LEN >> 8;
	cdb.ic_alloc_len[1] = (uint8_t)(DEF_ALLOC_LEN & 0xff);
	return hpux_ioctl_passthru(dev, &cdb, sizeof(cdb), SCTL_READ, resp,
			max_resp_len);
}

static int _hpux_create_cdp(OsnDevice* dev, unsigned int pagecode)
{
	MODE_SELECT10 cdb;
	OSN_MARKER_PAGE data;

	memset((char*) &cdb, 0, sizeof(cdb));
	memset((char*) &data, 0, sizeof(data));

	cdb.op_code = OSN_CDP_CMD;
	cdb.ParameterListLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	cdb.ParameterListLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	data.PageCode = pagecode;
	data.PageLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.PageLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);
	data.Header.ModeDataLength[0] = (uint8_t)(sizeof(OSN_MARKER_PAGE) >> 8);
	data.Header.ModeDataLength[1] = (uint8_t)(sizeof(OSN_MARKER_PAGE) & 0xff);

	return hpux_ioctl_passthru(dev, &cdb, sizeof(cdb), 0,
			&data, sizeof(data));
}

int hpux_create_cdp(OsnDevice* dev)
{
	return _hpux_create_cdp(dev, OSN_CDP_PAGENUM);
}

int hpux_create_timecdp(OsnDevice* dev)
{
	return _hpux_create_cdp(dev, OSN_TIMECDP_PAGENUM);
}

void
hpux_device_probe_all (int filter)
{
	DIR *dir;
	struct dirent *dp;
	struct stat buffer;
	char *dev_directory = NULL;
	char real_path[PATH_MAX + 1];
	char *path;
	int fp;
	int len;

	bzero(real_path, sizeof(path));
	dev_directory = strdup("/dev/rdsk/");

	dir = opendir("/dev/rdsk");
	while ((dp = readdir(dir)) != NULL) {
		if(!strcmp(dp->d_name, ".") || !strcmp(dp->d_name, ".."))
			continue;
		len = strlen(dp->d_name);
		/* bypass hpux disk section, c0t0d0s1 for example */
		if(strncmp(dp->d_name+len-2, "d", 1))
			continue;
		strcpy(real_path, dev_directory);
		strcat(real_path, dp->d_name);
		if (!stat(real_path, &buffer)) {
			fp = open(real_path, O_RDONLY | O_NONBLOCK);
			if (fp > 0) {
				osn_device_add(real_path, fp, filter);
				close(fp);
			}
		}
	}
}

OsnDevOps hpux_dev_ops = {
		device_probe_all : hpux_device_probe_all
};

OsnScsiOps hpux_scsi_ops = {
		issue_inquiry : hpux_issue_inquiry,
		create_cdp : hpux_create_cdp,
		create_timecdp : hpux_create_timecdp,
                create_grp_timcdp: NULL /* TODO: Not supported yet. */
};

OsnArch	osn_hpux_arch = {
		dev_ops : &hpux_dev_ops,
		scsi_ops : &hpux_scsi_ops
};
