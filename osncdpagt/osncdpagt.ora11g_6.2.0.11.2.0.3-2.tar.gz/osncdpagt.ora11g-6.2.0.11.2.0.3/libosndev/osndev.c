/*
 * osndev.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#define _GNU_SOURCE
#define _LARGEFILE64_SOURCE

#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <osn/osndev/osnlib.h>

static OsnDevice* osndevs;

static void _dev_register (OsnDevice* dev, int filter) {
  OsnDevice* walk;
  /* Linux may redo registering the same device path*/
#ifdef linux
  for (walk = osndevs; walk != NULL; walk = walk->next) {
    if (!strcmp((char *)walk->path, (char *)dev->path)) {
      log_debug(DEBUG_DEV, "Device path [%s][%s] has already been registered,"
            "ignore device [%s][%s].",
            walk->path, walk->guid, dev->path, dev->guid);
      return;
    }
  }
#endif

  if (filter) {
    for (walk = osndevs; walk != NULL; walk = walk->next) {
      if (!strcmp((char *)walk->guid, (char *)dev->guid)) {
        log_debug(DEBUG_DEV, "Device GUID [%s][%s] has already been registered,"
                "ignore device [%s][%s].",
                walk->path, walk->guid, dev->path, dev->guid);
        return;
      }
    }
  }

  /* do register , add at the end*/
  for (walk = osndevs; walk && walk->next; walk = walk->next)
    ;

  if (walk)
    walk->next = dev;
  else
    osndevs = dev;
  dev->next = NULL;
  log_debug(DEBUG_DEV, "Device [%s] registered.", dev->path);
}

static void _dev_unregister (OsnDevice* dev) {
  OsnDevice* walk;
  OsnDevice* last = NULL;
  for (walk = osndevs; walk != NULL; last = walk, walk = walk->next) {
    if (walk == dev)
      break;
  }
  if (last)
    last->next = dev->next;
  else
    osndevs = dev->next;
}

static void _osn_device_free(OsnDevice* dev) {
  if (! dev) {
      return;
  }

  if (dev->path) {
      log_debug(DEBUG_APP, "dev path is %s.", dev->path);
      free(dev->path);
  }
  free(dev);
}

static void _osn_device_destroy (OsnDevice* dev) {
  _dev_unregister(dev);
  _osn_device_free(dev);
}

OsnDevice* osn_device_get_next (const OsnDevice* dev) {
  if (dev)
    return dev->next;
  else
    return osndevs;
}

/* Function which performs blocking read. */
static ssize_t _osn_bread(int fd, void *buf, size_t count) {
    ssize_t ret;
    size_t offset, remain;
    if (fd < 0) {
        log_error("Invalid fd: %d.", fd);
        return -1;
    }
    if (buf == NULL) {
        log_error("Null pointer to buffer.");
        return -1;
    }

    offset = 0;
    remain = count;
    while (remain > 0) {
        ret = read(fd, buf + offset, remain);
        if (ret < 0) {
            if (ret == EAGAIN || ret == EINTR) {
                continue;
            }
            else {
                return -1;
            }
        }
        else if (ret == 0) {
            return offset;
        }
        offset += ret;
        remain -= ret;
    }
    return offset;
}

/* Get the size (number of sector) of device via sysfs.
 * The functions reads the content of /sys/block/<device>/size,
 * and returns the number of sector. */
static int _osn_get_size_via_sysfs(const char *path, size_t *size) {
    int ret, fd;
    size_t path_len, attr_len, dev_size;
    ssize_t ioret;
    char *last_slash, *dev_name;
    char sysfs_attr[128];
    char sysfs_path[128];

    if (! path || ! size) {
        return -1;
    }
    
    path_len = strlen(path);
    if (! path_len) {
        return -1;
    }
    if (path[path_len - 1] == '/') {
        return -1;
    }

    /* Search for the last / in device path, and extract device name. */
    last_slash = strrchr(path, '/');
    if (last_slash == NULL) {
        log_debug(DEBUG_APP, "Cannot slash in device path [%s], "
                "use entire path as device name.", path);
        dev_name = (char *) path;
    } else {
        dev_name = (char *) last_slash + 1;
    }
    log_debug(DEBUG_APP, "Try to read size of device [%s].", dev_name);

    /* Form sysfs attribute file path. */
    memset(sysfs_path, 0, 128); 
    ret = snprintf(sysfs_path, 128, "/sys/block/%s/size", dev_name);
    if (ret < 0 || ret >= 128) {
        log_error("Failed to format sysfs path.");
        return -1;
    }
    log_debug(DEBUG_APP, "Sysfs path [%s] of device formated.", sysfs_path);

    fd = open(sysfs_path, O_RDONLY);
    if (fd < 0) {
        log_error("Failed to open sysfs file [%s]: %s.",
                sysfs_path, strerror(errno)); 
        return -1;
    }

    /* Read attribute file /sys/block/<device>/size and parse its value. */
    memset(sysfs_attr, 0, 128);
    ioret = _osn_bread(fd, sysfs_attr, 128);
    if (ioret < 0) {
        log_error("Cannot read sysfs file [%s].", sysfs_path);
        goto error;
    }
    sysfs_attr[127] = '\0';
    attr_len = strlen(sysfs_attr);
    if (attr_len > 0 && *(sysfs_attr + attr_len - 1) == '\n') {
        *(sysfs_attr + attr_len - 1) = '\0';
    }
    log_debug(DEBUG_APP, "Sysfs attribute read: %s.", sysfs_attr);

    ret = sscanf(sysfs_attr, "%zu", &dev_size);
    if (ret != 1) {
        log_error("Cannot parse sysfs attribute [%s].", sysfs_attr); 
        goto error;
    }
    log_debug(DEBUG_APP, "Size of device [%s] read: %zu.", path, dev_size);
    
    close(fd);
    (*size) = dev_size;
    return 0;
error:
    close(fd);
    return -1;
}

/* Try to read the first sector of device. */
static int _osn_check_device_availability (const char *path) {
    
    int fd;
    void *buffer;
    size_t dev_size;
    ssize_t ret;
    off64_t dev_offset;

    if (path == NULL) {
        log_error("Null pointer to device path.");
        return -1;
    }

    /* Get the total size of device in sector. */
    if (_osn_get_size_via_sysfs(path, &dev_size) < 0) {
        log_error("Cannot get size of device [%s] via sysfs.", path);
        return -1;
    }
    if (dev_size < 2048) {
        log_error("Device size too small: %zu.", dev_size);
        return -1;
    }

    /* The ONLY sector which can be read in a Streamer mirror is:
     * offset = size_in_sector - 2048. */
    dev_offset = (dev_size - 2048);
    dev_offset *= 512;

    if (posix_memalign(&buffer, 512, 512) != 0) {
        log_error("Failed to create buffer for device read check.");
        return -1;
    }
    
    /* Open the device and read a sector at dev_offset. */
    fd = open(path, O_DIRECT, O_RDONLY);
    if (fd < 0) {
        log_error("Failed to open device file: %s.", strerror(errno));
        free(buffer);
        return -1;
    }

    if (lseek64(fd, dev_offset, SEEK_SET) < 0) {
        log_error("Failed to seek device file [%s] path: %s.",
                path, strerror(errno));
        close(fd);
        free(buffer);
        return -1;
    }

    if ((ret = _osn_bread(fd, buffer, 512)) != 512) {
        log_error("Device [%s] doesn't seem to be available.", path);
        close(fd);
        free(buffer);
        return -1;
    }

    free(buffer);
    close(fd);
    return 0;
}

void osn_device_add(const char* path, int fd, int filter) {
    OsnDevice* dev = NULL;
    int ret = -1;

    if (! path) {
        log_error("Null path, cannot add device.");
        return;
    }

    if (NULL == (dev = calloc(1, sizeof(OsnDevice)))) {
        log_error("Failed to alloctate memory for OsnDevice.");
        return;
    }
    memset(dev, 0, sizeof(OsnDevice));
    dev->path = strdup(path);
    dev->fd = fd;

    //	ret = osn_device_issueinq_standard(dev);
    //	if (!ret) {
    /* inquiry for guid */
    log_debug(DEBUG_DEV, "Try to add device [%s].", path);

    /* Try to read a sector from the given path. */
    if (_osn_check_device_availability(path) < 0) {
        log_error("Read-IO rejected, cannot add device [%s].", path);
        _osn_device_free(dev);
        return;
    }
    log_debug(DEBUG_DEV, "Read operation succeeded on device [%s].", path);

    log_debug(DEBUG_DEV, "Try in inquiry device [%s].", path);
    ret = osn_device_issueinq_t10(dev);
    if (!ret) {
        if(dev->guid[0] == '{' && dev->guid[GUID_LEN-1] == '}'){
            _dev_register(dev, filter);
        }
        else{
            log_debug(DEBUG_DEV, "Device returns unrecognizable GUID [%s].", dev->guid);
            log_debug(DEBUG_DEV, "Device %s(GUID %s)is not a OSN Device",
                    dev->path, dev->guid);
            _osn_device_free(dev);
        }
    } else if (ret == 1) {
        _osn_device_free(dev);
    } else {
        log_error("Failed to inquiry device [%s] (T10), no registration needed.", path);
        _osn_device_free(dev);
    }
    /*
       } else {
       _osn_device_free(dev);
       log_error("failed to register device %s (standard)", path);
       }
       */
}

void osn_device_free_all () {
  while (osndevs)
    _osn_device_destroy(osndevs);
}

void osn_device_probe_all (int filter) {
  /* fresh probe, clean old devices */
  if (osndevs) {
    osn_device_free_all();
  }
  if (osn_arch != NULL) {
    log_debug(DEBUG_DEV, "Probing all SCSI Device ......");
    osn_arch->dev_ops->device_probe_all(filter);
  }
}
