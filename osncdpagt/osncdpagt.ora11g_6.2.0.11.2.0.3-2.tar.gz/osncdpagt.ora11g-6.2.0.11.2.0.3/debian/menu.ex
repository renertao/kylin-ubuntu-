?package(osncdpagt.ora11g):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="osncdpagt.ora11g" command="/usr/bin/osncdpagt.ora11g"
