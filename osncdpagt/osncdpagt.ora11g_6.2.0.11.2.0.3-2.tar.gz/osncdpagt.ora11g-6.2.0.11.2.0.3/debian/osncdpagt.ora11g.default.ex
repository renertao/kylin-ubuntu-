# Defaults for osncdpagt.ora11g initscript
# sourced by /etc/init.d/osncdpagt.ora11g
# installed at /etc/default/osncdpagt.ora11g by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
