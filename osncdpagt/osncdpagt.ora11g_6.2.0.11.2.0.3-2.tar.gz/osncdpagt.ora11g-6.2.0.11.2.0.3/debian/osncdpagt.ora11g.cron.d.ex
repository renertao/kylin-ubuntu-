#
# Regular cron jobs for the osncdpagt.ora11g package
#
0 4	* * *	root	[ -x /usr/bin/osncdpagt.ora11g_maintenance ] && /usr/bin/osncdpagt.ora11g_maintenance
