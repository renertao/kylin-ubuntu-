/*
 * osncdp.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Feb 6, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osndev/osnlib.h>

int main(int argc ,char **argv){
	int ret = 0;
	char *device = NULL;
	OsnDevice *dev = NULL;
	if(argc != 2 || argc != 3){
		printf("Argument error, exit");
		exit(1);
	}
	device = argv[1];	
	if(access(device, F_OK)){
		printf("Failed to access device %s! \n", device);
		exit(1);
	}

	dev = malloc(sizeof(OsnDevice));
	if(dev == NULL){
		printf("Malloc failed,exit");
		exit(1);
	}
	memset(dev, 0, sizeof(OsnDevice));
	dev->path = strdup(device);

	if(argc == 3){
		if(!strcmp(argv[2], "timemark"))
			ret = osn_device_createtimecdp(dev);
		else{
			printf("invalid argument, exit");
			exit(1);
		}
	}
	else
		ret = osn_device_createcdp(dev);
	return ret;
}
