#ifndef OSNCDPD_H_
#define OSNCDPD_H_

#define CDPCLIENT_VERSION "OSN CDPAgent v2.0"

#define OSNRPC_SOCKET_CLIENT_LISTEN_PORT 59191

#define LISTEN_MAX		8
#define INCOMING_MAX	384
#define MAX_DEV_NAMES	256
#define MAX_MSG_ARGCS	16

#define obstack_chunk_alloc malloc
#define obstack_chunk_free free

#endif
