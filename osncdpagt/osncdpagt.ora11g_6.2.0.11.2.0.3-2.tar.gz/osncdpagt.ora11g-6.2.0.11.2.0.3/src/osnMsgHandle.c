/*
 * osnMsgHandle.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 11, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/xmlsave.h>

#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/obstack.h>
#include <osn/osnpub/matchrx.h>
#include <osn/osnagt/osnagt.h>

#include <sys/socket.h>
#include <sys/types.h>

#include "MsgInfo.h"
#include "osncdpd.h"

//#include "schedule.h"
//#include "osncdp_conf.h"
//#include "osnsg.h"

//struct obstack hit;

static unsigned short parsePara(xmlDocPtr doc,xmlNodePtr cur,char **argv);
static void OSN_CmdHandle(char *cmd,unsigned long paranum,char **argv,int sock);

/*
static char *
glue_string(char deli,int n_sub,...){
	char *str;
	int n = 1;
	va_list va;
	va_start(va, n_sub);
	while(n <= n_sub)
	{
		str = va_arg(va, char *);
		obstack_grow(&hit, str, strlen(str));
		obstack_1grow(&hit, ' ');
		n++;
	}
	va_end(va);
	obstack_1grow(&hit, '\0');
	return obstack_finish(&hit);
}
*/

/*
 * Remove leading,trailing,&execss embeded spaces
 *
 */
static char*
ctrim(char* str){
	char *ibuf = str , *obuf = str;
	int i = 0,cnt = 0;
	if(str){
		/*
		 * Remove leading spaces
		*/

		for (ibuf = str;*ibuf && isspace(*ibuf);++ibuf)
			;
		if(str != ibuf)
			memmove(str,ibuf,ibuf - str);

		/*
		 * Callapse embeded spaces
		*/
		while(*ibuf){
			if(isspace(*ibuf) && cnt)
				ibuf++;
			else{
				if(!isspace(*ibuf))
					cnt = 0;
				else{
					*ibuf = ' ';
					cnt = 1;
				}
				obuf[i++] = *ibuf++;
			}
		}
		obuf[i] = '\0';

		/*
		 * remove trailling space
		*/

		while (--i >= 0){
			if(!isspace(obuf[i]))
				break;
		}
		obuf[++i] = '\0';
	}
	return str;
}

static void
sendxmlmessage(int sock, char* MsgInfo, int bs){
	int n;
	if((n = send(sock, MsgInfo, bs, 0)) == -1){
		log_error("Error on sending return message,%s",strerror(errno));
		close(sock);
	}
}

/*
 * Parse the xml tree for OSN_COMMAND parameters
 */
static unsigned short
parsePara(xmlDocPtr doc, xmlNodePtr cur, char**argv){
	cur = cur->xmlChildrenNode;
	unsigned short num=0;
	while(cur != NULL){
		if(!(xmlStrcmp(cur->name,(const xmlChar *)OSN_ParaType))){
			argv[num] = (char *)xmlNodeListGetString(doc, cur->xmlChildrenNode, 1);
//			log_debug(DEBUG_MSG, "Para: %s", argv[num]);
			num++;
		}
		cur = cur->next;
	}
	return num;
}

static void
SockMsgRet(char* status, int errcode, char* errMsg, int sock){
	xmlDocPtr doc = NULL ;
	xmlNodePtr root_node = NULL;
	xmlChar *xmlbuff;
	char *of;
	int buffersize;
	char eno[30];
	xmlIndentTreeOutput = 0;
	doc = xmlNewDoc(BAD_CAST "1.0");
	root_node = xmlNewNode(NULL,BAD_CAST OSN_MsgRet);
	xmlDocSetRootElement(doc, root_node);
	xmlNewChild(root_node, NULL, BAD_CAST OSN_RepStatus, BAD_CAST status);
	sprintf(eno, "%i", errcode);
	xmlNewChild(root_node, NULL, BAD_CAST OSN_ErrorCode, BAD_CAST eno);
	xmlNewChild(root_node, NULL, BAD_CAST OSN_MsgInfo, BAD_CAST errMsg);

	xmlDocDumpFormatMemoryEnc(doc, &xmlbuff, &buffersize, "utf-8", 0);
	of = ctrim((char *)xmlbuff);
//	log_debug(DEBUG_MSG, "Msg to send :[ %s ]", of);
	sendxmlmessage(sock, of, buffersize);
	xmlFree(xmlbuff);
	xmlFreeDoc(doc);
}

/*
 * OSN CDP Command handle function
 */
static void
OSN_CmdHandle(char *cmd,unsigned long paranum,char **argv,int sock){
	char *guid = NULL;
	Osndev* dev = NULL;
   char *path = NULL;

	if(!strcmp(cmd,"OSN_RC_CMD_CREATE_CDP")){
		log_debug(DEBUG_MSG,"received command %s from osn server %s",
				"OSN_RC_CMD_CREATE_CDP", argv[2]);
		guid = strchr(argv[0],'{');
		dev = Osn_getdev(guid, path, 0);
		if(!dev)
			goto nodev;
		SockMsgRet("RS_SUCCESS_START_CREATE_CDP",
				RS_SUCCESS_START_CREATE_CDP, "SUCCESS", sock);
		Osn_markcdp(dev);
	}
	else if(!strcmp(cmd, "OSN_RC_CMD_CREATE_TIMECDP")){
		log_debug(DEBUG_MSG,"received command %s from osn server %s",
						"OSN_RC_CMD_CREATE_CDP", argv[2]);
		guid = strchr(argv[0],'{');
		dev = Osn_getdev(guid, path, 0);
		if(!dev)
			goto nodev;
		SockMsgRet("RS_SUCCESS_START_CREATE_CDP",
					RS_SUCCESS_START_CREATE_CDP, "SUCCESS", sock);
		Osn_marktimecdp(dev);
	}
	else if(!strcmp(cmd,"OSN_RC_CMD_CREATE_CDP_SCHEDULE")){
		log_debug(DEBUG_MSG,"received command %s from osn server %s",
				"OSN_RC_CMD_CREATE_CDP_SCHEDULE", argv[1]);
		guid = strchr(argv[2], '{');
		dev = Osn_getdev(guid, path, 1);
		if(!dev)
			goto nodev;
		SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
				RS_ERROR_API_CATCH_EXCEPTION,"Not Support yet!",sock);
		/*
		int res = read_tab(dev);
		if(res == 1){
			obstack_free(&hit, obstack_finish(&hit));
		}
		if(res!=-1){
			if(parseSchedule(argv[3],strtoul(argv[5],NULL,0),dev) == 0){
				SockMsgRet("RS_SUCCESS",RS_SUCCESS,"SUCCESS",sock);
			}
			else{
				// result failled ,Mode not support , or errno number
				SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",RS_ERROR_API_CATCH_EXCEPTION,"failed to create cdp schedule",sock);
			}
		}
		obstack_free(&hit, obstack_finish(&hit));
		cron_close();
		free(dev);
		*/
	}
	else if(!strcmp(cmd, "OSN_RC_CMD_DELETE_CDP_SCHEDULE")){
		log_debug(DEBUG_MSG, "received command %s",
				"OSN_RC_CMD_DELETE_CDP_SCHEDULE");
		guid = strchr(argv[0],'{');
		dev = Osn_getdev(guid, path, 1);
		if(!dev)
			goto nodev;
		SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
				RS_ERROR_API_CATCH_EXCEPTION,"Not Support yet!",sock);
		/*
		int res = read_tab(dev);
		if(res == 1){ //hit
			obstack_free(&hit, obstack_finish(&hit));
			SockMsgRet("RS_SUCCESS", RS_SUCCESS, "Schedule Deleted", sock);
		}
		else if(res == 0){  //miss
			SockMsgRet("RS_SUCCESS", RS_SUCCESS, "NO SCHEDULE FOUND!", sock);
		}
		else{ //error
			SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
					RS_ERROR_API_CATCH_EXCEPTION,
					"failed to delete cdp schedule,Unknown error,check client log",sock);
		}
		cron_close();
		free(dev);
		*/
	}
	else if(!strcmp(cmd,"OSN_RC_CMD_GET_CDP_SCHEDULE")){
		log_debug(DEBUG_MSG,"received command %s","OSN_RC_CMD_GET_CDP_SCHEDULE");
		guid = strchr(argv[0],'{');
		dev = Osn_getdev(guid, path, 1);
		if(dev == NULL)
			goto nodev;
		SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
				RS_ERROR_API_CATCH_EXCEPTION,"Not Support yet!", sock);
		/*
		int res=read_tab(dev);
		if(res == 1){
			char *tab = obstack_finish(&hit);

			char *line = NULL;
			char retLine[256];
			line=strdup(tab);
			char *min;
			char *hour;
			char *day;
			char *mon;
			char *weak;
			char *cmd;
			char *cmdpara;
			int r=0;
			write_tab(tab);
			r = match_rx("^[ \t]*([^ \t]+)[ \t]([^ \t]+)[ \t]([^ \t]+)[ \t]([^ \t]+)[ \t]([^ \t]+)[ \t]([^ \t]+)[ \t]([^ \t]+)[ \t][^ \t]*.*$",
					line,7,&min,&hour,&day,&mon,&weak,&cmd,&cmdpara);
			if(r == 1){
				strcpy(retLine,"Minute:");
				strcat(retLine,min);
				strcat(retLine,"  Hour:");
				strcat(retLine,hour);
				strcat(retLine,"  Day of month:");
				strcat(retLine,day);
				strcat(retLine,"  Month of year:");
				strcat(retLine,mon);
				strcat(retLine,"  weak:");
				strcat(retLine,weak);
				SockMsgRet("RS_SUCCESS",RS_SUCCESS,retLine,sock);
			}
			else
			{
				SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
						RS_ERROR_API_CATCH_EXCEPTION,
						"failed to get CDP schedule,Match error",sock);
			}
			obstack_free(&hit,tab);   //hit
		}
		else if(res == 0){  //miss
			SockMsgRet("RS_SUCCESS", RS_SUCCESS, "NO SCHEDULE FOUND!", sock);
		}
		else{
			SockMsgRet("RS_ERROR_API_CATCH_EXCEPTION",
					RS_ERROR_API_CATCH_EXCEPTION,
					"failed to get CDP schedule,readtab error",sock);
		}
		cron_close();  // close crontab pipe
		free(dev);
		*/
	}
	else{
		log_warning("Unknown Command Type: %s, ignore",cmd);
	}

	return ;
nodev:
	// no disk found;
	SockMsgRet("RS_ERROR_NOT_FIND_DISK", RS_ERROR_NOT_FIND_DISK, "FAILED",sock);
}

/*
 * parse message function
 * @inbuffer	the message buffer pointer
 * @sock		the socket that the message come from
 * @MsgLength	message length
 */
void parse_SockMsgInfo(char *inbuffer, int sock, int MsgLength) {
	xmlDocPtr doc;
	xmlNodePtr cur;
	char *cmd = NULL;
	int i;
	unsigned long ParaNum = 0;
	char *Para[MAX_MSG_ARGCS];
	doc = xmlReadMemory(inbuffer, MsgLength, NULL, NULL, 1);
	if(doc == NULL){
		log_error("Unable to parse socket message.[%d]",sock);
		goto out;
	}
	cur = xmlDocGetRootElement(doc);
	if(cur == NULL){
		log_error("Empty Message,nothing will be done! [%d]", sock);
		goto out;
	}
	if(xmlStrcmp(cur->name, (const xmlChar *)OSN_MsgStr)){
		log_error("Wrong message type,ignore ! [%d]", sock);
		goto out;
	}
//	log_debug(DEBUG_MSG, "Root name : %s [%d]",cur->name,sock);
	cur = cur->xmlChildrenNode;
	while(cur != NULL){
//		log_debug(DEBUG_MSG,"Node Name: %s [%d]", cur->name, sock);
		if(!(xmlStrcmp(cur->name,BAD_CAST OSN_CMDStr))){
			cmd=(char *)xmlNodeGetContent(cur);
//			log_debug(DEBUG_MSG, "Cmd Name : %s [%d]", cmd, sock);
		}

		if(!(xmlStrcmp(cur->name,BAD_CAST OSN_ParaNum))){
			char *tmp=(char *)xmlNodeGetContent(cur);
			ParaNum = strtoul(tmp,NULL,0);
			xmlFree(tmp);
//			log_debug(DEBUG_MSG, "ParaNum: %ld [%d]", ParaNum, sock);
		}

		if(!(xmlStrcmp(cur->name, BAD_CAST OSN_ParaList))){
			if(ParaNum > 0){
				int num = parsePara(doc, cur, Para);
				if(num != ParaNum){
					log_error("Wrong parameter number! [%d]", sock);
					goto out;
				}
			}
		}
		cur = cur->next;
	}
	if(cmd != NULL)
		OSN_CmdHandle(cmd, ParaNum, Para, sock);
	else{
		log_error("No Command, ignore ! [%d]", sock);
	}

out:
	for(i=0; i<ParaNum; i++){
		if(Para[i] != NULL)
			xmlFree(Para[i]);
	}
	xmlFreeDoc(doc);
	close(sock);
}
