/*
 * osncdp.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Feb 6, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnagt/osnagt.h>

const char program_name[] = "osncdp";

static struct option const long_options[] =
{
	{"config", required_argument, 0, 'c'},
	{"group", no_argument, 0, 'g'},
	{"timemark", no_argument, 0, 't'},
	{"device", required_argument, 0, 'd'},
	{"verbose", required_argument, 0, 'v'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage: %s [OPTION]\n", program_name);
		printf("\
      osncdpagt \n\
        -c, --config=[path]     Execute in the config file.\n");
		printf("\
        -d, --device            device to mark cdp \n\
        -g, --group             mark disk group cdp \n\
        -t, --timemark          mark timemark cdp \n\
        -v, --verbose  level    in verbose mode, 0-9 for level\n\
        -h, --help              display this help and exit\n");
	}
	exit(1);
}

static Osndev*
search_cfg_device(char* path){
	Osndev *rdev = NULL;
	Osndev *dev;
	if(path == NULL){
		log_error("Input NULL device path");
		return NULL;
	}
	pthread_mutex_lock(&osndev_list_lock);
	list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
		if(!strcmp(dev->path, path)){
			rdev = dev;
			break;
		}
	}
	pthread_mutex_unlock(&osndev_list_lock);
	return rdev;
}

int main(int argc ,char **argv){
	int ch,longindex,level,group,timemark;
	char *config = NULL;
	char *device = NULL;
	Osndev *tmpdev, *dev = NULL;
	level = 0;
	group = 0;
	timemark = 0;

	while ((ch = getopt_long(argc,argv,"c:d:gv:h",
			long_options, &longindex)) >= 0){
		switch (ch){
			case 'c':
				config = optarg;
				break;
			case 'd':
				device = optarg;
				break;
			case 'g':
				group = 1;
				break;
			case 't':
				timemark =1;
				break;
			case 'v':
				level = strtol(optarg, NULL, 0);
				break;
			case 'h':
				usage(0);
				break;
			default:
				usage(1);
				break;
		}
	}
	if(device == NULL){
		printf("Please specify the device to mark cdp!\n");
		exit(1);
	}
	if(access(device, F_OK)){
		printf("Failed to access device %s! \n", device);
		exit(1);
	}
	osn_log_init(program_name);
	osn_set_logdaemon(0);
	osn_set_loglevel(level);
	/* scan for device */

	OsnDevice *ods = NULL;
	osn_device_probe_all(0);
	while ((ods = osn_device_get_next(ods))) {
		if(!strcmp(ods->path, device)){
			dev = malloc(sizeof(Osndev));
			memset(dev, 0, sizeof(Osndev));
			dev->path = strdup(ods->path);
			memcpy(dev->guid, ods->guid, GUID_LEN);
			break;
		}
	}
	if(dev == NULL){
		printf("Device %s is not a OSN Storage device.\n", device);
		exit(1);
	}
/*
	dev = malloc(sizeof(Osndev));
	memset(dev, 0, sizeof(Osndev));
	dev->path = strdup(device);
*/
	if(config == NULL){
		config = OSNCFG_DEFAULT;
	}
	if(access(config, F_OK)){
		printf("Config file %s doesn't exist.\n", config);
		exit(1);
	}
	Osn_parse_cfgfile(config);
	if(group){
		tmpdev = search_cfg_device(device);
		if(tmpdev != NULL){
			if(!timemark)
				Osn_markcdp(tmpdev);
			else
				Osn_marktimecdp(tmpdev);
		}
		else{
			printf("Can't find group with device %s in it, Ignore marking cdp.\n", device);
		}
		goto out;
	}

	if(!timemark)
		Osn_markcdp(dev);
	else
		Osn_marktimecdp(dev);
out:
	return 0;
}
