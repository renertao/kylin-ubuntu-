/*
 * osncdpd.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 11, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>
#include <unistd.h>

#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include <osn/osnpub/obstack.h>
#include <osn/osnpub/getopt.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/osncfg.h>

#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>

#include <signal.h>
#include <errno.h>
#include "osncdpd.h"
#include "osnMsgHandle.h"
#include "MsgInfo.h"
//#include "osncdp_conf.h"

static struct obstack inbuffer; // socket data in buffer

static char* server_address;
const char program_name[] = "osncdpd";

uint16_t server_port = OSNRPC_SOCKET_CLIENT_LISTEN_PORT;
fd_set active_fd_set,read_fd_set;
int maxfd = 0;
int init_report_pipe[2];
int incoming[INCOMING_MAX];

static struct option const long_options[] =
{
  {"config", required_argument, 0, 'c'},
  {"foreground",no_argument,0,'f'},
  {"debug",required_argument,0,'d'},
  {"address", required_argument, 0, 'a'},
  {"port", required_argument, 0, 'p'},
  {"version", no_argument, 0, 'v'},
  {"help", no_argument, 0, 'h'},
  {0, 0, 0, 0},
};

static void usage(int status)
{
  if (status != 0)
    fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
  else {
    printf("Usage: %s [OPTION]\n", program_name);
    printf("\
        OSNcdp daemon.\n\
        -c, --config=[path]     Execute in the config file.\n");
    printf("\
        -f, --foreground        make the program run in the foreground\n\
        -d,	--debug debuglevel  print debugging information\n\
        -a, --address=address   listen on specified local address instead of all\n\
        -p, --port=port         listen on specified port instead of 59191\n\
        -h, --help              display this help and exit\n");
  }
  exit(1);
}

static void set_non_blocking(int fd)
{
  int res = fcntl(fd, F_GETFL);

  if (res != -1) {
    res = fcntl(fd, F_SETFL, res | O_NONBLOCK);
    if (res)
      log_warning("unable to set fd flags (%s)!", strerror(errno));
  } else
    log_warning("unable to get fd flags (%s)!", strerror(errno));
}

static void sock_set_keepalive(int sock, int timeout)
{
  if (timeout) { /* timeout [s] */
    int opt = 2;
#if defined(TCP_KEEPCNT) && defined(SOL_TCP)
    if (setsockopt(sock, SOL_TCP, TCP_KEEPCNT, &opt, sizeof(opt)))
      log_warning("unable to set TCP_KEEPCNT on server socket (%s)!", strerror(errno));
#endif
#if defined(TCP_KEEPIDLE) && defined(SOL_TCP)
    if (setsockopt(sock, SOL_TCP, TCP_KEEPIDLE, &timeout, sizeof(timeout)))
      log_warning("unable to set TCP_KEEPIDLE on server socket (%s)!", strerror(errno));
#endif
    opt = 3;
#if defined(TCP_KEEPINTVL) && defined(SOL_TCP)
    if (setsockopt(sock, SOL_TCP, TCP_KEEPINTVL, &opt, sizeof(opt)))
      log_warning("unable to set KEEPINTVL on server socket (%s)!", strerror(errno));
#endif
    opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &opt, sizeof(opt)))
      log_warning("unable to set SO_KEEPALIVE on server socket (%s)!", strerror(errno));
  }
}

static void net_init(char *server_address){
  struct addrinfo hints, *res ,*res0;
  char servname[64];
  int i,sock,opt;
  memset(servname, 0, sizeof(servname));
  snprintf(servname, sizeof(servname), "%d", server_port);
  memset(&hints, 0, sizeof(hints));
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;

  if (getaddrinfo(server_address, servname, &hints, &res0)) {
    log_error("Unable to get address info (%s)!", strerror(errno));
    exit(1);
  }

  i=0;
  for (res = res0; res && i < LISTEN_MAX; res = res->ai_next) {
    sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sock < 0) {
      log_error("Unable to create server socket (%s) %d %d %d!",
          strerror(errno), res->ai_family,
          res->ai_socktype, res->ai_protocol);
      continue;
    }

    sock_set_keepalive(sock, 50);
    opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
      log_warning("Unable to set SO_REUSEADDR on server socket (%s)!",
          strerror(errno));
    opt = 1;
    /*
       if (res->ai_family == AF_INET6 &&
       setsockopt(sock, IPPROTO_IPV6, IPV6_V6ONLY, &opt, sizeof(opt))) {
       log_error("Unable to restrict IPv6 socket (%s)", strerror(errno));
       close(sock);
       continue;
       }
       */
    if (bind(sock, res->ai_addr, res->ai_addrlen)) {
      log_error("Unable to bind server socket (%s)!", strerror(errno));
      close(sock);
      continue;
    }

    if (listen(sock, INCOMING_MAX)) {
      log_error("Unable to listen to server socket (%s)!", strerror(errno));
      close(sock);
      continue;
    }
    log_debug(DEBUG_CONN,"Listen to server socket: %d",sock);
    set_non_blocking(sock);
    FD_SET(sock,&active_fd_set);
    incoming[i]=sock;
    if(sock > maxfd){
      maxfd = sock;
    }
    i++;
  }

  freeaddrinfo(res0);
  if (i == 0)
    exit(1);
}

static int
readxmlmessage(int filedes){
  obstack_init(&inbuffer);
  char buffer[512];
  int nbytes;
  while(1){
    if((nbytes = recv(filedes, buffer, 512, 0)) == -1){
      if(errno == EAGAIN || errno == EINTR)
        break;
      else{
        log_error("recv error exit, errno : %s", strerror(errno));
        close(filedes);
      }
    }
    if(nbytes == 0)
      break;
    obstack_grow(&inbuffer, &buffer, nbytes);
  }

  obstack_1grow(&inbuffer, '\0');
  return obstack_object_size(&inbuffer);
}

int main(int argc ,char **argv){
  int ch,longindex;
  char *config = NULL;
  char *xmlbuffer;
  struct sockaddr_in clientname;
  socklen_t size;
  int daemon = 1;
  int level = 0;

  while ((ch = getopt_long(argc,argv,"c:fd:a:p:vh",
          long_options, &longindex)) >= 0){
    switch (ch){
      case 'c':
        config = optarg;
        break;
      case 'f':
        daemon = 0;
        break;
      case 'd':
        level= strtol(optarg,NULL,0);
        break;
      case 'a':
        server_address = strdup(optarg);
        if(server_address == NULL){
          perror("strdup failed");
          exit(-1);
        }
        break;
      case 'p':
        server_port = (uint16_t)strtoul(optarg, NULL, 0);
        break;
      case 'v':
        printf("%s version %s \n", program_name, CDPCLIENT_VERSION);
        exit(0);
        break;
      case 'h':
        usage(0);
        break;
      default:
        usage(1);
        break;
    }
  }

  osn_log_init(program_name);
  osn_set_logdaemon(daemon);
  osn_set_loglevel(level);
  if(config == NULL){
    config = OSNCFG_DEFAULT;
  }
  Osn_parse_cfgfile(config);
#if defined(aix)
  if (0) {
#else
    if (daemon) {
#endif
      log_info("Starting %s...", program_name);
      char buf[64];
      pid_t pid;
      int fd;

      fd = open("/var/run/osncdpd.pid", O_WRONLY|O_CREAT, 0644);
      if (fd < 0) {
        log_error("unable to create pid file");
        exit(1);
      }
      pid = fork();
      if (pid < 0) {
        log_error("starting daemon failed");
        exit(1);
      } else if (pid) {
        /*
           int res = -1;
           close(init_report_pipe[1]);
           if (read(init_report_pipe[0], &res, sizeof(res)) < sizeof(res))
           exit(-1);
           else
           exit(res);
           */
        exit(0);
      }

      if (chdir("/") < 0) {
        log_error("failed to set working dir to /: %m");
        exit(1);
      }
      if (lockf(fd, F_TLOCK, 0) < 0) {
        log_error("unable to lock pid file");
        exit(1);
      }
      if (ftruncate(fd, 0) < 0) {
        log_error("failed to ftruncate the PID file: %m");
        exit(1);
      }

      sprintf(buf, "%d\n", (int)getpid());
      if (write(fd, buf, strlen(buf)) < strlen(buf)) {
        log_error("failed to write PID to PID file: %m");
        exit(1);
      }
      close(0);
      open("/dev/null", O_RDWR);
      dup2(0, 1);
      dup2(0, 2);
      setsid();
    }

    /* Initialize the set of active  sockets */
    FD_ZERO (&active_fd_set);
    memset(incoming, 0, sizeof(incoming));
    net_init(NULL);
    while(1){
      read_fd_set = active_fd_set;

      if(select(FD_SETSIZE, &read_fd_set,NULL,NULL,NULL)<0){
        log_error("select error");
        exit(-1);
      }

      int i;

      for(i=0;i<FD_SETSIZE;++i)
        if(FD_ISSET(i, &read_fd_set)){
          int j;
          for(j=0; j<INCOMING_MAX; j++){
            if(i == incoming[j]){
              break;
            }
          }
          if(i == incoming[j] && j != INCOMING_MAX){
            size = sizeof(clientname);
            int nsock = accept(incoming[j],
                (struct sockaddr *) &clientname, &size);
            if(nsock < 0){
              log_error("accept socket error");
              exit(-1);
            }
            set_non_blocking(nsock);
            log_debug(DEBUG_CONN, "Accept connection from host %s,port %hd,accept sock: %d",
                inet_ntoa(clientname.sin_addr),ntohs(clientname.sin_port),nsock);
            FD_SET(nsock,&active_fd_set);
          } else {
            int MsgLength = readxmlmessage(i);
            //					log_debug(DEBUG_CONN, "Get %d bytes from socket %d ", MsgLength, i);
            xmlbuffer = (char *)obstack_finish(&inbuffer);
            FD_CLR(i, &active_fd_set); /* handled, clear mark bit*/
            parse_SockMsgInfo(xmlbuffer, i, MsgLength);
            obstack_free(&inbuffer, xmlbuffer);
          }
        }
    }
    return 0;
  }
