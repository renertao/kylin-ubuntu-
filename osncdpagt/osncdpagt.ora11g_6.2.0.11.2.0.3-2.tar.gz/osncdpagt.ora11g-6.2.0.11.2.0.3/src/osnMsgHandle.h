#ifndef OSN_MSGHANDLE_H_
#define OSN_MSGHANDLE_H_

void parse_SockMsgInfo(char *inbuffer,int sock,int MsgLength);

#endif
