/*
 * osncfg.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 23, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <osn/osnagt/osnagt.h>
#include <osn/osnpub/osncfg.h>
#include <osn/osnpub/osnlog.h>
#include <osn/osnpub/base64.h>


//struct list_head	osndev_list;
LIST_HEAD(osndev_list);
pthread_mutex_t osndev_list_lock = PTHREAD_MUTEX_INITIALIZER;

/* struct list_head	osndevgrp_list; Removed since Streamer 6.1. */
//struct list_head	osnapp_list;
LIST_HEAD(osnapp_list);
pthread_mutex_t osnapp_list_lock = PTHREAD_MUTEX_INITIALIZER;

static int Osn_parse_appentry(xmlDocPtr doc, xmlNodePtr cur) {
   xmlChar	*key = NULL;
   OsnApp *appentry = NULL;
   appentry = malloc(sizeof(OsnApp));
   if(appentry == NULL){
      log_error("Unable to malloc memory for OsnApp");
      return -1 ;
   }
   memset(appentry, 0, sizeof(OsnApp));
   //INIT_LIST_HEAD(&appentry->osn_app_list_entry);
   key = xmlGetProp(cur, BAD_CAST OSNCFG_APPENT_ID);
   if(key != NULL){
      appentry->id = strtoul((char *)key, NULL, 0);
      xmlFree(key);
   }else{
      appentry->id = 0;
   }
   cur = cur->xmlChildrenNode;
   while(cur != NULL){
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_SVR)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->server = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_MODE)){
         key = xmlNodeGetContent(cur);
         if(key){
            appentry->mode = strtoul((char *)key, NULL, 0);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_NAME)){
         key = xmlNodeGetContent(cur);
         if(key){
            appentry->name = strdup((char *)key);
            xmlFree(key);
            key = xmlGetProp(cur, BAD_CAST OSNCFG_APPENT_TYPE);
            if(key){
               int type = strtoul((char *)key, NULL, 0);
               if(type == 0 || type > APP_MAXNUM){
                  log_error("Bad app type %d", type);
                  xmlFree(key);
                  return -1;
               }
               appentry->type = type;
               xmlFree(key);
            }else{
               xmlFree(key);
               log_error("No app type, nonstandard config file");
               return -1;
            }
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_USER)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->usrname = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_GRP)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->usrgroup = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_PWD)){
         key = xmlNodeGetContent(cur);
         char* pwd_encrypted; /* unsigned qualifier added by Yshou. */
         char* pwd_clear;
         if(key && strlen((char *)key)){
            pwd_encrypted = strdup((char *)key);
            pwd_clear = base64_decode(pwd_encrypted);
            appentry->passwd = strdup(pwd_clear);
            free(pwd_clear);
            free(pwd_encrypted);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_IPATH)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->installpath = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_DPATH)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->datapath = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT_ENV)){
         key = xmlNodeGetContent(cur);
         if(key && strlen((char *)key)){
            appentry->env = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPEND_HOST)) {
          key = xmlNodeGetContent(cur);
          if (key && strlen((char *)key)) {
              appentry->host = strdup((char *)key);
              xmlFree(key);
          }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPEND_PORT)) {
          key = xmlNodeGetContent(cur);
          if (key && strlen((char *)key)) {
              appentry->port = strdup((char *)key);
              xmlFree(key);
          }
      }
      cur = cur->next;
   }
   pthread_mutex_lock(&osnapp_list_lock);
   list_add_tail(&appentry->osn_app_list_entry, &osnapp_list);
   pthread_mutex_unlock(&osnapp_list_lock);

   log_debug(DEBUG_APP, "Import App: Name: %s", appentry->name);
   return 0;
}

static int Osn_parse_app(xmlDocPtr doc, xmlNodePtr cur) {
   int ret = 0;
   cur = cur->xmlChildrenNode;
   while(cur != NULL){
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APPENT)){
         ret = Osn_parse_appentry(doc, cur);
         if(ret)
            return ret;
      }
      cur = cur->next;
   }
   return ret;
}

/**
 * When counter <deventry> node, read its properties.
 * @param doc The xml doc to be parsed.
 * @param cur The <deventry> node.
 * @return 0 on success, -1 on error.
 */
static int Osn_parse_deventry(xmlDocPtr doc, xmlNodePtr cur) {
   xmlChar	*key = NULL;
   Osndev *dev = NULL;
   dev = malloc(sizeof(Osndev));
   if(dev == NULL ){
      log_error("Failed to get memory");
      return -1 ;
   }
   memset(dev, 0, sizeof(Osndev));
   INIT_LIST_HEAD(&dev->osn_dev_list_entry);
   INIT_LIST_HEAD(&dev->osn_grp_dev_entry);

   /**
    * @Deprecated since Streamer 6.1.
    * CDPAgt is no longer supposed to manage disk groups.
    *  
    * Iterate the entire the group list and search for specified
    * group name in the XML doc.
    * If the group cannot be found, the create one and attach it
    * to the group list.
    *

   key = xmlGetProp(cur, BAD_CAST OSNCFG_DEVENT_GRP);

   if(key != NULL){
      Osndevgrp *grpentry,*grp = NULL;
      list_for_each_entry(grpentry, &osndevgrp_list, grp_list_entry){
         if(!strcmp(grpentry->grp_name, (char *)key)){
            grp = grpentry;
         }
      }
      if(!grp){
         grp = malloc(sizeof(Osndevgrp));
         memset(dev, 0, sizeof(Osndevgrp));
         INIT_LIST_HEAD(&grp->grp_list_entry);
         INIT_LIST_HEAD(&grp->devs_list);
         grp->grp_name = strdup((char *)key);
         list_add_tail(&grp->grp_list_entry, &osndevgrp_list);
      }
      list_add_tail(&dev->osn_grp_dev_entry, &grp->devs_list);
      dev->dgrp = grp;
      xmlFree(key);
   } */

   /* forcecheck */
   key = xmlGetProp(cur, BAD_CAST OSNCFG_DEVENT_CHK);
   if(key != NULL){
      dev->forcecheck = strtoul((char *)key, NULL, 0);
      xmlFree(key);
   }else{
      dev->forcecheck = 0;
   }

   /* device id */
   key = xmlGetProp(cur, BAD_CAST OSNCFG_DEVENT_ID);
   if(key != NULL){
      dev->id = strtoul((char *)key, NULL, 0);
      xmlFree(key);
   }else{
      dev->id = 0;
   }

   cur = cur->xmlChildrenNode;
   while(cur != NULL){
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_DEVENT_PATH)){
         key = xmlNodeGetContent(cur);
         if(key){
            dev->path = strdup((char *)key);
            xmlFree(key);
         }
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_DEVENT_GUID)){
         key = xmlNodeGetContent(cur);
         if(key){
            strncat((char *)dev->guid, (const char *)key, GUID_LEN);
            xmlFree(key);
         }
      }
      cur = cur->next;
   }
   pthread_mutex_lock(&osndev_list_lock);
   list_add_tail(&dev->osn_dev_list_entry, &osndev_list);
   pthread_mutex_unlock(&osndev_list_lock);
   log_debug(DEBUG_DEV, "Import config device, GUID %s , path: %s", dev->guid, dev->path);
   return 0;
}

/**
 * When encounter <device> node, continue to read devices.
 * @param doc The xml doc to be parsed.
 * @param cur The <device> node.
 * @return 0 on success, -1 on error.
 */
static int Osn_parse_dev(xmlDocPtr doc, xmlNodePtr cur) {
   int ret = 0;
   cur = cur->xmlChildrenNode;
   while(cur != NULL){
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_DEVENT)){
         ret = Osn_parse_deventry(doc, cur);
         if(ret)
            return ret;
      }
      cur = cur->next;
   }
   return ret;
}

/**
 * Read config file and load configuration of CDP Agent.
 * @param docname The XML doc containing config infos.
 * @return 0 on success, -1 on error.
 */
int Osn_parse_cfgfile(char* docname) {
   /*OsnApp *itr_app;*/
   xmlDocPtr	doc;
   xmlNodePtr	cur;
   int ret = 0;

   INIT_LIST_HEAD(&osndev_list);
   /*INIT_LIST_HEAD(&osndevgrp_list);*/
   INIT_LIST_HEAD(&osnapp_list);

   doc = xmlParseFile(docname);
   if(doc == NULL) {
      log_error("Config file %s parse error.", docname);
      ret = -1;
      goto out;
   }
   cur = xmlDocGetRootElement(doc);
   if(cur == NULL) {
      log_debug(DEBUG_APP, "Empty Config file.\n");
      ret = -2;
      goto out_free;
   }
   if(xmlStrcmp(cur->name, BAD_CAST OSNCFG_ROOT)) {
      log_error("Nonstandard config file");
      ret = -1;
      goto out_free;
   }

   cur = cur->xmlChildrenNode;
   while (cur != NULL) {
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_APP)) {
         ret = Osn_parse_app(doc, cur);
         if(ret)
            goto out_free;
      }
      if(!xmlStrcmp(cur->name, BAD_CAST OSNCFG_DEV)) {
         ret = Osn_parse_dev(doc, cur);
         if(ret)
            goto out_free;
      }
      cur = cur->next;
   }
    
    /*
    log_debug(DEBUG_APP, "App loaded successfully.");
    list_for_each_entry(itr_app, &osnapp_list, osn_app_list_entry) {
        log_debug(DEBUG_APP, "entry [%ld] prev [%ld] next [%ld].",
            &itr_app->osn_app_list_entry,
            itr_app->osn_app_list_entry.prev,
            itr_app->osn_app_list_entry.next);
    }*/
out_free:
   xmlFreeDoc(doc);
out:
   return ret;
}

int Osn_update_cfgfile(char* docname) {
   Osndev *dev;
   OsnApp *app;
   xmlDocPtr doc = NULL;       /* document pointer */
   xmlNodePtr root_node = NULL, pnode = NULL, node = NULL, subnode = NULL;
   xmlAttrPtr attr __attribute__((unused)) = NULL; /* Marked as unused by Yshou. */
   xmlChar conv[256];
   char* encryptpwd = NULL;
   if(docname == NULL){
      log_debug(DEBUG_APP, "no file specified!");
      return -1;
   }
   doc = xmlNewDoc(BAD_CAST "1.0");
   root_node = xmlNewNode(NULL, BAD_CAST OSNCFG_ROOT);
   xmlDocSetRootElement(doc, root_node);
   /* app entries */
   pnode = xmlNewNode(NULL, BAD_CAST OSNCFG_APP);
   list_for_each_entry(app, &osnapp_list, osn_app_list_entry){
      node = xmlNewNode(NULL, BAD_CAST OSNCFG_APPENT);
      /* name */
      if(app->name != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_NAME, BAD_CAST app->name);
         xmlStrPrintf(conv, 256, "%d", app->type);
         attr = xmlNewProp(subnode, BAD_CAST OSNCFG_APPENT_TYPE, conv);
      }

      if(app->id){
         xmlStrPrintf(conv, 256, "%d", app->id);
         attr = xmlNewProp(node, BAD_CAST OSNCFG_APPENT_ID, conv);
      }

      /* server */
      if(app->server != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_SVR, BAD_CAST app->server);
      }
      /* password */
      if(app->passwd != NULL){
         encryptpwd = base64_encode(app->passwd);
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_PWD, BAD_CAST encryptpwd);
         free(encryptpwd);
      }
      /* username */
      if(app->usrname != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_USER, BAD_CAST app->usrname);
      }
      /* usergroup*/
      if(app->usrgroup != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_GRP, BAD_CAST app->usrgroup);
      }
      /* data path */
      if(app->datapath != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_DPATH, BAD_CAST app->datapath);
      }
      /* install path */
      if(app->installpath != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_IPATH, BAD_CAST app->installpath);
      }
      /* oracle home environment virable */
      if(app->env != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_APPENT_ENV, BAD_CAST app->env);
      }
      
      if(app->host != NULL) {
          subnode = xmlNewChild(node, NULL,
                BAD_CAST OSNCFG_APPEND_HOST, BAD_CAST app->host);
      }
      if(app->port != NULL) {
          subnode = xmlNewChild(node, NULL,
                BAD_CAST OSNCFG_APPEND_PORT, BAD_CAST app->port);
      }
      /* mode */
      xmlStrPrintf(conv, 256, "%d", app->mode);
      subnode = xmlNewChild(node, NULL, BAD_CAST OSNCFG_APPENT_MODE, conv);
      xmlAddChild (pnode, node);
   }
   xmlAddChild (root_node, pnode);
   /* device entries */
   pnode = xmlNewNode(NULL, BAD_CAST OSNCFG_DEV);
   pthread_mutex_lock(&osndev_list_lock);
   list_for_each_entry(dev, &osndev_list, osn_dev_list_entry){
      node = xmlNewNode(NULL, BAD_CAST OSNCFG_DEVENT);

      /* group */

      /** @Deprecated since Streamer 6.1.
      if(dev->dgrp != NULL){
         attr = xmlNewProp(node, BAD_CAST OSNCFG_DEVENT_GRP, BAD_CAST dev->dgrp->grp_name);
      } */

      /* forcecheck */
      xmlStrPrintf(conv, 256, "%d", dev->forcecheck);
      attr = xmlNewProp(node, BAD_CAST OSNCFG_DEVENT_CHK, conv);

      if(dev->id){
         xmlStrPrintf(conv, 256, "%d", dev->id);
         attr = xmlNewProp(node, BAD_CAST OSNCFG_DEVENT_ID, conv);
      }

      /* device guid */
      if(dev->guid != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_DEVENT_GUID, BAD_CAST dev->guid);
      }

      /* device path */
      if(dev->path != NULL){
         subnode = xmlNewChild(node, NULL,
               BAD_CAST OSNCFG_DEVENT_PATH, BAD_CAST dev->path);
      }
      xmlAddChild (pnode, node);
   }
   pthread_mutex_unlock(&osndev_list_lock);
   xmlAddChild (root_node, pnode);
   xmlSaveFormatFileEnc(docname, doc, "UTF-8", 1);
   xmlFreeDoc (doc);
   return 0;
}
