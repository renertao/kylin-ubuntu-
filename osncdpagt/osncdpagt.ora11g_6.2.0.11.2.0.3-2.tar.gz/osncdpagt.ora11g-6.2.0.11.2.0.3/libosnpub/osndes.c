/*
 * osndes.c
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Jan 9, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/des.h>
#include <osn/osnpub/osndes.h>

char *
OSNEncrypt(char *Key, char *Msg, int size)
{
	static char*    Res;
	int	n=0;
	DES_cblock      Key2;
	DES_key_schedule schedule;

	Res = (char *) malloc(size);

	/* Prepare the key for use with DES_cfb64_encrypt */
	memcpy(Key2, Key, 8);
	DES_set_odd_parity(&Key2);
	DES_set_key_checked(&Key2, &schedule);

	/* Encryption occurs here */
	DES_cfb64_encrypt((unsigned char *) Msg, (unsigned char *) Res,
			size, &schedule, &Key2, &n, DES_ENCRYPT);

	return (Res);
}

char *
OSNDecrypt(char *Key, char *Msg, int size)
{
	static char*    Res;
	int             n=0;

	DES_cblock      Key2;
	DES_key_schedule schedule;

	Res = (char *) malloc( size );

	/* Prepare the key for use with DES_cfb64_encrypt */
	memcpy(Key2, Key, 8);
	DES_set_odd_parity(&Key2);
	DES_set_key_checked(&Key2, &schedule);

	/* Decryption occurs here */
	DES_cfb64_encrypt((unsigned char *) Msg, (unsigned char *) Res,
			size, &schedule, &Key2, &n, DES_DECRYPT);

	return (Res);
}
