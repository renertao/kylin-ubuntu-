/*
 * osndb2.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Aug 27, 2012
 *      Author: tao.shang@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNDB2_H_
#define OSNDB2_H_

int osn_db2_precdpscripts(const char *usr,const char *dbname,const char *path);
int osn_db2_postcdpscripts(const char *usr,const char *dbname,const char *path);

#endif /* OSNDB2_H_ */
