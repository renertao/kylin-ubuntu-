/*
 * osnase.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Feb 27, 2013
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNASE_H_
#define OSNASE_H_

#endif /* OSNASE_H_ */
