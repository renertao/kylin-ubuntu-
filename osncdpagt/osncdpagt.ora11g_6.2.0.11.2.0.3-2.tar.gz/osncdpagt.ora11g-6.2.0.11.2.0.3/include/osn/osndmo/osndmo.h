/*
 * osndmo.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 14, 2012
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef __DOMINO_H
#define __DOMINO_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <osn/osnpub/list.h>
#include <domino/global.h>

typedef struct backup_file_list_s Osndmo_flist;

struct backup_file_list_s {
    struct list_head entry;
    char *fname;
    HANDLE h_db;
    HANDLE backup_context;
    DWORD file_size_high, file_size_low;
};

#include <domino/lapicinc.h>

#include <domino/global.h>
#include <domino/nsfdb.h>
#include <domino/nsfsearc.h>
#include <domino/osfile.h>
#include <domino/names.h>
#include <domino/nsferr.h>
#include <domino/textlist.h>
#include <domino/ods.h>
#include <domino/odstypes.h>

struct list_head* osn_domino_initflist(char *notespath);
int osn_domino_initdmo(char *notespath);
int osn_domino_precdp(struct list_head* list);
int osn_domino_postcdp(struct list_head* list);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __DOMINO_H */
