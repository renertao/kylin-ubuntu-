/*
 * osnmql.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Mar 27, 2012
 *      Author: minfei.huang@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNMQL_H_
#define OSNMQL_H_

#include <mysql/mysql.h>

int osn_mysql_connect(MYSQL *cn, const char *user, const char *passwd, const char *unix_socket);
void osn_mysql_disconnect(MYSQL *cn);
int osn_refresh_database(MYSQL *cn);

#endif /* OSNMQL_H_ */
