/*
 * hpux.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 17, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef HPUX_H_
#define HPUX_H_

extern OsnArch	osn_hpux_arch;

#endif /* HPUX_H_ */
