/*
 * osndev.h
 *
 *  Copyright (C) 2006-2013 Enterprise Information Management.Inc
 *  All rights reserved.
 *
 *  Created on: Dec 16, 2011
 *      Author: feiwen.tong@infocore.cn
 *      http://www.infocore.cn
 */

#ifndef OSNDEV_H_
#define OSNDEV_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <sys/types.h>
#include <stdint.h>

#define VID_LEN		8
#define	PID_LEN		16
#define	REV_LEN		4
#define GUID_LEN	38


  typedef struct _OsnDevice OsnDevice;

  struct _OsnDevice {
    OsnDevice* next;
    char* path;
    int fd;
    uint8_t vid[VID_LEN + 1]; /* vendor ID */
    uint8_t pid[PID_LEN + 1]; /* product ID */
    uint8_t rev[REV_LEN + 1]; /* revision level */
    uint8_t guid[GUID_LEN + 1]; /* Unit serial number */
  };

  typedef const struct _OsnDevOps {
    void (*device_probe_all)(int filter);
  } OsnDevOps;

  void osn_device_add(const char* path, int fd, int filter);
  OsnDevice* osn_device_get_next(const OsnDevice* dev);
  void osn_device_probe_all(int filter);
  void osn_device_free_all();

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* OSNDEV_H_ */
