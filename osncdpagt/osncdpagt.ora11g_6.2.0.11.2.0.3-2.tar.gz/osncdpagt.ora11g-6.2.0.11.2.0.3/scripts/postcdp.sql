#!/bin/bash
PATH=$PATH:$1
export PATH

db2 connect to $2 > $HOME/result.txt

if [ $? != 0 ]
then
	echo "connect to database failed at postcdp"
	exit 1
fi

db2 set write resume for database > $HOME/result.txt
if [ $? != 0 ]
then
        echo "set write resume failed"
        exit 2
fi
