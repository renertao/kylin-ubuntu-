#!/bin/bash

isql -U$1 -P$2 -S$3 <<!
select P.cmd from master..sysprocesses P,master..sysdatabases D where P.dbid=D.dbid and D.name="$4"
go
quit
!
