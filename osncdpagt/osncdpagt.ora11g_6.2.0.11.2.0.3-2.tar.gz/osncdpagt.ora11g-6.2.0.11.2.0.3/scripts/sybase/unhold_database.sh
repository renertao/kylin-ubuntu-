#!/bin/bash

isql -U$1 -P$2 -S$3 <<!
quiesce database $4 release
go
quit
!
