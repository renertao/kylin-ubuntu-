#!/bin/bash

isql -U$1 -P$2 -S$3 <<!
select name from master.dbo.sysdatabases
go
quit
!
