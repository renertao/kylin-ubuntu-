#!/bin/sh
PATH=$PATH:$1
export PATH
db2 connect to $2 > $HOME/result.txt
if [ $? != 0 ]
then
	echo "**********CONNECT TESTING**********"
	echo "connect test failed"
	echo "**********FINISH  TESTING**********"
	exit 1 
fi
