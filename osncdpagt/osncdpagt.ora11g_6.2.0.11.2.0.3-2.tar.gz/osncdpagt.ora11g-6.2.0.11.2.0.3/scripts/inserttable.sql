declare
 i int:=1;
begin
	while i< 10000000 loop
		insert into infocore VALUES('test','HangZhouXiaoShan',i);
		i := i+1;
		if(i mod 100 =0) then
			commit;
		end if;
	end loop;
end;
