truncate table infocore;
