create table infocore(
	name VARCHAR2(10),
	address VARCHAR2(50),
	age NUMBER);
