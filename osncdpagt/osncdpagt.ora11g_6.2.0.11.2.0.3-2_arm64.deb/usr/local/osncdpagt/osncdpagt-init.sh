#!/bin/sh

#
# *****************************************************************
# * Copyright (C) 2006-2013 Enterprise Information Management.Inc *
# * All rights reserved.					  *
# * Author: feiwen.tong@infocore.cn				  *
# *****************************************************************		
# OSNCDPAgent environment variables

PATH=$PATH:/usr/local/osncdpagt/bin
ORACLE_HOME=`su - oracle -c 'env | grep ORACLE_HOME | cut -d = -f 2'`
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/osncdpagt/lib:"$ORACLE_HOME"/lib

ENV_SCRIPT="/usr/local/osncdpagt/env.sh"

# Export environment variables into /etc/profile
if [ -f /etc/profile ]; then
    echo "export PATH=$PATH # OSNCDPAGT_ENV" >> /etc/profile
    echo "export ORACLE_HOME=$ORACLE_HOME # OSNCDPAGT_ENV" >> /etc/profile
    echo "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH # OSNCDPAGT_ENV" >> /etc/profile
fi

# Generate a env script which is used by Streamer Client
echo "#!/bin/sh" > "$ENV_SCRIPT"
echo "export PATH=$PATH" >> "$ENV_SCRIPT"
echo "export ORACLE_HOME=$ORACLE_HOME" >> "$ENV_SCRIPT"
echo "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH" >> "$ENV_SCRIPT"

export PATH
export ORACLE_HOME
export LD_LIBRARY_PATH

echo "exported PATH=$PATH"
echo "exported ORACLE_HOME=$ORACLE_HOME"
echo "exported LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
echo "Environment-variables configuration added into /etc/profile"
